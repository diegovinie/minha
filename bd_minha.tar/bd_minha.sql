-- MySQL dump 10.13  Distrib 5.7.17, for Linux (x86_64)
--
-- Host: localhost    Database: bd_minha
-- ------------------------------------------------------
-- Server version	5.7.17-0ubuntu0.16.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `A17`
--

DROP TABLE IF EXISTS `A17`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `A17` (
  `A17_id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `A17_number` varchar(3) NOT NULL,
  `A17_balance` decimal(10,2) NOT NULL DEFAULT '0.00',
  `A17_weight` int(1) NOT NULL COMMENT 'Porcentaje ponderado',
  `A17_assigned` tinyint(1) NOT NULL DEFAULT '1',
  `A17_occupied` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'Si esta habitado',
  `A17_notes` varchar(1000) DEFAULT NULL,
  PRIMARY KEY (`A17_id`),
  UNIQUE KEY `A17_number_2` (`A17_number`),
  KEY `A17_number` (`A17_number`)
) ENGINE=InnoDB AUTO_INCREMENT=121 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `A17`
--

LOCK TABLES `A17` WRITE;
/*!40000 ALTER TABLE `A17` DISABLE KEYS */;
INSERT INTO `A17` VALUES (1,'1A',0.00,3,1,1,NULL);
INSERT INTO `A17` VALUES (2,'1B',0.00,2,1,1,NULL);
INSERT INTO `A17` VALUES (3,'1C',0.00,2,1,1,NULL);
INSERT INTO `A17` VALUES (4,'1D',0.00,3,1,1,NULL);
INSERT INTO `A17` VALUES (5,'1E',0.00,2,1,1,NULL);
INSERT INTO `A17` VALUES (6,'1F',0.00,1,1,1,NULL);
INSERT INTO `A17` VALUES (7,'1G',0.00,1,1,1,NULL);
INSERT INTO `A17` VALUES (8,'1H',0.00,2,1,1,NULL);
INSERT INTO `A17` VALUES (9,'2A',0.00,3,1,1,NULL);
INSERT INTO `A17` VALUES (10,'2B',0.00,2,1,1,NULL);
INSERT INTO `A17` VALUES (11,'2C',0.00,2,1,1,NULL);
INSERT INTO `A17` VALUES (12,'2D',0.00,3,1,1,NULL);
INSERT INTO `A17` VALUES (13,'2E',0.00,2,1,1,NULL);
INSERT INTO `A17` VALUES (14,'2F',0.00,1,1,1,NULL);
INSERT INTO `A17` VALUES (15,'2G',0.00,1,1,1,NULL);
INSERT INTO `A17` VALUES (16,'2H',0.00,2,1,1,NULL);
INSERT INTO `A17` VALUES (17,'3A',0.00,3,1,1,NULL);
INSERT INTO `A17` VALUES (18,'3B',0.00,2,1,1,NULL);
INSERT INTO `A17` VALUES (19,'3C',0.00,2,1,1,NULL);
INSERT INTO `A17` VALUES (20,'3D',0.00,3,1,1,NULL);
INSERT INTO `A17` VALUES (21,'3E',0.00,2,1,1,NULL);
INSERT INTO `A17` VALUES (22,'3F',0.00,1,1,1,NULL);
INSERT INTO `A17` VALUES (23,'3G',0.00,1,1,1,NULL);
INSERT INTO `A17` VALUES (24,'3H',0.00,2,1,1,NULL);
INSERT INTO `A17` VALUES (25,'4A',0.00,3,1,1,NULL);
INSERT INTO `A17` VALUES (26,'4B',0.00,2,0,1,NULL);
INSERT INTO `A17` VALUES (27,'4C',0.00,2,1,1,NULL);
INSERT INTO `A17` VALUES (28,'4D',0.00,3,1,0,NULL);
INSERT INTO `A17` VALUES (29,'4E',0.00,2,1,1,NULL);
INSERT INTO `A17` VALUES (30,'4F',0.00,1,1,1,NULL);
INSERT INTO `A17` VALUES (31,'4G',0.00,1,1,1,NULL);
INSERT INTO `A17` VALUES (32,'4H',0.00,2,1,1,NULL);
INSERT INTO `A17` VALUES (33,'5A',0.00,3,1,1,NULL);
INSERT INTO `A17` VALUES (34,'5B',0.00,2,1,1,NULL);
INSERT INTO `A17` VALUES (35,'5C',0.00,2,1,1,NULL);
INSERT INTO `A17` VALUES (36,'5D',0.00,3,1,1,NULL);
INSERT INTO `A17` VALUES (37,'5E',0.00,2,1,1,NULL);
INSERT INTO `A17` VALUES (38,'5F',0.00,1,1,1,NULL);
INSERT INTO `A17` VALUES (39,'5G',0.00,1,1,1,NULL);
INSERT INTO `A17` VALUES (40,'5H',0.00,2,1,1,NULL);
INSERT INTO `A17` VALUES (41,'6A',0.00,3,1,1,NULL);
INSERT INTO `A17` VALUES (42,'6B',0.00,2,1,1,NULL);
INSERT INTO `A17` VALUES (43,'6C',0.00,2,1,1,NULL);
INSERT INTO `A17` VALUES (44,'6D',0.00,3,1,1,NULL);
INSERT INTO `A17` VALUES (45,'6E',0.00,2,1,1,NULL);
INSERT INTO `A17` VALUES (46,'6F',0.00,1,1,1,NULL);
INSERT INTO `A17` VALUES (47,'6G',0.00,1,1,1,NULL);
INSERT INTO `A17` VALUES (48,'6H',0.00,2,1,1,NULL);
INSERT INTO `A17` VALUES (49,'7A',0.00,3,1,1,NULL);
INSERT INTO `A17` VALUES (50,'7B',0.00,2,1,1,NULL);
INSERT INTO `A17` VALUES (51,'7C',0.00,2,1,1,NULL);
INSERT INTO `A17` VALUES (52,'7D',0.00,3,1,0,NULL);
INSERT INTO `A17` VALUES (53,'7E',0.00,2,1,1,NULL);
INSERT INTO `A17` VALUES (54,'7F',0.00,1,1,1,NULL);
INSERT INTO `A17` VALUES (55,'7G',0.00,1,1,1,NULL);
INSERT INTO `A17` VALUES (56,'7H',0.00,2,1,1,NULL);
INSERT INTO `A17` VALUES (57,'8A',0.00,3,1,1,NULL);
INSERT INTO `A17` VALUES (58,'8B',0.00,2,1,1,NULL);
INSERT INTO `A17` VALUES (59,'8C',0.00,2,1,1,NULL);
INSERT INTO `A17` VALUES (60,'8D',0.00,3,1,1,NULL);
INSERT INTO `A17` VALUES (61,'8E',0.00,2,1,1,NULL);
INSERT INTO `A17` VALUES (62,'8F',0.00,1,1,1,NULL);
INSERT INTO `A17` VALUES (63,'8G',0.00,1,1,1,NULL);
INSERT INTO `A17` VALUES (64,'8H',0.00,2,1,1,NULL);
INSERT INTO `A17` VALUES (65,'9A',0.00,3,1,1,NULL);
INSERT INTO `A17` VALUES (66,'9B',0.00,2,1,1,NULL);
INSERT INTO `A17` VALUES (67,'9C',0.00,2,1,1,NULL);
INSERT INTO `A17` VALUES (68,'9D',0.00,3,1,1,NULL);
INSERT INTO `A17` VALUES (69,'9E',0.00,2,1,1,NULL);
INSERT INTO `A17` VALUES (70,'9F',0.00,1,1,1,NULL);
INSERT INTO `A17` VALUES (71,'9G',0.00,1,1,1,NULL);
INSERT INTO `A17` VALUES (72,'9H',0.00,2,1,1,NULL);
INSERT INTO `A17` VALUES (73,'10A',0.00,3,1,1,NULL);
INSERT INTO `A17` VALUES (74,'10B',0.00,2,1,1,NULL);
INSERT INTO `A17` VALUES (75,'10C',0.00,2,1,1,NULL);
INSERT INTO `A17` VALUES (76,'10D',0.00,3,1,1,NULL);
INSERT INTO `A17` VALUES (77,'10E',0.00,2,1,1,NULL);
INSERT INTO `A17` VALUES (78,'10F',0.00,1,1,1,NULL);
INSERT INTO `A17` VALUES (79,'10G',0.00,1,0,0,NULL);
INSERT INTO `A17` VALUES (80,'10H',0.00,2,1,1,NULL);
INSERT INTO `A17` VALUES (81,'11A',0.00,3,1,1,NULL);
INSERT INTO `A17` VALUES (82,'11B',0.00,2,1,1,NULL);
INSERT INTO `A17` VALUES (83,'11C',0.00,2,1,1,NULL);
INSERT INTO `A17` VALUES (84,'11D',0.00,3,1,1,NULL);
INSERT INTO `A17` VALUES (85,'11E',0.00,2,1,1,NULL);
INSERT INTO `A17` VALUES (86,'11F',0.00,1,1,1,NULL);
INSERT INTO `A17` VALUES (87,'11G',0.00,1,1,1,NULL);
INSERT INTO `A17` VALUES (88,'11H',0.00,2,1,1,NULL);
INSERT INTO `A17` VALUES (89,'12A',0.00,3,1,1,NULL);
INSERT INTO `A17` VALUES (90,'12B',0.00,2,1,1,NULL);
INSERT INTO `A17` VALUES (91,'12C',0.00,2,1,1,NULL);
INSERT INTO `A17` VALUES (92,'12D',0.00,3,1,1,NULL);
INSERT INTO `A17` VALUES (93,'12E',0.00,2,1,1,NULL);
INSERT INTO `A17` VALUES (94,'12F',0.00,1,1,1,NULL);
INSERT INTO `A17` VALUES (95,'12G',0.00,1,1,1,NULL);
INSERT INTO `A17` VALUES (96,'12H',0.00,2,1,1,NULL);
INSERT INTO `A17` VALUES (97,'13A',0.00,3,1,1,NULL);
INSERT INTO `A17` VALUES (98,'13B',0.00,2,1,1,NULL);
INSERT INTO `A17` VALUES (99,'13C',0.00,2,1,1,NULL);
INSERT INTO `A17` VALUES (100,'13D',0.00,3,1,1,NULL);
INSERT INTO `A17` VALUES (101,'13E',0.00,2,1,1,NULL);
INSERT INTO `A17` VALUES (102,'13F',0.00,1,1,1,NULL);
INSERT INTO `A17` VALUES (103,'13G',0.00,1,1,1,NULL);
INSERT INTO `A17` VALUES (104,'13H',0.00,2,1,1,NULL);
INSERT INTO `A17` VALUES (105,'14A',0.00,3,1,1,NULL);
INSERT INTO `A17` VALUES (106,'14B',0.00,2,1,1,NULL);
INSERT INTO `A17` VALUES (107,'14C',0.00,2,1,1,NULL);
INSERT INTO `A17` VALUES (108,'14D',0.00,3,1,1,NULL);
INSERT INTO `A17` VALUES (109,'14E',0.00,2,1,1,NULL);
INSERT INTO `A17` VALUES (110,'14F',0.00,1,1,1,NULL);
INSERT INTO `A17` VALUES (111,'14G',0.00,1,1,1,NULL);
INSERT INTO `A17` VALUES (112,'14H',0.00,2,1,1,NULL);
INSERT INTO `A17` VALUES (113,'15A',0.00,3,1,1,NULL);
INSERT INTO `A17` VALUES (114,'15B',0.00,2,1,1,NULL);
INSERT INTO `A17` VALUES (115,'15C',0.00,2,1,1,NULL);
INSERT INTO `A17` VALUES (116,'15D',0.00,3,1,1,NULL);
INSERT INTO `A17` VALUES (117,'15E',0.00,2,1,1,NULL);
INSERT INTO `A17` VALUES (118,'15F',0.00,1,1,1,NULL);
INSERT INTO `A17` VALUES (119,'15G',0.00,1,1,1,NULL);
INSERT INTO `A17` VALUES (120,'15H',0.00,2,1,1,NULL);
/*!40000 ALTER TABLE `A17` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `accounts`
--

DROP TABLE IF EXISTS `accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `accounts` (
  `acc_id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `acc_name` varchar(200) COLLATE utf8_spanish_ci NOT NULL,
  `acc_balance` decimal(10,2) NOT NULL DEFAULT '0.00',
  `acc_type` int(1) unsigned NOT NULL COMMENT 'Cuenta principal, caja chica',
  `acc_user` smallint(5) unsigned NOT NULL COMMENT 'Responsable de la cuenta',
  `acc_max` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT 'Aplica si es caja chica',
  `acc_creator` varchar(30) COLLATE utf8_spanish_ci NOT NULL DEFAULT 'N/D' COMMENT 'El creador de la cuenta',
  `acc_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`acc_id`),
  KEY `acc_user` (`acc_user`),
  KEY `acc_name` (`acc_name`),
  CONSTRAINT `accounts_ibfk_1` FOREIGN KEY (`acc_user`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci COMMENT='Cuentas y cajas chicas en uso';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accounts`
--

LOCK TABLES `accounts` WRITE;
/*!40000 ALTER TABLE `accounts` DISABLE KEYS */;
INSERT INTO `accounts` VALUES (1,'BDV CC 0102-0422-18-0000011238',89017.00,1,2,0.00,'DV','2017-05-08 16:30:24');
INSERT INTO `accounts` VALUES (2,'CAJA CHICA 1',37000.00,2,30,25000.00,'N/D','2017-05-08 16:31:52');
/*!40000 ALTER TABLE `accounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `banks`
--

DROP TABLE IF EXISTS `banks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `banks` (
  `bank_id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `bank_name` varchar(50) NOT NULL,
  `bank_rif` varchar(1) DEFAULT NULL,
  `bank_op` int(1) DEFAULT NULL COMMENT 'Indicador para uso futuro',
  PRIMARY KEY (`bank_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `banks`
--

LOCK TABLES `banks` WRITE;
/*!40000 ALTER TABLE `banks` DISABLE KEYS */;
INSERT INTO `banks` VALUES (1,'Banco Bicentenario, C.A.',NULL,NULL);
INSERT INTO `banks` VALUES (2,'Banco de Venezuela, S.A.',NULL,NULL);
INSERT INTO `banks` VALUES (3,'Banco del Tesoro, C.A.',NULL,NULL);
INSERT INTO `banks` VALUES (4,'Banco Provincial, S.A.',NULL,NULL);
INSERT INTO `banks` VALUES (5,'Banesco Banco Universal, C.A',NULL,NULL);
INSERT INTO `banks` VALUES (6,'BFC Banco Fondo Común, C.A.',NULL,NULL);
INSERT INTO `banks` VALUES (7,'Mercantil, C.A.',NULL,NULL);
INSERT INTO `banks` VALUES (8,'Banco Nacional de Crédito, C.A.',NULL,NULL);
INSERT INTO `banks` VALUES (9,'Banco Occidental de Descuento C.A.',NULL,NULL);
/*!40000 ALTER TABLE `banks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bills`
--

DROP TABLE IF EXISTS `bills`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bills` (
  `bil_id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `bil_date` date NOT NULL COMMENT 'Fecha de la factura',
  `bil_class` varchar(50) COLLATE utf8_spanish_ci NOT NULL DEFAULT 'N/D' COMMENT 'Materiales, Sueldos, Proveedores Registrados',
  `bil_desc` varchar(300) COLLATE utf8_spanish_ci NOT NULL DEFAULT 'N/D' COMMENT 'Nombre o Razon Social',
  `bil_name` varchar(100) COLLATE utf8_spanish_ci NOT NULL COMMENT 'Nombre o razon social',
  `bil_rif` varchar(10) COLLATE utf8_spanish_ci DEFAULT NULL COMMENT 'Rif o CI',
  `bil_fk_account` tinyint(3) unsigned NOT NULL COMMENT 'Cuenta principal, Caja chica',
  `bil_method` varchar(30) COLLATE utf8_spanish_ci NOT NULL COMMENT 'TDC, TDD, Transferencia o con caja chica',
  `bil_log` varchar(30) COLLATE utf8_spanish_ci NOT NULL DEFAULT 'N/D' COMMENT 'Factura, recibo de pago',
  `bil_lapse_fk` int(3) unsigned NOT NULL DEFAULT '1' COMMENT 'Periodo de facturacion',
  `bil_amount` decimal(10,2) NOT NULL,
  `bil_iva` decimal(10,2) NOT NULL,
  `bil_total` decimal(10,2) NOT NULL,
  `bil_user` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `bil_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`bil_id`),
  KEY `bil_lapse_fk` (`bil_lapse_fk`),
  KEY `bil_fk_method` (`bil_fk_account`),
  CONSTRAINT `bills_ibfk_2` FOREIGN KEY (`bil_lapse_fk`) REFERENCES `lapses` (`lap_id`),
  CONSTRAINT `bills_ibfk_3` FOREIGN KEY (`bil_fk_account`) REFERENCES `accounts` (`acc_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci COMMENT='Facturas de gastos realizados';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bills`
--

LOCK TABLES `bills` WRITE;
/*!40000 ALTER TABLE `bills` DISABLE KEYS */;
INSERT INTO `bills` VALUES (1,'2017-03-13','SERVICIOS','N/D','Hidrológica de la Regio Capital, C.A. (HIDROCAPITAL)','G200121076',2,'CAJA CHICA','COMPROBANTE',3,10000.00,1200.00,11200.00,'DV','2017-05-08 17:13:25');
INSERT INTO `bills` VALUES (2,'2017-03-15','SERVICIOS','N/D','Corporacición Eléctrica Nacional, S.A. (CORPOELEC)','G200100141',1,'CHEQUE','RECIBO',3,1000.00,120.00,1120.00,'DV','2017-05-08 17:13:25');
INSERT INTO `bills` VALUES (3,'2017-03-16','MATERIALES','Compra de 10 bombillos para los pasillos','Consorcio de Ferreterías Comerciales EPA C.A.','J000000456',1,'TDD','FACTURA',3,34983.00,4197.96,39180.96,'DV','2017-05-08 17:17:16');
INSERT INTO `bills` VALUES (4,'2017-03-30','PERSONAL','Sueldo Quincenal','María Laura Mora Torta','V13900343',1,'TRANSFERENCIA','RECIBO',3,60500.00,0.00,60500.00,'DV','2017-05-08 17:19:40');
INSERT INTO `bills` VALUES (5,'2017-03-30','SERVICIOS','N/D','Servicios y Proyectos Cosmonauta C.A.','J000456789',1,'TRANSFERENCIA','RECIBO',3,19800.00,2376.00,22176.00,'DV','2017-05-08 17:39:57');
INSERT INTO `bills` VALUES (6,'2017-04-26','SERVICIOS','N/D','Hidrológica de la Regio Capital, C.A. (HIDROCAPITAL)','G200121076',2,'CAJA CHICA','RECIBO',4,9609.00,1153.08,10762.08,'DV','2017-05-08 17:44:01');
INSERT INTO `bills` VALUES (7,'2017-04-28','SERVICIOS','N/D','Corporacición Eléctrica Nacional, S.A. (CORPOELEC)','G200100141',1,'PAGO ELECTRONICO','RECIBO',4,860.00,103.20,963.20,'DV','2017-05-08 17:46:08');
INSERT INTO `bills` VALUES (8,'2017-04-05','MATERIALES','Compra de paquete de bolsas de basura y productos de limpieza del mes','Consorcio de Ferreterías Comerciales EPA C.A.','J000000456',2,'CAJA CHICA','FACTURA',4,7468.00,896.16,8364.16,'DV','2017-05-08 17:48:54');
INSERT INTO `bills` VALUES (9,'2017-04-05','BIENES','Compra de manguera de 100 m','Consorcio de Ferreterías Comerciales EPA C.A.','J000000456',1,'TDD','FACTURA',4,36300.00,4356.00,40656.00,'DV','2017-05-08 17:50:46');
INSERT INTO `bills` VALUES (10,'2017-05-01','SERVICIOS','Mantenimiento de ascensores','Proyectos Técnicos, S.A.','J311429506',1,'TRANSFERENCIA','N/D',4,12000.00,1440.00,13440.00,'DV','2017-05-08 17:52:41');
INSERT INTO `bills` VALUES (11,'2017-04-30','SERVICIOS','N/D','Servicios y Proyectos Cosmonauta C.A.','J000456789',1,'TRANSFERENCIA','FACTURA',4,19800.00,2376.00,22176.00,'DV','2017-05-08 17:55:00');
INSERT INTO `bills` VALUES (12,'2017-04-30','PERSONAL','Sueldo','María Laura Mora Torta','V13900343',2,'CAJA CHICA','RECIBO',4,60500.00,0.00,60500.00,'DV','2017-05-08 17:56:36');
/*!40000 ALTER TABLE `bills` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `bil_account_dec` AFTER INSERT ON `bills` FOR EACH ROW UPDATE accounts SET acc_balance = (acc_balance - NEW.bil_total) WHERE acc_id = NEW.bil_fk_account */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `charges`
--

DROP TABLE IF EXISTS `charges`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `charges` (
  `cha_id` int(8) unsigned NOT NULL AUTO_INCREMENT,
  `cha_fk_number` tinyint(3) unsigned NOT NULL,
  `cha_amount` decimal(10,2) NOT NULL COMMENT 'Cantidad a cobrar o pagada',
  `cha_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `cha_user` varchar(50) CHARACTER SET utf32 COLLATE utf32_spanish_ci NOT NULL,
  PRIMARY KEY (`cha_id`),
  KEY `cha_fk_number` (`cha_fk_number`)
) ENGINE=InnoDB AUTO_INCREMENT=122 DEFAULT CHARSET=utf8 COMMENT='Se lleva el balance de cobros';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `charges`
--

LOCK TABLES `charges` WRITE;
/*!40000 ALTER TABLE `charges` DISABLE KEYS */;
INSERT INTO `charges` VALUES (1,1,2729.64,'2017-04-23 01:33:23','diego');
INSERT INTO `charges` VALUES (2,2,1819.75,'2017-04-23 01:33:23','diego');
INSERT INTO `charges` VALUES (3,3,1819.75,'2017-04-23 01:33:23','diego');
INSERT INTO `charges` VALUES (4,4,2729.64,'2017-04-23 01:33:23','diego');
INSERT INTO `charges` VALUES (5,5,1819.75,'2017-04-23 01:33:23','diego');
INSERT INTO `charges` VALUES (6,6,909.89,'2017-04-23 01:33:23','diego');
INSERT INTO `charges` VALUES (7,7,909.89,'2017-04-23 01:33:23','diego');
INSERT INTO `charges` VALUES (8,8,1819.75,'2017-04-23 01:33:23','diego');
INSERT INTO `charges` VALUES (9,9,2729.64,'2017-04-23 01:33:23','diego');
INSERT INTO `charges` VALUES (10,10,1819.75,'2017-04-23 01:33:23','diego');
INSERT INTO `charges` VALUES (11,11,1819.75,'2017-04-23 01:33:23','diego');
INSERT INTO `charges` VALUES (12,12,2729.64,'2017-04-23 01:33:23','diego');
INSERT INTO `charges` VALUES (13,13,1819.75,'2017-04-23 01:33:24','diego');
INSERT INTO `charges` VALUES (14,14,909.89,'2017-04-23 01:33:24','diego');
INSERT INTO `charges` VALUES (15,15,909.89,'2017-04-23 01:33:24','diego');
INSERT INTO `charges` VALUES (16,16,1819.75,'2017-04-23 01:33:24','diego');
INSERT INTO `charges` VALUES (17,17,2729.64,'2017-04-23 01:33:24','diego');
INSERT INTO `charges` VALUES (18,18,1819.75,'2017-04-23 01:33:24','diego');
INSERT INTO `charges` VALUES (19,19,1819.75,'2017-04-23 01:33:24','diego');
INSERT INTO `charges` VALUES (20,20,2729.64,'2017-04-23 01:33:24','diego');
INSERT INTO `charges` VALUES (21,21,1819.75,'2017-04-23 01:33:24','diego');
INSERT INTO `charges` VALUES (22,22,909.89,'2017-04-23 01:33:24','diego');
INSERT INTO `charges` VALUES (23,23,909.89,'2017-04-23 01:33:24','diego');
INSERT INTO `charges` VALUES (24,24,1819.75,'2017-04-23 01:33:24','diego');
INSERT INTO `charges` VALUES (25,25,2729.64,'2017-04-23 01:33:24','diego');
INSERT INTO `charges` VALUES (26,26,1819.75,'2017-04-23 01:33:24','diego');
INSERT INTO `charges` VALUES (27,27,1819.75,'2017-04-23 01:33:24','diego');
INSERT INTO `charges` VALUES (28,28,2729.64,'2017-04-23 01:33:24','diego');
INSERT INTO `charges` VALUES (29,29,1819.75,'2017-04-23 01:33:24','diego');
INSERT INTO `charges` VALUES (30,30,909.89,'2017-04-23 01:33:24','diego');
INSERT INTO `charges` VALUES (31,31,909.89,'2017-04-23 01:33:24','diego');
INSERT INTO `charges` VALUES (32,32,1819.75,'2017-04-23 01:33:24','diego');
INSERT INTO `charges` VALUES (33,33,2729.64,'2017-04-23 01:33:24','diego');
INSERT INTO `charges` VALUES (34,34,1819.75,'2017-04-23 01:33:24','diego');
INSERT INTO `charges` VALUES (35,35,1819.75,'2017-04-23 01:33:24','diego');
INSERT INTO `charges` VALUES (36,36,2729.64,'2017-04-23 01:33:24','diego');
INSERT INTO `charges` VALUES (37,37,1819.75,'2017-04-23 01:33:24','diego');
INSERT INTO `charges` VALUES (38,38,909.89,'2017-04-23 01:33:24','diego');
INSERT INTO `charges` VALUES (39,39,909.89,'2017-04-23 01:33:24','diego');
INSERT INTO `charges` VALUES (40,40,1819.75,'2017-04-23 01:33:24','diego');
INSERT INTO `charges` VALUES (41,41,2729.64,'2017-04-23 01:33:24','diego');
INSERT INTO `charges` VALUES (42,42,1819.75,'2017-04-23 01:33:24','diego');
INSERT INTO `charges` VALUES (43,43,1819.75,'2017-04-23 01:33:24','diego');
INSERT INTO `charges` VALUES (44,44,2729.64,'2017-04-23 01:33:24','diego');
INSERT INTO `charges` VALUES (45,45,1819.75,'2017-04-23 01:33:24','diego');
INSERT INTO `charges` VALUES (46,46,909.89,'2017-04-23 01:33:24','diego');
INSERT INTO `charges` VALUES (47,47,909.89,'2017-04-23 01:33:24','diego');
INSERT INTO `charges` VALUES (48,48,1819.75,'2017-04-23 01:33:25','diego');
INSERT INTO `charges` VALUES (49,49,2729.64,'2017-04-23 01:33:25','diego');
INSERT INTO `charges` VALUES (50,50,1819.75,'2017-04-23 01:33:25','diego');
INSERT INTO `charges` VALUES (51,51,1819.75,'2017-04-23 01:33:25','diego');
INSERT INTO `charges` VALUES (52,52,2729.64,'2017-04-23 01:33:25','diego');
INSERT INTO `charges` VALUES (53,53,1819.75,'2017-04-23 01:33:25','diego');
INSERT INTO `charges` VALUES (54,54,909.89,'2017-04-23 01:33:25','diego');
INSERT INTO `charges` VALUES (55,55,909.89,'2017-04-23 01:33:25','diego');
INSERT INTO `charges` VALUES (56,56,1819.75,'2017-04-23 01:33:25','diego');
INSERT INTO `charges` VALUES (57,57,2729.64,'2017-04-23 01:33:25','diego');
INSERT INTO `charges` VALUES (58,58,1819.75,'2017-04-23 01:33:25','diego');
INSERT INTO `charges` VALUES (59,59,1819.75,'2017-04-23 01:33:25','diego');
INSERT INTO `charges` VALUES (60,60,2729.64,'2017-04-23 01:33:25','diego');
INSERT INTO `charges` VALUES (61,61,1819.75,'2017-04-23 01:33:25','diego');
INSERT INTO `charges` VALUES (62,62,909.89,'2017-04-23 01:33:25','diego');
INSERT INTO `charges` VALUES (63,63,909.89,'2017-04-23 01:33:25','diego');
INSERT INTO `charges` VALUES (64,64,1819.75,'2017-04-23 01:33:25','diego');
INSERT INTO `charges` VALUES (65,65,2729.64,'2017-04-23 01:33:25','diego');
INSERT INTO `charges` VALUES (66,66,1819.75,'2017-04-23 01:33:25','diego');
INSERT INTO `charges` VALUES (67,67,1819.75,'2017-04-23 01:33:25','diego');
INSERT INTO `charges` VALUES (68,68,2729.64,'2017-04-23 01:33:25','diego');
INSERT INTO `charges` VALUES (69,69,1819.75,'2017-04-23 01:33:25','diego');
INSERT INTO `charges` VALUES (70,70,909.89,'2017-04-23 01:33:25','diego');
INSERT INTO `charges` VALUES (71,71,909.89,'2017-04-23 01:33:25','diego');
INSERT INTO `charges` VALUES (72,72,1819.75,'2017-04-23 01:33:25','diego');
INSERT INTO `charges` VALUES (73,73,2729.64,'2017-04-23 01:33:25','diego');
INSERT INTO `charges` VALUES (74,74,1819.75,'2017-04-23 01:33:25','diego');
INSERT INTO `charges` VALUES (75,75,1819.75,'2017-04-23 01:33:25','diego');
INSERT INTO `charges` VALUES (76,76,2729.64,'2017-04-23 01:33:25','diego');
INSERT INTO `charges` VALUES (77,77,1819.75,'2017-04-23 01:33:25','diego');
INSERT INTO `charges` VALUES (78,78,909.89,'2017-04-23 01:33:26','diego');
INSERT INTO `charges` VALUES (79,79,909.89,'2017-04-23 01:33:26','diego');
INSERT INTO `charges` VALUES (80,80,1819.75,'2017-04-23 01:33:26','diego');
INSERT INTO `charges` VALUES (81,81,2729.64,'2017-04-23 01:33:26','diego');
INSERT INTO `charges` VALUES (82,82,1819.75,'2017-04-23 01:33:26','diego');
INSERT INTO `charges` VALUES (83,83,1819.75,'2017-04-23 01:33:26','diego');
INSERT INTO `charges` VALUES (84,84,2729.64,'2017-04-23 01:33:26','diego');
INSERT INTO `charges` VALUES (85,85,1819.75,'2017-04-23 01:33:26','diego');
INSERT INTO `charges` VALUES (86,86,909.89,'2017-04-23 01:33:26','diego');
INSERT INTO `charges` VALUES (87,87,909.89,'2017-04-23 01:33:26','diego');
INSERT INTO `charges` VALUES (88,88,1819.75,'2017-04-23 01:33:26','diego');
INSERT INTO `charges` VALUES (89,89,2729.64,'2017-04-23 01:33:26','diego');
INSERT INTO `charges` VALUES (90,90,1819.75,'2017-04-23 01:33:26','diego');
INSERT INTO `charges` VALUES (91,91,1819.75,'2017-04-23 01:33:26','diego');
INSERT INTO `charges` VALUES (92,92,2729.64,'2017-04-23 01:33:26','diego');
INSERT INTO `charges` VALUES (93,93,1819.75,'2017-04-23 01:33:26','diego');
INSERT INTO `charges` VALUES (94,94,909.89,'2017-04-23 01:33:26','diego');
INSERT INTO `charges` VALUES (95,95,909.89,'2017-04-23 01:33:26','diego');
INSERT INTO `charges` VALUES (96,96,1819.75,'2017-04-23 01:33:26','diego');
INSERT INTO `charges` VALUES (97,97,2729.64,'2017-04-23 01:33:26','diego');
INSERT INTO `charges` VALUES (98,98,1819.75,'2017-04-23 01:33:26','diego');
INSERT INTO `charges` VALUES (99,99,1819.75,'2017-04-23 01:33:26','diego');
INSERT INTO `charges` VALUES (100,100,2729.64,'2017-04-23 01:33:26','diego');
INSERT INTO `charges` VALUES (101,101,1819.75,'2017-04-23 01:33:26','diego');
INSERT INTO `charges` VALUES (102,102,909.89,'2017-04-23 01:33:26','diego');
INSERT INTO `charges` VALUES (103,103,909.89,'2017-04-23 01:33:26','diego');
INSERT INTO `charges` VALUES (104,104,1819.75,'2017-04-23 01:33:26','diego');
INSERT INTO `charges` VALUES (105,105,2729.64,'2017-04-23 01:33:26','diego');
INSERT INTO `charges` VALUES (106,106,1819.75,'2017-04-23 01:33:26','diego');
INSERT INTO `charges` VALUES (107,107,1819.75,'2017-04-23 01:33:26','diego');
INSERT INTO `charges` VALUES (108,108,2729.64,'2017-04-23 01:33:26','diego');
INSERT INTO `charges` VALUES (109,109,1819.75,'2017-04-23 01:33:26','diego');
INSERT INTO `charges` VALUES (110,110,909.89,'2017-04-23 01:33:26','diego');
INSERT INTO `charges` VALUES (111,111,909.89,'2017-04-23 01:33:26','diego');
INSERT INTO `charges` VALUES (112,112,1819.75,'2017-04-23 01:33:27','diego');
INSERT INTO `charges` VALUES (113,113,2729.64,'2017-04-23 01:33:27','diego');
INSERT INTO `charges` VALUES (114,114,1819.75,'2017-04-23 01:33:27','diego');
INSERT INTO `charges` VALUES (115,115,1819.75,'2017-04-23 01:33:27','diego');
INSERT INTO `charges` VALUES (116,116,2729.64,'2017-04-23 01:33:27','diego');
INSERT INTO `charges` VALUES (117,117,1819.75,'2017-04-23 01:33:27','diego');
INSERT INTO `charges` VALUES (118,118,909.89,'2017-04-23 01:33:27','diego');
INSERT INTO `charges` VALUES (119,119,909.89,'2017-04-23 01:33:27','diego');
INSERT INTO `charges` VALUES (120,120,1819.75,'2017-04-23 01:33:27','diego');
INSERT INTO `charges` VALUES (121,78,-2000.00,'2017-04-23 01:35:52','diego');
/*!40000 ALTER TABLE `charges` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `charges_set_balance` AFTER INSERT ON `charges` FOR EACH ROW UPDATE A17 SET A17_balance = (SELECT SUM(cha_amount) FROM charges WHERE cha_fk_number = NEW.cha_fk_number) WHERE A17_id = NEW.cha_fk_number */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `db_logs`
--

DROP TABLE IF EXISTS `db_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `db_logs` (
  `logs_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `logs_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `logs_user` varchar(50) NOT NULL,
  `log_query` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`logs_id`)
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `db_logs`
--

LOCK TABLES `db_logs` WRITE;
/*!40000 ALTER TABLE `db_logs` DISABLE KEYS */;
INSERT INTO `db_logs` VALUES (1,'2017-04-09 04:08:56','login:admin@caracol','SELECT user_user, user_pwd, user_type FROM users WHERE user_user = \'admin@caracol\' AND user_pwd = \'1234\'');
INSERT INTO `db_logs` VALUES (2,'2017-04-09 04:11:25','admin@caracol','SELECT user_id FROM users WHERE user_user = \'gab@bat\'');
INSERT INTO `db_logs` VALUES (3,'2017-04-09 04:11:26','admin@caracol','INSERT INTO users VALUES (NULL, \'gab@bat\', \'1234\', \'2\', \'admin@caracol\', NULL)');
INSERT INTO `db_logs` VALUES (4,'2017-04-09 04:11:26','admin@caracol','SELECT user_id FROM users WHERE user_user = \'gab@bat\'');
INSERT INTO `db_logs` VALUES (5,'2017-04-09 04:11:26','admin@caracol','INSERT INTO userdata VALUES (NULL, \'Gabriel\', \'Batistuta\', \'e80111234\', \'1A\', 1)');
INSERT INTO `db_logs` VALUES (6,'2017-04-09 04:12:40','admin@caracol','SELECT user_id FROM users WHERE user_user = \'admin@caracol\'');
INSERT INTO `db_logs` VALUES (7,'2017-04-09 04:12:40','admin@caracol','INSERT INTO users VALUES (NULL, \'admin@caracol\', \'1234\', \'1\', \'admin@caracol\', NULL)');
INSERT INTO `db_logs` VALUES (8,'2017-04-09 04:12:40','admin@caracol','SELECT user_id FROM users WHERE user_user = \'admin@caracol\'');
INSERT INTO `db_logs` VALUES (9,'2017-04-09 04:12:40','admin@caracol','INSERT INTO userdata VALUES (NULL, \'Stalin\', \'Rivas\', \'v9456345\', \'9H\', 2)');
INSERT INTO `db_logs` VALUES (10,'2017-04-09 04:18:51','admin@caracol','INSERT INTO users VALUES (NULL, \'guest@caracol\', \'1234\', \'2\', \'admin@caracol\', NULL)');
INSERT INTO `db_logs` VALUES (11,'2017-04-09 05:24:53','admin@caracol','INSERT INTO users VALUES (NULL, \'un@correo\', \'1234\', \'2\', 1, \'admin@caracol\', NULL)');
INSERT INTO `db_logs` VALUES (13,'2017-04-09 14:21:54','register:$email','INSERT INTO users VALUES (NULL, \'salo@correo\', \'1234\', 2, 0, \'register:salo@correo\', NULL)');
INSERT INTO `db_logs` VALUES (14,'2017-04-09 14:23:10','register:$email','INSERT INTO users VALUES (NULL, \'paolo@correo\', \'1234\', 2, 0, \'register:paolo@correo\', NULL)');
INSERT INTO `db_logs` VALUES (15,'2017-04-09 15:46:33','admin@caracol','UPDATE users SET user_active = 1 WHERE user_user = \'gab@bat\' OR user_user = \'salo@correo\' ');
INSERT INTO `db_logs` VALUES (16,'2017-04-09 16:17:34','register:$email','INSERT INTO users VALUES (NULL, \'pa@cor\', \'1234\', 2, 0, \'register:pa@cor\', NULL)');
INSERT INTO `db_logs` VALUES (17,'2017-04-09 16:18:05','register:$email','INSERT INTO users VALUES (NULL, \'mari@marara\', \'1234\', 2, 0, \'register:mari@marara\', NULL)');
INSERT INTO `db_logs` VALUES (18,'2017-04-09 16:18:40','admin@caracol','UPDATE users SET user_active = 1 WHERE user_user = \'gab@bat\' ');
INSERT INTO `db_logs` VALUES (19,'2017-04-09 16:20:58','admin@caracol','UPDATE users SET user_active = 1 WHERE user_user = \'gab@bat\' ');
INSERT INTO `db_logs` VALUES (20,'2017-04-09 16:50:14','admin@caracol','DELETE FROM users WHERE user_user = \'pa@cor\' OR user_user = \'mari@marara\' ');
INSERT INTO `db_logs` VALUES (21,'2017-04-09 16:55:26','admin@caracol','UPDATE users SET user_active = 1 WHERE user_user = \'salo@correo\' ');
INSERT INTO `db_logs` VALUES (22,'2017-04-09 16:55:47','register:$email','INSERT INTO users VALUES (NULL, \'che@ge\', \'1234\', 2, 0, \'register:che@ge\', NULL)');
INSERT INTO `db_logs` VALUES (23,'2017-04-09 16:56:04','admin@caracol','DELETE FROM users WHERE user_user = \'che@ge\' ');
INSERT INTO `db_logs` VALUES (24,'2017-04-12 15:51:55','admin@caracol','INSERT INTO bills VALUES (NULL, \'2017-04-12\', \'Corporacición Eléctrica Nacional, S.A. (CORPOELEC)\', \'G200100141\', \'2\', \'4\', \'1111\', \'133.32\', \'1244.32\', \'1\', \'\', \'admin@caracol\', NULL)');
INSERT INTO `db_logs` VALUES (25,'2017-04-12 15:55:08','admin@caracol','INSERT INTO bills VALUES (NULL, \'2017-04-11\', \'Pedro Perez\', \'V12331313\', \'1\', \'3\', \'12121.21\', \'1454.55\', \'13575.76\', \'2\', \'El señor se róbo la desmalezadora\', \'admin@caracol\', NULL)');
INSERT INTO `db_logs` VALUES (26,'2017-04-13 01:37:06','register:$email','INSERT INTO users VALUES (NULL, \'dennis@berk\', \'1234\', 2, 0, \'register:dennis@berk\', NULL)');
INSERT INTO `db_logs` VALUES (27,'2017-04-13 14:51:09','admin@caracol','INSERT INTO users VALUES (NULL, \'oleg@caracol\', \'1234\', \'1\', 1, \'admin@caracol\', NULL)');
INSERT INTO `db_logs` VALUES (28,'2017-04-13 14:54:20','admin@caracol','INSERT INTO users VALUES (NULL, \'oleg@correo\', \'1234\', \'1\', 1, \'admin@caracol\', NULL)');
INSERT INTO `db_logs` VALUES (29,'2017-04-13 14:55:30','admin@caracol','INSERT INTO users VALUES (NULL, \'ole@correo\', \'1234\', \'1\', 1, \'admin@caracol\', NULL)');
INSERT INTO `db_logs` VALUES (30,'2017-04-13 23:56:30','admin@caracol','INSERT INTO users VALUES (NULL, \'u1n@correo\', \'1234\', \'2\', 1, \'admin@caracol\', NULL)');
INSERT INTO `db_logs` VALUES (31,'2017-04-14 00:20:10','admin@caracol','INSERT INTO users VALUES (NULL, \'cheto@correo\', \'1234\', \'2\', 1, \'admin@caracol\', NULL)');
INSERT INTO `db_logs` VALUES (32,'2017-04-14 00:24:58','admin@caracol','INSERT INTO users VALUES (NULL, \'pun@correo\', \'1234\', \'1\', 1, \'admin@caracol\', NULL)');
INSERT INTO `db_logs` VALUES (33,'2017-04-14 00:26:04','admin@caracol','INSERT INTO users VALUES (NULL, \'pun@correo\', \'1234\', \'1\', 1, \'admin@caracol\', NULL)');
INSERT INTO `db_logs` VALUES (34,'2017-04-14 00:28:04','admin@caracol','INSERT INTO users VALUES (NULL, \'pun@correo\', \'1234\', \'1\', 1, \'admin@caracol\', NULL)');
INSERT INTO `db_logs` VALUES (35,'2017-04-14 00:29:05','admin@caracol','INSERT INTO users VALUES (NULL, \'pun@correo\', \'1234\', \'1\', 1, \'admin@caracol\', NULL)');
INSERT INTO `db_logs` VALUES (36,'2017-04-14 00:29:37','admin@caracol','INSERT INTO users VALUES (NULL, \'pun@correo\', \'1234\', \'1\', 1, \'admin@caracol\', NULL)');
INSERT INTO `db_logs` VALUES (37,'2017-04-14 00:32:02','admin@caracol','INSERT INTO users VALUES (NULL, \'pun@correo\', \'1234\', \'1\', 1, \'admin@caracol\', NULL)');
INSERT INTO `db_logs` VALUES (38,'2017-04-14 00:34:00','admin@caracol','INSERT INTO users VALUES (NULL, \'pun@correo\', \'1234\', \'1\', 1, \'admin@caracol\', NULL)');
INSERT INTO `db_logs` VALUES (39,'2017-04-14 00:37:04','admin@caracol','INSERT INTO users VALUES (NULL, \'pun@correo\', \'1234\', \'1\', 1, \'admin@caracol\', NULL)');
INSERT INTO `db_logs` VALUES (40,'2017-04-14 00:39:44','admin@caracol','INSERT INTO users VALUES (NULL, \'pun@correo\', \'1234\', \'1\', 1, \'admin@caracol\', NULL)');
INSERT INTO `db_logs` VALUES (41,'2017-04-14 00:42:23','admin@caracol','INSERT INTO users VALUES (NULL, \'pun@correo\', \'1234\', \'1\', 1, \'admin@caracol\', NULL)');
INSERT INTO `db_logs` VALUES (42,'2017-04-14 00:44:40','admin@caracol','INSERT INTO users VALUES (NULL, \'pun@correo\', \'1234\', \'1\', 1, \'admin@caracol\', NULL)');
INSERT INTO `db_logs` VALUES (43,'2017-04-14 00:45:55','admin@caracol','INSERT INTO users VALUES (NULL, \'pun@correo\', \'1234\', \'1\', 1, \'admin@caracol\', NULL)');
INSERT INTO `db_logs` VALUES (44,'2017-04-14 00:49:53','admin@caracol','INSERT INTO users VALUES (NULL, \'pun@correo\', \'1234\', \'1\', 1, \'admin@caracol\', NULL)');
INSERT INTO `db_logs` VALUES (45,'2017-04-14 00:51:35','admin@caracol','INSERT INTO users VALUES (NULL, \'puen@correo\', \'1234\', \'2\', 1, \'admin@caracol\', NULL)');
INSERT INTO `db_logs` VALUES (46,'2017-04-14 00:55:35','admin@caracol','INSERT INTO users VALUES (NULL, \'diego@caracol\', \'1234\', \'2\', 1, \'admin@caracol\', NULL)');
INSERT INTO `db_logs` VALUES (47,'2017-04-14 01:02:17','register:$email','INSERT INTO users VALUES (NULL, \'meri@mat\', \'1234\', 2, 0, \'register:meri@mat\', NULL)');
INSERT INTO `db_logs` VALUES (48,'2017-04-14 16:43:15','register:$email','INSERT INTO users VALUES (NULL, \'luz@gmail.com\', \'1234\', 2, 0, \'register:luz@gmail.com\', NULL)');
INSERT INTO `db_logs` VALUES (49,'2017-04-14 16:43:53','admin@caracol','UPDATE users SET user_active = 1 WHERE user_user = \'luz@gmail_com\' ');
INSERT INTO `db_logs` VALUES (50,'2017-04-14 16:45:27','admin@caracol','INSERT INTO bills VALUES (NULL, \'2017-01-01\', \'Hidrológica de la Regio Capital, C.A. (HIDROCAPITAL)\', \'G200121076\', \'3\', \'4\', \'5512.12\', \'661.45\', \'6173.57\', \'1\', \'ninguna\', \'admin@caracol\', NULL)');
INSERT INTO `db_logs` VALUES (51,'2017-04-14 17:13:08','admin@caracol','INSERT INTO users VALUES (NULL, \'punn@correo\', \'1234\', \'2\', 1, \'admin@caracol\', NULL)');
INSERT INTO `db_logs` VALUES (52,'2017-04-16 17:47:36','admin@caracol','INSERT INTO bills VALUES (NULL, \'2017-04-16\', \'María Laura Mora Torta\', \'V13900343\', \'6\', \'4\', \'85\', \'0\', \'85\', \'2\', \'            \', \'admin@caracol\', NULL)');
INSERT INTO `db_logs` VALUES (53,'2017-04-16 17:48:12','admin@caracol','INSERT INTO bills VALUES (NULL, \'2017-04-15\', \'Proyectos Técnicos, S.A.\', \'J311429506\', \'5\', \'4\', \'15490.7\', \'1858.88\', \'17349.58\', \'1\', \'            \', \'admin@caracol\', NULL)');
INSERT INTO `db_logs` VALUES (54,'2017-04-16 17:49:29','admin@caracol','INSERT INTO bills VALUES (NULL, \'2017-04-13\', \'varios Proveedores\', \'J000000000\', \'7\', \'4\', \'23000\', \'2760\', \'25760\', \'1\', \'20 bolsas de basura\r\n2 lts de detergente\', \'admin@caracol\', NULL)');
INSERT INTO `db_logs` VALUES (55,'2017-04-16 17:54:38','admin@caracol','INSERT INTO bills VALUES (NULL, \'2017-04-13\', \'Hidrológica de la Regio Capital, C.A. (HIDROCAPITAL)\', \'G200121076\', \'3\', \'4\', \'8500\', \'1020\', \'9520\', \'1\', \'            \', \'admin@caracol\', NULL)');
INSERT INTO `db_logs` VALUES (56,'2017-04-16 17:56:01','admin@caracol','INSERT INTO bills VALUES (NULL, \'2017-04-16\', \'Corporacición Eléctrica Nacional, S.A. (CORPOELEC)\', \'G200100141\', \'2\', \'4\', \'60000.44\', \'7200.05\', \'67200.49\', \'1\', \'            \', \'admin@caracol\', NULL)');
INSERT INTO `db_logs` VALUES (57,'2017-04-20 19:20:59','admin@caracol','INSERT INTO payments VALUES (NULL, \'2017-04-06\', \'2\', \'2\', \'3444000\', \'4\', \'60090\', 0, \'notas\', NULL, \'2\')');
INSERT INTO `db_logs` VALUES (58,'2017-04-25 21:12:01','gab@bat','INSERT INTO payments VALUES (NULL, \'2017-04-06\', \'1\', \'2\', \'33533\', \'4\', \'1000\', 0, \'\', NULL, \'1\')');
INSERT INTO `db_logs` VALUES (59,'2017-04-25 21:22:07','gab@bat','INSERT INTO payments VALUES (NULL, \'2017-04-20\', \'1\', \'2\', \'646464\', \'1\', \'1201\', 0, \'\', NULL, \'1\')');
INSERT INTO `db_logs` VALUES (60,'2017-04-25 21:25:25','gab@bat','INSERT INTO payments VALUES (NULL, \'2017-04-01\', \'1\', \'2\', \'334434\', \'3\', \'2020\', 0, \'\', NULL, \'1\')');
/*!40000 ALTER TABLE `db_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `funds`
--

DROP TABLE IF EXISTS `funds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `funds` (
  `fun_id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `fun_name` varchar(100) NOT NULL,
  `fun_balance` decimal(10,2) NOT NULL DEFAULT '0.00',
  `fun_default` varchar(20) NOT NULL DEFAULT '0' COMMENT 'Monto a cobrar mensualmente',
  `fun_type` int(1) NOT NULL DEFAULT '1' COMMENT 'Fondo de trabajo, cuota especial',
  `fun_rel` varchar(30) NOT NULL DEFAULT 'A17' COMMENT 'Edificio al que pertenece',
  `fun_creator` varchar(30) NOT NULL DEFAULT 'N/D',
  `fun_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`fun_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='Fondos y Cuotas especiales';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `funds`
--

LOCK TABLES `funds` WRITE;
/*!40000 ALTER TABLE `funds` DISABLE KEYS */;
INSERT INTO `funds` VALUES (1,'Fondo de Trabajo',0.00,'10',1,'A17','N/D','2017-05-14 17:10:00');
INSERT INTO `funds` VALUES (2,'Cuota Especial',0.00,'50000',2,'A17','N/D','2017-05-14 17:10:00');
/*!40000 ALTER TABLE `funds` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lapses`
--

DROP TABLE IF EXISTS `lapses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lapses` (
  `lap_id` int(3) unsigned NOT NULL AUTO_INCREMENT,
  `lap_name` varchar(20) COLLATE utf8_spanish_ci NOT NULL,
  `lap_month` int(2) NOT NULL,
  `lap_year` int(4) NOT NULL,
  PRIMARY KEY (`lap_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lapses`
--

LOCK TABLES `lapses` WRITE;
/*!40000 ALTER TABLE `lapses` DISABLE KEYS */;
INSERT INTO `lapses` VALUES (1,'Enero 2017',1,2017);
INSERT INTO `lapses` VALUES (2,'Febrero 2017',2,2017);
INSERT INTO `lapses` VALUES (3,'Marzo 2017',3,2017);
INSERT INTO `lapses` VALUES (4,'Abril 2017',4,2017);
INSERT INTO `lapses` VALUES (5,'Mayo 2017',5,2017);
INSERT INTO `lapses` VALUES (6,'Junio 2017',6,2017);
INSERT INTO `lapses` VALUES (7,'Julio 2017',7,2017);
/*!40000 ALTER TABLE `lapses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `movements`
--

DROP TABLE IF EXISTS `movements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `movements` (
  `mov_id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `mov_date` date DEFAULT NULL,
  `mov_amount` decimal(10,2) unsigned NOT NULL,
  `mov_fk_origin` tinyint(3) unsigned NOT NULL,
  `mov_fk_receiver` tinyint(3) unsigned NOT NULL,
  `mov_method` varchar(30) COLLATE utf8_spanish_ci NOT NULL COMMENT 'Cheque, transferencia, deposito',
  `mov_user` varchar(30) CHARACTER SET utf8 NOT NULL DEFAULT 'N/D',
  `mov_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`mov_id`),
  KEY `mov_origin` (`mov_fk_origin`),
  KEY `mov_receiver` (`mov_fk_receiver`),
  CONSTRAINT `movements_ibfk_1` FOREIGN KEY (`mov_fk_origin`) REFERENCES `accounts` (`acc_id`),
  CONSTRAINT `movements_ibfk_2` FOREIGN KEY (`mov_fk_receiver`) REFERENCES `accounts` (`acc_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci COMMENT='Movimientos internos que no afectan el balance general';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `movements`
--

LOCK TABLES `movements` WRITE;
/*!40000 ALTER TABLE `movements` DISABLE KEYS */;
INSERT INTO `movements` VALUES (1,'2017-04-10',12000.00,1,2,'TRANSFERENCIA','N/D','2017-05-13 14:45:08');
/*!40000 ALTER TABLE `movements` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `decrement` AFTER INSERT ON `movements` FOR EACH ROW UPDATE accounts SET acc_balance = (acc_balance - NEW.mov_amount) WHERE acc_id = NEW.mov_fk_origin */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `increment` AFTER INSERT ON `movements` FOR EACH ROW UPDATE accounts SET acc_balance = (acc_balance + NEW.mov_amount) WHERE acc_id = NEW.mov_fk_receiver */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `payments`
--

DROP TABLE IF EXISTS `payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payments` (
  `pay_id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `pay_date` date NOT NULL COMMENT 'Fecha de la operacion',
  `pay_fk_number` tinyint(3) unsigned NOT NULL COMMENT 'Id Apartamento',
  `pay_type` int(1) NOT NULL COMMENT 'Tipo de operacion',
  `pay_op` mediumint(8) unsigned NOT NULL COMMENT 'Numero de operacion',
  `pay_fk_bank` tinyint(3) unsigned NOT NULL COMMENT 'Banco',
  `pay_amount` decimal(10,0) NOT NULL COMMENT 'Monto del pago',
  `pay_check` int(1) DEFAULT NULL COMMENT 'Si ya fue relacionado',
  `pay_obs` varchar(250) DEFAULT NULL COMMENT 'Observaciones',
  `pay_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `pay_fk_user` smallint(5) unsigned NOT NULL,
  PRIMARY KEY (`pay_id`),
  KEY `index_pay` (`pay_fk_user`,`pay_type`),
  KEY `pay_fk_bank` (`pay_fk_bank`),
  KEY `pay_fk_number` (`pay_fk_number`),
  CONSTRAINT `payments_ibfk_1` FOREIGN KEY (`pay_fk_number`) REFERENCES `A17` (`A17_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `payments_ibfk_2` FOREIGN KEY (`pay_fk_bank`) REFERENCES `banks` (`bank_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payments`
--

LOCK TABLES `payments` WRITE;
/*!40000 ALTER TABLE `payments` DISABLE KEYS */;
INSERT INTO `payments` VALUES (1,'2017-04-06',2,2,3444000,4,60090,1,'notas','2017-04-20 19:20:59',2);
INSERT INTO `payments` VALUES (2,'2017-03-14',33,1,102130,4,2402,0,'nada en especial','2017-04-22 19:35:22',1);
INSERT INTO `payments` VALUES (3,'2017-03-15',74,2,230012,2,1504,0,'estoy al dia','2017-04-22 19:35:22',1);
INSERT INTO `payments` VALUES (4,'2017-03-30',14,1,300012,3,3500,0,'','2017-04-22 19:35:22',1);
INSERT INTO `payments` VALUES (5,'2017-03-31',90,1,300013,2,1220,1,'ahora','2017-04-22 19:35:22',1);
INSERT INTO `payments` VALUES (6,'2017-04-02',64,1,426680,1,3800,1,'','2017-04-22 19:35:22',1);
INSERT INTO `payments` VALUES (7,'2017-04-02',80,2,300015,5,2745,2,'viva la pelona','2017-04-22 19:35:22',1);
INSERT INTO `payments` VALUES (8,'2017-04-02',45,1,300016,2,1200,0,'','2017-04-22 19:35:22',1);
INSERT INTO `payments` VALUES (9,'2017-04-04',56,1,300017,4,800,0,'','2017-04-22 19:35:23',1);
INSERT INTO `payments` VALUES (10,'2017-04-06',1,2,33533,4,1000,0,'','2017-04-25 21:12:01',1);
INSERT INTO `payments` VALUES (11,'2017-04-20',1,2,646464,1,1201,0,'','2017-04-25 21:22:07',1);
INSERT INTO `payments` VALUES (12,'2017-04-01',1,2,334434,3,2020,0,'','2017-04-25 21:25:25',1);
INSERT INTO `payments` VALUES (13,'2017-05-01',70,1,500667,9,4565,0,NULL,'2017-05-12 17:03:18',87);
INSERT INTO `payments` VALUES (14,'2017-05-02',54,1,44099,8,1891,0,NULL,'2017-05-12 17:04:59',6);
INSERT INTO `payments` VALUES (15,'2017-05-03',99,2,200,6,987,0,NULL,'2017-05-12 17:04:59',2);
/*!40000 ALTER TABLE `payments` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `payments_accounts_inc` AFTER UPDATE ON `payments` FOR EACH ROW UPDATE accounts SET acc_balance = (acc_balance + paycheck(NEW.pay_check, NEW.pay_amount)) WHERE acc_id = 1 */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `spendings_types`
--

DROP TABLE IF EXISTS `spendings_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `spendings_types` (
  `spe_id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `spe_name` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `spe_op` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`spe_id`),
  KEY `spe_name` (`spe_name`),
  KEY `spe_name_2` (`spe_name`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `spendings_types`
--

LOCK TABLES `spendings_types` WRITE;
/*!40000 ALTER TABLE `spendings_types` DISABLE KEYS */;
INSERT INTO `spendings_types` VALUES (1,'PERSONAL',0);
INSERT INTO `spendings_types` VALUES (2,'MATERIALES',0);
INSERT INTO `spendings_types` VALUES (3,'SERVICIOS',0);
INSERT INTO `spendings_types` VALUES (4,'BIENES',0);
INSERT INTO `spendings_types` VALUES (5,'LEGAL',0);
/*!40000 ALTER TABLE `spendings_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userdata`
--

DROP TABLE IF EXISTS `userdata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userdata` (
  `udata_id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `udata_name` varchar(50) NOT NULL,
  `udata_surname` varchar(50) NOT NULL,
  `udata_ci` varchar(10) NOT NULL COMMENT 'cedula o rif',
  `udata_tlf` varchar(13) DEFAULT NULL,
  `udata_gender` varchar(1) NOT NULL DEFAULT 'M',
  `udata_number_fk` tinyint(3) unsigned NOT NULL COMMENT 'numero de apartamento',
  `udata_user_fk` smallint(5) unsigned NOT NULL,
  PRIMARY KEY (`udata_id`),
  KEY `fk_user` (`udata_user_fk`),
  KEY `udata_number_fk` (`udata_number_fk`),
  CONSTRAINT `link_users` FOREIGN KEY (`udata_user_fk`) REFERENCES `users` (`user_id`),
  CONSTRAINT `userdata_ibfk_1` FOREIGN KEY (`udata_number_fk`) REFERENCES `A17` (`A17_id`)
) ENGINE=InnoDB AUTO_INCREMENT=195 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userdata`
--

LOCK TABLES `userdata` WRITE;
/*!40000 ALTER TABLE `userdata` DISABLE KEYS */;
INSERT INTO `userdata` VALUES (1,'Gabriel','Batistuta','e80111234',NULL,'M',1,1);
INSERT INTO `userdata` VALUES (2,'Stalin','Rivas','v9456345',NULL,'M',2,2);
INSERT INTO `userdata` VALUES (3,'Carlos','Valderrama','v20445632',NULL,'M',3,3);
INSERT INTO `userdata` VALUES (4,'Faustino','Asprilla','e82009342',NULL,'M',4,4);
INSERT INTO `userdata` VALUES (6,'Salomon','Rondon','v14000333',NULL,'M',5,6);
INSERT INTO `userdata` VALUES (7,'Paolo','Maldini','e83000212',NULL,'M',5,7);
INSERT INTO `userdata` VALUES (8,'Dennis Adolfo','Berkham','E80445765',NULL,'M',7,8);
INSERT INTO `userdata` VALUES (10,'Nombre','Apellido','V999999',NULL,'M',29,26);
INSERT INTO `userdata` VALUES (11,'Nombre','Apellido','V999999',NULL,'M',3,27);
INSERT INTO `userdata` VALUES (12,'Diego Jose','Viniegra Villalobos','V14891345',NULL,'M',78,28);
INSERT INTO `userdata` VALUES (13,'Meridian','Matova','E88282822',NULL,'M',78,29);
INSERT INTO `userdata` VALUES (14,'Luz Marina','Villalobos Alvarez','E81447878',NULL,'M',78,30);
INSERT INTO `userdata` VALUES (15,'nombre','apellido','v999999',NULL,'M',1,31);
INSERT INTO `userdata` VALUES (16,'Delcy','Bello','V6816747','','F',1,32);
INSERT INTO `userdata` VALUES (17,'Armando','Leon','V6835592','','M',2,33);
INSERT INTO `userdata` VALUES (18,'Ramon','Torrez','V6501771','0414-2678648','M',3,34);
INSERT INTO `userdata` VALUES (19,'Juan','Calderon','V937787','','M',4,35);
INSERT INTO `userdata` VALUES (20,'Bladimiro','Montilla','V9017289','0414-1406484','M',5,36);
INSERT INTO `userdata` VALUES (21,'Alejandro','Romero','V9941682','0414-1722014','M',6,37);
INSERT INTO `userdata` VALUES (22,'Oscar','Diaz','V9560116','0414-0110384','M',7,38);
INSERT INTO `userdata` VALUES (23,'Julian','Blanco','V6961144','0416-7141023','M',8,39);
INSERT INTO `userdata` VALUES (24,'Adon','Hernandez','V6975838','0416-3295092','M',9,40);
INSERT INTO `userdata` VALUES (25,'Rina','Vargas','V10629158','','F',10,41);
INSERT INTO `userdata` VALUES (26,'Sigris','Rivas','V10784373','0414-3349272','F',11,42);
INSERT INTO `userdata` VALUES (27,'Franklin','Gomez','V10065092','0416-7973715','M',12,43);
INSERT INTO `userdata` VALUES (28,'Edit','Nuñez','V10820207','','F',13,44);
INSERT INTO `userdata` VALUES (29,'Katiuska','Aguilar','V10822251','0416-7036249','F',14,45);
INSERT INTO `userdata` VALUES (30,'Eduardo','Guerra','V9958901','0214-2470405','M',15,46);
INSERT INTO `userdata` VALUES (31,'Aracelys','Diaz','V7474773','0416-7042602','F',16,47);
INSERT INTO `userdata` VALUES (32,'Maria','Abeijon','V942051','','F',17,48);
INSERT INTO `userdata` VALUES (33,'Leudys','Gonzalez','V10528201','0416-1726990','F',18,49);
INSERT INTO `userdata` VALUES (34,'Orlando','Graterol','V9961345','0414-2228407','M',19,50);
INSERT INTO `userdata` VALUES (35,'Marianella','Muñoz','V10788721','0416-2146611','F',20,51);
INSERT INTO `userdata` VALUES (36,'Octavio','Gutierrez','E8185146','','M',21,52);
INSERT INTO `userdata` VALUES (37,'Carlos','Aguilera','V9280761','0414-3363262','M',22,53);
INSERT INTO `userdata` VALUES (38,'Gustavo','Bermudez','V9099693','0414-3237117','M',23,54);
INSERT INTO `userdata` VALUES (39,'Irina','Passo','E84341298','','F',24,55);
INSERT INTO `userdata` VALUES (40,'Sonia','Perez','V9120751','','F',25,56);
INSERT INTO `userdata` VALUES (41,'Armando','Salazar','E8224868','','M',26,57);
INSERT INTO `userdata` VALUES (42,'Juan','Angulo','V8674922','0416-9367854','M',27,58);
INSERT INTO `userdata` VALUES (43,'Carol','Bermudez','V10484289','','F',28,59);
INSERT INTO `userdata` VALUES (44,'Atilana','Cocho','V10544035','0412-5574926','F',29,60);
INSERT INTO `userdata` VALUES (45,'William','Sanchez','E82296106','','M',30,61);
INSERT INTO `userdata` VALUES (46,'Deyanira','Perez','E82361170','','F',31,62);
INSERT INTO `userdata` VALUES (47,'Yatsen','Torres','V10486850','0414-0110168','M',32,63);
INSERT INTO `userdata` VALUES (48,'Plutarco','Guerrero','V10201557','0416-8304160','M',33,64);
INSERT INTO `userdata` VALUES (49,'Yorman','Rodriguez','V10489903','','M',34,65);
INSERT INTO `userdata` VALUES (50,'Alexis','Indriago','V10114529','0412-6932460','M',35,66);
INSERT INTO `userdata` VALUES (51,'Raquel','Ortiz','V9149630','0414-1806052','F',36,67);
INSERT INTO `userdata` VALUES (52,'Coromoto','Gil','V7983315','0416-4235945','F',37,68);
INSERT INTO `userdata` VALUES (53,'Jose','Barrientos','V7235353','0414-4597545','M',38,69);
INSERT INTO `userdata` VALUES (54,'Ernesto','Vivas','V8707516','0414-3078846','M',39,70);
INSERT INTO `userdata` VALUES (55,'Nelly','Silva','V10429175','0414-0669951','F',40,71);
INSERT INTO `userdata` VALUES (56,'Hector','Briceño','V11044404','0416-4210775','M',41,72);
INSERT INTO `userdata` VALUES (57,'Miryan','Zabala','V7661297','0412-9248887','F',42,73);
INSERT INTO `userdata` VALUES (58,'Oscar','Granados','V7681942','','M',43,74);
INSERT INTO `userdata` VALUES (59,'Carlos','Rey','V7681951','0416-8109192','M',44,75);
INSERT INTO `userdata` VALUES (60,'Luz','Duarte','V9187628','','F',45,76);
INSERT INTO `userdata` VALUES (61,'Alirio','Rojas','V9190151','0414-9276280','M',46,77);
INSERT INTO `userdata` VALUES (62,'Edinson','Bello','E83076512','','M',47,78);
INSERT INTO `userdata` VALUES (63,'Jose','Marcano','V8762580','0416-2147249','M',48,79);
INSERT INTO `userdata` VALUES (64,'Jose','Silva','V10505214','0416-4185649','M',49,80);
INSERT INTO `userdata` VALUES (65,'Isney','Marchan','V8773933','0412-6000669','F',50,81);
INSERT INTO `userdata` VALUES (66,'Maria','Rojas','V9374164','0412-9502475','F',51,82);
INSERT INTO `userdata` VALUES (67,'Gianny','Gerardo','V11156265','0416-6204150','F',52,83);
INSERT INTO `userdata` VALUES (68,'Richard','Garcia','V11158991','','M',53,84);
INSERT INTO `userdata` VALUES (69,'Marlon','Felibert','V11180007','0412-5591822','M',54,85);
INSERT INTO `userdata` VALUES (70,'Jaime','Sintjago','V11228710','0412-2971355','M',55,86);
INSERT INTO `userdata` VALUES (71,'Nury','Hoyos','V11300972','0416-8213172','F',56,87);
INSERT INTO `userdata` VALUES (72,'Gloria','Gonzalez','V11287089','0414-2224742','F',57,88);
INSERT INTO `userdata` VALUES (73,'Jose','Briceño','V11405147','0414-2654575','M',58,89);
INSERT INTO `userdata` VALUES (74,'Lino','Parra','V11412926','','M',59,90);
INSERT INTO `userdata` VALUES (75,'Gilmy','Aguilar','V11482881','0414-1180388','F',60,91);
INSERT INTO `userdata` VALUES (76,'Jairo','Barros','V11663179','','M',61,92);
INSERT INTO `userdata` VALUES (77,'Yamileth','Urbina','V11666136','','F',62,93);
INSERT INTO `userdata` VALUES (78,'Victor','Mecia','V11690787','0416-8042528','M',63,94);
INSERT INTO `userdata` VALUES (79,'Jose','Camacho','V11801399','','M',64,95);
INSERT INTO `userdata` VALUES (80,'Any','Villarroel','V11829863','','F',65,96);
INSERT INTO `userdata` VALUES (81,'Edgardo','Coraspe','V11826588','0412-9377144','M',66,97);
INSERT INTO `userdata` VALUES (82,'Alejandro','Gonzalez','V11865447','0416-2638477','M',67,98);
INSERT INTO `userdata` VALUES (83,'Pedro','Jimenez','V12059338','0412-9521288','M',68,99);
INSERT INTO `userdata` VALUES (84,'Osvaldo','Hernandez','V12063483','','M',69,100);
INSERT INTO `userdata` VALUES (85,'Joher','Montilla','V12161817','0416-6118458','M',70,101);
INSERT INTO `userdata` VALUES (86,'Francia','Salazar','V12293572','','F',71,102);
INSERT INTO `userdata` VALUES (87,'Jeckson','Blanco','V12339520','0412-4356736','M',72,103);
INSERT INTO `userdata` VALUES (88,'Jose','Materano','V12299386','0414-1122527','M',73,104);
INSERT INTO `userdata` VALUES (89,'Henrry','Lares','V12411338','','M',74,105);
INSERT INTO `userdata` VALUES (90,'Beatriz','Jimenez','V12484299','0412-5950387','F',75,106);
INSERT INTO `userdata` VALUES (91,'Nairobi','Burgos','V12626931','0416-7259847','F',76,107);
INSERT INTO `userdata` VALUES (92,'Andres','Parra','V12627651','','M',77,108);
INSERT INTO `userdata` VALUES (93,'Katiuska','Osorio','V12666161','0412-5425564','F',78,109);
INSERT INTO `userdata` VALUES (94,'Jimmy','Benitez','V12973783','0414-2449257','M',10,110);
INSERT INTO `userdata` VALUES (95,'Leonardo','Velez','V12960326','','M',80,111);
INSERT INTO `userdata` VALUES (96,'Yony','Calderon','V13021647','','M',81,112);
INSERT INTO `userdata` VALUES (97,'Fabian','Ricardo','V13109019','','M',82,113);
INSERT INTO `userdata` VALUES (98,'Luis','Cornieles','V13144227','0414-1569728','M',83,114);
INSERT INTO `userdata` VALUES (99,'Luisa','Vergara','V13139649','0424-1214162','F',84,115);
INSERT INTO `userdata` VALUES (100,'Richar','Arellano','V13141656','0416-6106396','M',85,116);
INSERT INTO `userdata` VALUES (101,'Alexander','Amundaray','V13250270','','M',86,117);
INSERT INTO `userdata` VALUES (102,'Efrain','Duque','V13311205','0416-8075052','M',87,118);
INSERT INTO `userdata` VALUES (103,'Juan','Rodriguez','V13284794','0412-5887016','M',88,119);
INSERT INTO `userdata` VALUES (104,'Yesenia','Zambrano','V13581493','0412-9638301','F',89,120);
INSERT INTO `userdata` VALUES (105,'Michael','Cubano','V13614731','','M',90,121);
INSERT INTO `userdata` VALUES (106,'Jose','Ortega','V13658570','0414-3165974','M',91,122);
INSERT INTO `userdata` VALUES (107,'Maribel','Melendez','V13846650','','F',92,123);
INSERT INTO `userdata` VALUES (108,'Eglis','Izquierdo','V14153281','','F',93,124);
INSERT INTO `userdata` VALUES (109,'Juan','Mendoza','V14139637','0412-2938285','M',94,125);
INSERT INTO `userdata` VALUES (110,'Douglas','Montilla','V14201272','0414-9108865','M',95,126);
INSERT INTO `userdata` VALUES (111,'Xiomara','Lopez','V14201800','0416-2187889','F',96,127);
INSERT INTO `userdata` VALUES (112,'Marlyn','Guerra','V14420591','','F',97,128);
INSERT INTO `userdata` VALUES (113,'Yanibel','De Jesus','V14400968','0414-0107788','F',98,129);
INSERT INTO `userdata` VALUES (114,'Brenda','Ledeica','V14484000','0414-9393740','F',99,130);
INSERT INTO `userdata` VALUES (115,'Loni','Atencio','V14963827','0416-3062889','M',100,131);
INSERT INTO `userdata` VALUES (116,'Josefina','Alvarez','V14965758','0416-7083571','F',101,132);
INSERT INTO `userdata` VALUES (117,'Yosmar','Marchan','V14992500','0412-9803176','M',102,133);
INSERT INTO `userdata` VALUES (118,'Carlos','Teran','V15040564','','M',103,134);
INSERT INTO `userdata` VALUES (119,'Andres','Colsini','V15040851','','M',104,135);
INSERT INTO `userdata` VALUES (120,'Jairo','Mora','V15143099','0414-2561843','M',105,136);
INSERT INTO `userdata` VALUES (121,'Cleotilde','Hernandez','V15342914','0414-2864843','F',106,137);
INSERT INTO `userdata` VALUES (122,'Arturo','Olmos','V15366357','','M',107,138);
INSERT INTO `userdata` VALUES (123,'Beisy','Leal','V15395907','','F',108,139);
INSERT INTO `userdata` VALUES (124,'Luis','Chacon','V15503728','','M',109,140);
INSERT INTO `userdata` VALUES (125,'Oswaldo','Nuñez','V15613946','0412-6138932','M',110,141);
INSERT INTO `userdata` VALUES (126,'Antonio','Perez','V15582734','','M',111,142);
INSERT INTO `userdata` VALUES (127,'Jhonny','Lerma','V15665528','','M',112,143);
INSERT INTO `userdata` VALUES (128,'Yovany','Rincon','V15669530','','M',113,144);
INSERT INTO `userdata` VALUES (129,'Arianne','Cabaniel','V15605286','0416-4002256','F',114,145);
INSERT INTO `userdata` VALUES (130,'Arelis','Herrera','V15677817','0414-4684738','F',115,146);
INSERT INTO `userdata` VALUES (131,'Luis','Sifontes','V15797338','','M',116,147);
INSERT INTO `userdata` VALUES (132,'Yosneidy','Bandres','V15797490','0414-2145951','M',117,148);
INSERT INTO `userdata` VALUES (133,'Del Valle','Moreno','V15793427','0412-6165791','F',118,149);
INSERT INTO `userdata` VALUES (134,'Claudio','Letelier','V16032859','0414-2930477','M',119,150);
INSERT INTO `userdata` VALUES (135,'Mariela','Longa','V16032866','0412-9271923','F',120,151);
INSERT INTO `userdata` VALUES (136,'Johanna','Rivas','V16300288','','F',65,152);
INSERT INTO `userdata` VALUES (137,'Eduardo','Velasquez','V16486479','','M',66,153);
INSERT INTO `userdata` VALUES (138,'Norelys','Marquez','V16557182','0414-7372185','F',67,154);
INSERT INTO `userdata` VALUES (139,'Richard','Cocho','V16563834','0412-3991290','M',68,155);
INSERT INTO `userdata` VALUES (140,'Johana','Herra','V16525390','0414-3322147','F',69,156);
INSERT INTO `userdata` VALUES (141,'Neydimar','Diaz','V16475266','0414-9171684','F',70,157);
INSERT INTO `userdata` VALUES (142,'Osvaldo','Piña','V16673797','','M',71,158);
INSERT INTO `userdata` VALUES (143,'Orion','Hernandez','V16674881','','M',72,159);
INSERT INTO `userdata` VALUES (144,'Joan','Ferrer','V16727054','0416-2621219','M',73,160);
INSERT INTO `userdata` VALUES (145,'Yeghlin','Larez','V16893852','0414-0130566','F',74,161);
INSERT INTO `userdata` VALUES (146,'Maria','Diazx','V16971992','0416-4199622','F',75,162);
INSERT INTO `userdata` VALUES (147,'Lorena','Santana','V17075855','','M',76,163);
INSERT INTO `userdata` VALUES (148,'Maria','Trompetera','V17036100','','M',77,164);
INSERT INTO `userdata` VALUES (149,'Raiza','Vargas','V17285384','0416-8993204','M',119,165);
INSERT INTO `userdata` VALUES (150,'Yoxoely','Molina','V17294504','0224-6068036','F',120,166);
INSERT INTO `userdata` VALUES (151,'Rosa','Mora','V17358844','0416-1708987','F',65,167);
INSERT INTO `userdata` VALUES (152,'Maximo','Arias','V17588315','0412-9584686','M',66,168);
INSERT INTO `userdata` VALUES (153,'Flor','La Rosa','V17757424','','F',67,169);
INSERT INTO `userdata` VALUES (154,'Maria','Mora','V17895858','0416-5265870','F',68,170);
INSERT INTO `userdata` VALUES (155,'Fanny','Mendoza','V17886717','','F',6,171);
INSERT INTO `userdata` VALUES (156,'Jacssely','Montilla','V18026651','0414-2460120','F',7,172);
INSERT INTO `userdata` VALUES (157,'Elizabeth','Barrios','V18024708','0412-5722291','F',8,173);
INSERT INTO `userdata` VALUES (158,'Helleybert','Chitty','V17926479','','M',9,174);
INSERT INTO `userdata` VALUES (159,'Ysneda','Diaz','V18045347','0416-2399403','F',10,175);
INSERT INTO `userdata` VALUES (160,'Edixon','Romero','V18217218','0412-5987169','M',11,176);
INSERT INTO `userdata` VALUES (161,'Angela','Lirio','V18367900','','F',6,177);
INSERT INTO `userdata` VALUES (162,'Crizaida','Ramirez','V18584714','0416-9109792','F',7,178);
INSERT INTO `userdata` VALUES (163,'Jose','Pariata','V18756011','0412-9020830','M',8,179);
INSERT INTO `userdata` VALUES (164,'Maria','Lazo','V18713585','0416-8012250','F',9,180);
INSERT INTO `userdata` VALUES (165,'Ernesto','Mata','V19370411','','M',10,181);
INSERT INTO `userdata` VALUES (166,'Rafael','Rodriguez','V19499094','','M',11,182);
INSERT INTO `userdata` VALUES (167,'Andres','Gonzalez','V19500188','','M',12,183);
INSERT INTO `userdata` VALUES (168,'Luis','Mendivil','V20320408','','M',13,184);
INSERT INTO `userdata` VALUES (169,'Dariana','Cedeño','V20677373','','F',6,185);
INSERT INTO `userdata` VALUES (170,'Luis','Diaz','V2061188','','M',7,186);
INSERT INTO `userdata` VALUES (171,'Benjamin','Hernandez','V20678561','','M',8,187);
INSERT INTO `userdata` VALUES (172,'Elmira','Casique','V2071765','0414-9946558','F',9,188);
INSERT INTO `userdata` VALUES (173,'Carlos','Ortiz','V2074008','0416-8133299','M',10,189);
INSERT INTO `userdata` VALUES (174,'Jhonald','Caballero','V20910508','','M',11,190);
INSERT INTO `userdata` VALUES (175,'Hermes','Gutierrez','V2109247','','M',12,191);
INSERT INTO `userdata` VALUES (176,'Jose','Yepez','V21055104','','M',13,192);
INSERT INTO `userdata` VALUES (177,'Delvis','Cabrita','V21063246','','M',14,193);
INSERT INTO `userdata` VALUES (178,'Ender','Perez','V21418516','','M',6,194);
INSERT INTO `userdata` VALUES (179,'Elias','Ledeica','V2139011','','M',7,195);
INSERT INTO `userdata` VALUES (180,'Paula','Monasterio','V2154464','0414-9016373','F',8,196);
INSERT INTO `userdata` VALUES (181,'Cesar','Moreno','V2148924','0416-4702003','M',9,197);
INSERT INTO `userdata` VALUES (182,'Freddy','Velasco','V2149428','','M',10,198);
INSERT INTO `userdata` VALUES (183,'Jose','Guerra','V2151586','','M',11,199);
INSERT INTO `userdata` VALUES (184,'Mercedes','Marquez','V2158522','','F',28,200);
INSERT INTO `userdata` VALUES (185,'Jose','Arias','V22014703','0416-8160289','M',29,201);
INSERT INTO `userdata` VALUES (186,'Bernarda','De La Hoz','V22017201','','F',30,202);
INSERT INTO `userdata` VALUES (187,'Rafael','Manuitt','V2213427','0416-7155954','M',31,203);
INSERT INTO `userdata` VALUES (188,'Edward','Rios','V22759049','','M',32,204);
INSERT INTO `userdata` VALUES (189,'Manuel','Aguirre','V22762236','0412-9247063','M',33,205);
INSERT INTO `userdata` VALUES (190,'Pablo','Bermejo','V22762326','0412-7251509','M',34,206);
INSERT INTO `userdata` VALUES (191,'Aurora','Pereira','V22902137','','F',35,207);
INSERT INTO `userdata` VALUES (192,'Victor','Torres','V23148664','0416-2058817','M',36,208);
INSERT INTO `userdata` VALUES (193,'Omar','Gomez','V23446526','','M',37,209);
INSERT INTO `userdata` VALUES (194,'Ana','Alcantara','V23641888','','F',38,210);
/*!40000 ALTER TABLE `userdata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `user_id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `user_user` varchar(50) NOT NULL COMMENT 'e-mail como usuario',
  `user_pwd` varchar(50) NOT NULL,
  `user_type` int(1) NOT NULL COMMENT 'tipo de usuario',
  `user_active` int(1) DEFAULT NULL,
  `user_logged_user` varchar(50) DEFAULT NULL,
  `user_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_id`),
  KEY `user_user` (`user_user`),
  KEY `user_type` (`user_type`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=211 DEFAULT CHARSET=utf8 COMMENT='Tabla de usuarios para el acceso';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'gab@bat','1234',2,1,'admin@caracol','2017-04-09 04:11:25');
INSERT INTO `users` VALUES (2,'admin@caracol','1234',1,1,'admin@caracol','2017-04-09 04:12:40');
INSERT INTO `users` VALUES (3,'guest@caracol','1234',2,1,'admin@caracol','2017-04-09 04:18:51');
INSERT INTO `users` VALUES (4,'un@correo','1234',2,1,'admin@caracol','2017-04-09 05:24:53');
INSERT INTO `users` VALUES (6,'salo@correo','1234',2,1,'register:salo@correo','2017-04-09 14:21:53');
INSERT INTO `users` VALUES (7,'paolo@correo','1234',2,0,'register:paolo@correo','2017-04-09 14:23:10');
INSERT INTO `users` VALUES (8,'dennis@berk','1234',2,0,'register:dennis@berk','2017-04-13 01:37:06');
INSERT INTO `users` VALUES (9,'oleg@caracol','1234',1,1,'admin@caracol','2017-04-13 14:51:09');
INSERT INTO `users` VALUES (10,'oleg@correo','1234',1,1,'admin@caracol','2017-04-13 14:54:20');
INSERT INTO `users` VALUES (11,'ole@correo','1234',1,1,'admin@caracol','2017-04-13 14:55:30');
INSERT INTO `users` VALUES (12,'u1n@correo','1234',2,1,'admin@caracol','2017-04-13 23:56:30');
INSERT INTO `users` VALUES (26,'pun@correo','1234',1,1,'admin@caracol','2017-04-14 00:49:53');
INSERT INTO `users` VALUES (27,'puen@correo','1234',2,1,'admin@caracol','2017-04-14 00:51:35');
INSERT INTO `users` VALUES (28,'diego@caracol','1234',2,1,'admin@caracol','2017-04-14 00:55:35');
INSERT INTO `users` VALUES (29,'meri@mat','1234',2,0,'register:meri@mat','2017-04-14 01:02:16');
INSERT INTO `users` VALUES (30,'luz@gmail.com','1234',2,0,'register:luz@gmail.com','2017-04-14 16:43:15');
INSERT INTO `users` VALUES (31,'punn@correo','1234',2,1,'admin@caracol','2017-04-14 17:13:08');
INSERT INTO `users` VALUES (32,'gent1@comun.com','123456',1,0,NULL,'2017-05-05 20:55:52');
INSERT INTO `users` VALUES (33,'gent2@comun.com','123456',1,0,NULL,'2017-05-05 20:55:52');
INSERT INTO `users` VALUES (34,'gent3@comun.com','123456',1,0,NULL,'2017-05-05 20:55:52');
INSERT INTO `users` VALUES (35,'gent4@comun.com','123456',1,0,NULL,'2017-05-05 20:55:52');
INSERT INTO `users` VALUES (36,'gent5@comun.com','123456',1,0,NULL,'2017-05-05 20:55:52');
INSERT INTO `users` VALUES (37,'gent6@comun.com','123456',1,0,NULL,'2017-05-05 20:55:52');
INSERT INTO `users` VALUES (38,'gent7@comun.com','123456',1,1,NULL,'2017-05-05 20:55:52');
INSERT INTO `users` VALUES (39,'gent8@comun.com','123456',1,1,NULL,'2017-05-05 20:55:52');
INSERT INTO `users` VALUES (40,'gent9@comun.com','123456',1,1,NULL,'2017-05-05 20:55:52');
INSERT INTO `users` VALUES (41,'gent10@comun.com','123456',1,1,NULL,'2017-05-05 20:55:53');
INSERT INTO `users` VALUES (42,'gent11@comun.com','123456',1,1,NULL,'2017-05-05 20:55:53');
INSERT INTO `users` VALUES (43,'gent12@comun.com','123456',1,1,NULL,'2017-05-05 20:55:53');
INSERT INTO `users` VALUES (44,'gent13@comun.com','123456',1,1,NULL,'2017-05-05 20:55:53');
INSERT INTO `users` VALUES (45,'gent14@comun.com','123456',1,1,NULL,'2017-05-05 20:55:53');
INSERT INTO `users` VALUES (46,'gent15@comun.com','123456',1,1,NULL,'2017-05-05 20:55:53');
INSERT INTO `users` VALUES (47,'gent16@comun.com','123456',1,1,NULL,'2017-05-05 20:55:53');
INSERT INTO `users` VALUES (48,'gent17@comun.com','123456',1,1,NULL,'2017-05-05 20:55:53');
INSERT INTO `users` VALUES (49,'gent18@comun.com','123456',1,1,NULL,'2017-05-05 20:55:53');
INSERT INTO `users` VALUES (50,'gent19@comun.com','123456',1,1,NULL,'2017-05-05 20:55:53');
INSERT INTO `users` VALUES (51,'gent20@comun.com','123456',1,0,NULL,'2017-05-05 20:55:53');
INSERT INTO `users` VALUES (52,'gent21@comun.com','123456',1,0,NULL,'2017-05-05 20:55:53');
INSERT INTO `users` VALUES (53,'gent22@comun.com','123456',1,0,NULL,'2017-05-05 20:55:53');
INSERT INTO `users` VALUES (54,'gent23@comun.com','123456',1,0,NULL,'2017-05-05 20:55:53');
INSERT INTO `users` VALUES (55,'gent24@comun.com','123456',1,0,NULL,'2017-05-05 20:55:53');
INSERT INTO `users` VALUES (56,'gent25@comun.com','123456',1,0,NULL,'2017-05-05 20:55:53');
INSERT INTO `users` VALUES (57,'gent26@comun.com','123456',1,0,NULL,'2017-05-05 20:55:53');
INSERT INTO `users` VALUES (58,'gent27@cachi.net','123456',1,0,NULL,'2017-05-05 20:55:53');
INSERT INTO `users` VALUES (59,'gent28@cachi.net','123456',1,0,NULL,'2017-05-05 20:55:53');
INSERT INTO `users` VALUES (60,'gent29@cachi.net','123456',1,0,NULL,'2017-05-05 20:55:53');
INSERT INTO `users` VALUES (61,'gent30@cachi.net','123456',1,0,NULL,'2017-05-05 20:55:54');
INSERT INTO `users` VALUES (62,'gent31@cachi.net','123456',1,0,NULL,'2017-05-05 20:55:54');
INSERT INTO `users` VALUES (63,'gent32@cachi.net','123456',1,0,NULL,'2017-05-05 20:55:54');
INSERT INTO `users` VALUES (64,'gent33@cachi.net','123456',1,0,NULL,'2017-05-05 20:55:54');
INSERT INTO `users` VALUES (65,'gent34@cachi.net','123456',1,0,NULL,'2017-05-05 20:55:54');
INSERT INTO `users` VALUES (66,'gent35@cachi.net','123456',1,0,NULL,'2017-05-05 20:55:54');
INSERT INTO `users` VALUES (67,'gent36@cachi.net','123456',1,0,NULL,'2017-05-05 20:55:54');
INSERT INTO `users` VALUES (68,'gent37@cachi.net','123456',1,0,NULL,'2017-05-05 20:55:54');
INSERT INTO `users` VALUES (69,'gent38@cachi.net','123456',1,0,NULL,'2017-05-05 20:55:54');
INSERT INTO `users` VALUES (70,'gent39@cachi.net','123456',1,0,NULL,'2017-05-05 20:55:54');
INSERT INTO `users` VALUES (71,'gent40@cachi.net','123456',1,0,NULL,'2017-05-05 20:55:54');
INSERT INTO `users` VALUES (72,'gent41@cachi.net','123456',1,1,NULL,'2017-05-05 20:55:54');
INSERT INTO `users` VALUES (73,'gent42@cachi.net','123456',1,1,NULL,'2017-05-05 20:55:54');
INSERT INTO `users` VALUES (74,'gent43@cachi.net','123456',1,1,NULL,'2017-05-05 20:55:54');
INSERT INTO `users` VALUES (75,'gent44@cachi.net','123456',1,1,NULL,'2017-05-05 20:55:54');
INSERT INTO `users` VALUES (76,'gent45@cachi.net','123456',1,1,NULL,'2017-05-05 20:55:54');
INSERT INTO `users` VALUES (77,'gent46@cachi.net','123456',1,1,NULL,'2017-05-05 20:55:54');
INSERT INTO `users` VALUES (78,'gent47@cachi.net','123456',1,1,NULL,'2017-05-05 20:55:55');
INSERT INTO `users` VALUES (79,'gent48@cachi.net','123456',1,1,NULL,'2017-05-05 20:55:55');
INSERT INTO `users` VALUES (80,'gent49@cachi.net','123456',1,1,NULL,'2017-05-05 20:55:55');
INSERT INTO `users` VALUES (81,'gent50@cachi.net','123456',1,1,NULL,'2017-05-05 20:55:55');
INSERT INTO `users` VALUES (82,'gent51@cachi.net','123456',1,1,NULL,'2017-05-05 20:55:55');
INSERT INTO `users` VALUES (83,'gent52@cachi.net','123456',1,1,NULL,'2017-05-05 20:55:55');
INSERT INTO `users` VALUES (84,'gent53@cachi.net','123456',1,1,NULL,'2017-05-05 20:55:55');
INSERT INTO `users` VALUES (85,'gent54@cachi.net','123456',1,1,NULL,'2017-05-05 20:55:55');
INSERT INTO `users` VALUES (86,'gent55@cachi.net','123456',1,1,NULL,'2017-05-05 20:55:55');
INSERT INTO `users` VALUES (87,'gent56@cachi.net','123456',1,1,NULL,'2017-05-05 20:55:55');
INSERT INTO `users` VALUES (88,'gent57@cachi.net','123456',1,1,NULL,'2017-05-05 20:55:55');
INSERT INTO `users` VALUES (89,'gent58@cachi.net','123456',1,1,NULL,'2017-05-05 20:55:55');
INSERT INTO `users` VALUES (90,'gent59@cachi.net','123456',1,1,NULL,'2017-05-05 20:55:55');
INSERT INTO `users` VALUES (91,'gent60@cachi.net','123456',1,0,NULL,'2017-05-05 20:55:55');
INSERT INTO `users` VALUES (92,'gent61@cachi.net','123456',1,0,NULL,'2017-05-05 20:55:55');
INSERT INTO `users` VALUES (93,'gent62@cachi.net','123456',1,0,NULL,'2017-05-05 20:55:55');
INSERT INTO `users` VALUES (94,'gent63@cachi.net','123456',1,0,NULL,'2017-05-05 20:55:55');
INSERT INTO `users` VALUES (95,'gent64@cachi.net','123456',1,0,NULL,'2017-05-05 20:55:55');
INSERT INTO `users` VALUES (96,'gent65@cachi.net','123456',1,0,NULL,'2017-05-05 20:55:55');
INSERT INTO `users` VALUES (97,'gent66@cachi.net','123456',1,0,NULL,'2017-05-05 20:55:55');
INSERT INTO `users` VALUES (98,'gent67@cachi.net','123456',1,0,NULL,'2017-05-05 20:55:55');
INSERT INTO `users` VALUES (99,'gent68@cachi.net','123456',1,0,NULL,'2017-05-05 20:55:55');
INSERT INTO `users` VALUES (100,'gent69@cachi.net','123456',1,0,NULL,'2017-05-05 20:55:55');
INSERT INTO `users` VALUES (101,'gent70@cachi.net','123456',1,0,NULL,'2017-05-05 20:55:55');
INSERT INTO `users` VALUES (102,'gent71@cachi.net','123456',1,0,NULL,'2017-05-05 20:55:55');
INSERT INTO `users` VALUES (103,'gent72@cachi.net','123456',1,0,NULL,'2017-05-05 20:55:56');
INSERT INTO `users` VALUES (104,'gent73@cachi.net','123456',1,0,NULL,'2017-05-05 20:55:56');
INSERT INTO `users` VALUES (105,'gent74@cachi.net','123456',1,0,NULL,'2017-05-05 20:55:56');
INSERT INTO `users` VALUES (106,'gent75@cachi.net','123456',1,0,NULL,'2017-05-05 20:55:56');
INSERT INTO `users` VALUES (107,'gent76@cachi.net','123456',1,0,NULL,'2017-05-05 20:55:56');
INSERT INTO `users` VALUES (108,'gent77@cachi.net','123456',1,0,NULL,'2017-05-05 20:55:56');
INSERT INTO `users` VALUES (109,'gent78@cachi.net','123456',1,0,NULL,'2017-05-05 20:55:56');
INSERT INTO `users` VALUES (110,'gent79@cachi.net','123456',1,0,NULL,'2017-05-05 20:55:56');
INSERT INTO `users` VALUES (111,'gent80@cachi.net','123456',1,0,NULL,'2017-05-05 20:55:56');
INSERT INTO `users` VALUES (112,'gent81@cachi.net','123456',1,0,NULL,'2017-05-05 20:55:56');
INSERT INTO `users` VALUES (113,'gent82@cachi.net','123456',1,0,NULL,'2017-05-05 20:55:56');
INSERT INTO `users` VALUES (114,'gent83@cachi.net','123456',1,0,NULL,'2017-05-05 20:55:56');
INSERT INTO `users` VALUES (115,'gent84@cachi.net','123456',1,0,NULL,'2017-05-05 20:55:56');
INSERT INTO `users` VALUES (116,'gent85@cachi.net','123456',1,0,NULL,'2017-05-05 20:55:56');
INSERT INTO `users` VALUES (117,'gent86@cachi.net','123456',1,0,NULL,'2017-05-05 20:55:56');
INSERT INTO `users` VALUES (118,'gent87@cachi.net','123456',1,0,NULL,'2017-05-05 20:55:56');
INSERT INTO `users` VALUES (119,'gent88@cachi.net','123456',1,0,NULL,'2017-05-05 20:55:56');
INSERT INTO `users` VALUES (120,'gent89@cachi.net','123456',2,0,NULL,'2017-05-05 20:55:56');
INSERT INTO `users` VALUES (121,'gent90@cachi.net','123456',1,0,NULL,'2017-05-05 20:55:56');
INSERT INTO `users` VALUES (122,'gent91@cachi.net','123456',1,0,NULL,'2017-05-05 20:55:56');
INSERT INTO `users` VALUES (123,'gent92@cachi.net','123456',1,0,NULL,'2017-05-05 20:55:57');
INSERT INTO `users` VALUES (124,'gent93@cachi.net','123456',1,0,NULL,'2017-05-05 20:55:57');
INSERT INTO `users` VALUES (125,'gent94@cachi.net','123456',1,0,NULL,'2017-05-05 20:55:57');
INSERT INTO `users` VALUES (126,'gent95@cachi.net','123456',1,0,NULL,'2017-05-05 20:55:57');
INSERT INTO `users` VALUES (127,'gent96@cachi.net','123456',1,0,NULL,'2017-05-05 20:55:57');
INSERT INTO `users` VALUES (128,'gent97@cachi.net','123456',1,0,NULL,'2017-05-05 20:55:57');
INSERT INTO `users` VALUES (129,'gent98@cachi.net','123456',1,0,NULL,'2017-05-05 20:55:57');
INSERT INTO `users` VALUES (130,'gent99@cachi.net','123456',1,0,NULL,'2017-05-05 20:55:57');
INSERT INTO `users` VALUES (131,'gent100@cachi.net','123456',1,0,NULL,'2017-05-05 20:55:57');
INSERT INTO `users` VALUES (132,'gent101@cachi.net','123456',1,0,NULL,'2017-05-05 20:55:57');
INSERT INTO `users` VALUES (133,'gent102@cachi.net','123456',1,0,NULL,'2017-05-05 20:55:57');
INSERT INTO `users` VALUES (134,'gent103@cachi.net','123456',1,0,NULL,'2017-05-05 20:55:57');
INSERT INTO `users` VALUES (135,'gent104@cachi.net','123456',1,0,NULL,'2017-05-05 20:55:57');
INSERT INTO `users` VALUES (136,'gent105@cachi.net','123456',2,0,NULL,'2017-05-05 20:55:57');
INSERT INTO `users` VALUES (137,'gent106@cachi.net','123456',1,0,NULL,'2017-05-05 20:55:57');
INSERT INTO `users` VALUES (138,'gent107@cachi.net','123456',1,0,NULL,'2017-05-05 20:55:57');
INSERT INTO `users` VALUES (139,'gent108@copa.org','123456',1,0,NULL,'2017-05-05 20:55:57');
INSERT INTO `users` VALUES (140,'gent109@copa.org','123456',1,0,NULL,'2017-05-05 20:55:57');
INSERT INTO `users` VALUES (141,'gent110@copa.org','123456',1,0,NULL,'2017-05-05 20:55:57');
INSERT INTO `users` VALUES (142,'gent111@copa.org','123456',1,0,NULL,'2017-05-05 20:55:57');
INSERT INTO `users` VALUES (143,'gent112@copa.org','123456',1,0,NULL,'2017-05-05 20:55:57');
INSERT INTO `users` VALUES (144,'gent113@copa.org','123456',1,1,NULL,'2017-05-05 20:55:57');
INSERT INTO `users` VALUES (145,'gent114@copa.org','123456',1,1,NULL,'2017-05-05 20:55:57');
INSERT INTO `users` VALUES (146,'gent115@copa.org','123456',1,1,NULL,'2017-05-05 20:55:57');
INSERT INTO `users` VALUES (147,'gent116@copa.org','123456',1,1,NULL,'2017-05-05 20:55:57');
INSERT INTO `users` VALUES (148,'gent117@copa.org','123456',1,1,NULL,'2017-05-05 20:55:57');
INSERT INTO `users` VALUES (149,'gent118@copa.org','123456',1,1,NULL,'2017-05-05 20:55:57');
INSERT INTO `users` VALUES (150,'gent119@copa.org','123456',1,1,NULL,'2017-05-05 20:55:58');
INSERT INTO `users` VALUES (151,'gent120@copa.org','123456',1,1,NULL,'2017-05-05 20:55:58');
INSERT INTO `users` VALUES (152,'gent121@copa.org','123456',1,1,NULL,'2017-05-05 20:55:58');
INSERT INTO `users` VALUES (153,'gent122@copa.org','123456',1,1,NULL,'2017-05-05 20:55:58');
INSERT INTO `users` VALUES (154,'gent123@copa.org','123456',2,1,NULL,'2017-05-05 20:55:58');
INSERT INTO `users` VALUES (155,'gent124@copa.org','123456',1,1,NULL,'2017-05-05 20:55:58');
INSERT INTO `users` VALUES (156,'gent125@copa.org','123456',1,1,NULL,'2017-05-05 20:55:58');
INSERT INTO `users` VALUES (157,'gent126@copa.org','123456',1,1,NULL,'2017-05-05 20:55:58');
INSERT INTO `users` VALUES (158,'gent127@copa.org','123456',1,1,NULL,'2017-05-05 20:55:58');
INSERT INTO `users` VALUES (159,'gent128@copa.org','123456',1,1,NULL,'2017-05-05 20:55:58');
INSERT INTO `users` VALUES (160,'gent129@copa.org','123456',1,1,NULL,'2017-05-05 20:55:58');
INSERT INTO `users` VALUES (161,'gent130@copa.org','123456',1,1,NULL,'2017-05-05 20:55:58');
INSERT INTO `users` VALUES (162,'gent131@copa.org','123456',1,1,NULL,'2017-05-05 20:55:58');
INSERT INTO `users` VALUES (163,'gent132@copa.org','123456',1,1,NULL,'2017-05-05 20:55:58');
INSERT INTO `users` VALUES (164,'gent133@copa.org','123456',1,1,NULL,'2017-05-05 20:55:58');
INSERT INTO `users` VALUES (165,'gent134@copa.org','123456',1,1,NULL,'2017-05-05 20:55:58');
INSERT INTO `users` VALUES (166,'gent135@copa.org','123456',1,1,NULL,'2017-05-05 20:55:58');
INSERT INTO `users` VALUES (167,'gent136@copa.org','123456',1,1,NULL,'2017-05-05 20:55:58');
INSERT INTO `users` VALUES (168,'gent137@copa.org','123456',1,1,NULL,'2017-05-05 20:55:58');
INSERT INTO `users` VALUES (169,'gent138@copa.org','123456',1,0,NULL,'2017-05-05 20:55:58');
INSERT INTO `users` VALUES (170,'gent139@copa.org','123456',1,0,NULL,'2017-05-05 20:55:58');
INSERT INTO `users` VALUES (171,'gent140@copa.org','123456',1,0,NULL,'2017-05-05 20:55:58');
INSERT INTO `users` VALUES (172,'gent141@copa.org','123456',1,0,NULL,'2017-05-05 20:55:58');
INSERT INTO `users` VALUES (173,'gent142@copa.org','123456',2,0,NULL,'2017-05-05 20:55:58');
INSERT INTO `users` VALUES (174,'gent143@copa.org','123456',1,0,NULL,'2017-05-05 20:55:58');
INSERT INTO `users` VALUES (175,'gent144@copa.org','123456',1,0,NULL,'2017-05-05 20:55:58');
INSERT INTO `users` VALUES (176,'gent145@copa.org','123456',1,0,NULL,'2017-05-05 20:55:58');
INSERT INTO `users` VALUES (177,'gent146@copa.org','123456',1,0,NULL,'2017-05-05 20:55:58');
INSERT INTO `users` VALUES (178,'gent147@copa.org','123456',2,0,NULL,'2017-05-05 20:55:58');
INSERT INTO `users` VALUES (179,'gent148@copa.org','123456',1,0,NULL,'2017-05-05 20:55:58');
INSERT INTO `users` VALUES (180,'gent149@copa.org','123456',1,0,NULL,'2017-05-05 20:55:58');
INSERT INTO `users` VALUES (181,'gent150@copa.org','123456',1,0,NULL,'2017-05-05 20:55:59');
INSERT INTO `users` VALUES (182,'gent151@copa.org','123456',1,0,NULL,'2017-05-05 20:55:59');
INSERT INTO `users` VALUES (183,'gent152@copa.org','123456',1,0,NULL,'2017-05-05 20:55:59');
INSERT INTO `users` VALUES (184,'gent153@copa.org','123456',1,0,NULL,'2017-05-05 20:55:59');
INSERT INTO `users` VALUES (185,'gent154@copa.org','123456',1,0,NULL,'2017-05-05 20:55:59');
INSERT INTO `users` VALUES (186,'gent155@copa.org','123456',1,0,NULL,'2017-05-05 20:55:59');
INSERT INTO `users` VALUES (187,'gent156@copa.org','123456',1,0,NULL,'2017-05-05 20:55:59');
INSERT INTO `users` VALUES (188,'gent157@copa.org','123456',1,0,NULL,'2017-05-05 20:55:59');
INSERT INTO `users` VALUES (189,'gent158@copa.org','123456',1,0,NULL,'2017-05-05 20:55:59');
INSERT INTO `users` VALUES (190,'gent159@copa.org','123456',1,0,NULL,'2017-05-05 20:55:59');
INSERT INTO `users` VALUES (191,'gent160@copa.org','123456',1,0,NULL,'2017-05-05 20:55:59');
INSERT INTO `users` VALUES (192,'gent161@copa.org','123456',1,0,NULL,'2017-05-05 20:55:59');
INSERT INTO `users` VALUES (193,'gent162@copa.org','123456',1,0,NULL,'2017-05-05 20:55:59');
INSERT INTO `users` VALUES (194,'gent163@copa.org','123456',1,0,NULL,'2017-05-05 20:55:59');
INSERT INTO `users` VALUES (195,'gent164@copa.org','123456',1,0,NULL,'2017-05-05 20:55:59');
INSERT INTO `users` VALUES (196,'gent165@copa.org','123456',1,0,NULL,'2017-05-05 20:55:59');
INSERT INTO `users` VALUES (197,'gent166@copa.org','123456',1,0,NULL,'2017-05-05 20:55:59');
INSERT INTO `users` VALUES (198,'gent167@copa.org','123456',1,0,NULL,'2017-05-05 20:55:59');
INSERT INTO `users` VALUES (199,'gent168@copa.org','123456',1,0,NULL,'2017-05-05 20:55:59');
INSERT INTO `users` VALUES (200,'gent169@copa.org','123456',1,0,NULL,'2017-05-05 20:55:59');
INSERT INTO `users` VALUES (201,'gent170@copa.org','123456',1,0,NULL,'2017-05-05 20:55:59');
INSERT INTO `users` VALUES (202,'gent171@copa.org','123456',1,0,NULL,'2017-05-05 20:55:59');
INSERT INTO `users` VALUES (203,'gent172@copa.org','123456',1,0,NULL,'2017-05-05 20:55:59');
INSERT INTO `users` VALUES (204,'gent173@copa.org','123456',1,0,NULL,'2017-05-05 20:55:59');
INSERT INTO `users` VALUES (205,'gent174@copa.org','123456',1,0,NULL,'2017-05-05 20:55:59');
INSERT INTO `users` VALUES (206,'gent175@copa.org','123456',1,0,NULL,'2017-05-05 20:55:59');
INSERT INTO `users` VALUES (207,'gent176@copa.org','123456',1,0,NULL,'2017-05-05 20:55:59');
INSERT INTO `users` VALUES (208,'gent177@copa.org','123456',1,0,NULL,'2017-05-05 20:55:59');
INSERT INTO `users` VALUES (209,'gent178@copa.org','123456',1,0,NULL,'2017-05-05 20:55:59');
INSERT INTO `users` VALUES (210,'gent179@copa.org','123456',1,0,NULL,'2017-05-05 20:55:59');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usual_providers`
--

DROP TABLE IF EXISTS `usual_providers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usual_providers` (
  `up_id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `up_name` varchar(100) COLLATE utf8_spanish_ci NOT NULL COMMENT 'Nombre o Razon Social',
  `up_rif` varchar(10) COLLATE utf8_spanish_ci NOT NULL COMMENT 'Rif o CI',
  `up_alias` varchar(20) COLLATE utf8_spanish_ci NOT NULL,
  `up_fk_type` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT 'Tipo de gasto',
  `up_op` int(1) unsigned NOT NULL DEFAULT '0' COMMENT 'Caracteristicas especiales de cobro',
  `up_notes` varchar(1000) COLLATE utf8_spanish_ci DEFAULT '' COMMENT 'Documentacion relacionada',
  PRIMARY KEY (`up_id`),
  KEY `up_group_fk` (`up_fk_type`),
  KEY `up_name` (`up_name`),
  KEY `up_rif` (`up_rif`),
  KEY `up_alias` (`up_alias`),
  CONSTRAINT `usual_providers_ibfk_1` FOREIGN KEY (`up_fk_type`) REFERENCES `spendings_types` (`spe_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci COMMENT='Proveedores Frecuentes';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usual_providers`
--

LOCK TABLES `usual_providers` WRITE;
/*!40000 ALTER TABLE `usual_providers` DISABLE KEYS */;
INSERT INTO `usual_providers` VALUES (1,'Proveedor','','EXTRAORDINARIO',5,0,'');
INSERT INTO `usual_providers` VALUES (2,'Corporacición Eléctrica Nacional, S.A. (CORPOELEC)','G200100141','ELECTRICIDAD',3,0,'');
INSERT INTO `usual_providers` VALUES (3,'Hidrológica de la Regio Capital, C.A. (HIDROCAPITAL)','G200121076','HIDROCAPITAL',3,1,'');
INSERT INTO `usual_providers` VALUES (4,'José Alfredo Tamayo','V20112432','Jardinero',1,0,'Trabaja martes y jueves');
INSERT INTO `usual_providers` VALUES (5,'Proyectos Técnicos, S.A.','J311429506','MANT. ASCENSORES',3,0,'');
INSERT INTO `usual_providers` VALUES (6,'María Laura Mora Torta','V13900343','LIMPIEZA EDIFICIO',1,0,'');
INSERT INTO `usual_providers` VALUES (7,'Consorcio de Ferreterías Comerciales EPA C.A.','J000000456','EPA',2,2,'');
INSERT INTO `usual_providers` VALUES (8,'Servicios y Proyectos Cosmonauta C.A.','J000456789','ADMINISTRACION',3,0,'');
/*!40000 ALTER TABLE `usual_providers` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-05-16 11:29:03
