-- MySQL dump 10.13  Distrib 5.7.18, for Linux (x86_64)
--
-- Host: localhost    Database: bd_minha
-- ------------------------------------------------------
-- Server version	5.7.18-0ubuntu0.16.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `charges`
--

DROP TABLE IF EXISTS `charges`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `charges` (
  `cha_id` int(8) unsigned NOT NULL AUTO_INCREMENT,
  `cha_fk_number` tinyint(3) unsigned NOT NULL,
  `cha_amount` decimal(10,2) NOT NULL COMMENT 'Cantidad a cobrar o pagada',
  `cha_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `cha_user` varchar(50) CHARACTER SET utf32 COLLATE utf32_spanish_ci NOT NULL,
  PRIMARY KEY (`cha_id`),
  KEY `cha_fk_number` (`cha_fk_number`)
) ENGINE=InnoDB AUTO_INCREMENT=241 DEFAULT CHARSET=utf8 COMMENT='Se lleva el balance de cobros';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `charges`
--

LOCK TABLES `charges` WRITE;
/*!40000 ALTER TABLE `charges` DISABLE KEYS */;
INSERT INTO `charges` VALUES (1,1,2729.64,'2017-04-23 01:33:23','diego');
INSERT INTO `charges` VALUES (2,2,1819.75,'2017-04-23 01:33:23','diego');
INSERT INTO `charges` VALUES (3,3,1819.75,'2017-04-23 01:33:23','diego');
INSERT INTO `charges` VALUES (4,4,2729.64,'2017-04-23 01:33:23','diego');
INSERT INTO `charges` VALUES (5,5,1819.75,'2017-04-23 01:33:23','diego');
INSERT INTO `charges` VALUES (6,6,909.89,'2017-04-23 01:33:23','diego');
INSERT INTO `charges` VALUES (7,7,909.89,'2017-04-23 01:33:23','diego');
INSERT INTO `charges` VALUES (8,8,1819.75,'2017-04-23 01:33:23','diego');
INSERT INTO `charges` VALUES (9,9,2729.64,'2017-04-23 01:33:23','diego');
INSERT INTO `charges` VALUES (10,10,1819.75,'2017-04-23 01:33:23','diego');
INSERT INTO `charges` VALUES (11,11,1819.75,'2017-04-23 01:33:23','diego');
INSERT INTO `charges` VALUES (12,12,2729.64,'2017-04-23 01:33:23','diego');
INSERT INTO `charges` VALUES (13,13,1819.75,'2017-04-23 01:33:24','diego');
INSERT INTO `charges` VALUES (14,14,909.89,'2017-04-23 01:33:24','diego');
INSERT INTO `charges` VALUES (15,15,909.89,'2017-04-23 01:33:24','diego');
INSERT INTO `charges` VALUES (16,16,1819.75,'2017-04-23 01:33:24','diego');
INSERT INTO `charges` VALUES (17,17,2729.64,'2017-04-23 01:33:24','diego');
INSERT INTO `charges` VALUES (18,18,1819.75,'2017-04-23 01:33:24','diego');
INSERT INTO `charges` VALUES (19,19,1819.75,'2017-04-23 01:33:24','diego');
INSERT INTO `charges` VALUES (20,20,2729.64,'2017-04-23 01:33:24','diego');
INSERT INTO `charges` VALUES (21,21,1819.75,'2017-04-23 01:33:24','diego');
INSERT INTO `charges` VALUES (22,22,909.89,'2017-04-23 01:33:24','diego');
INSERT INTO `charges` VALUES (23,23,909.89,'2017-04-23 01:33:24','diego');
INSERT INTO `charges` VALUES (24,24,1819.75,'2017-04-23 01:33:24','diego');
INSERT INTO `charges` VALUES (25,25,2729.64,'2017-04-23 01:33:24','diego');
INSERT INTO `charges` VALUES (26,26,1819.75,'2017-04-23 01:33:24','diego');
INSERT INTO `charges` VALUES (27,27,1819.75,'2017-04-23 01:33:24','diego');
INSERT INTO `charges` VALUES (28,28,2729.64,'2017-04-23 01:33:24','diego');
INSERT INTO `charges` VALUES (29,29,1819.75,'2017-04-23 01:33:24','diego');
INSERT INTO `charges` VALUES (30,30,909.89,'2017-04-23 01:33:24','diego');
INSERT INTO `charges` VALUES (31,31,909.89,'2017-04-23 01:33:24','diego');
INSERT INTO `charges` VALUES (32,32,1819.75,'2017-04-23 01:33:24','diego');
INSERT INTO `charges` VALUES (33,33,2729.64,'2017-04-23 01:33:24','diego');
INSERT INTO `charges` VALUES (34,34,1819.75,'2017-04-23 01:33:24','diego');
INSERT INTO `charges` VALUES (35,35,1819.75,'2017-04-23 01:33:24','diego');
INSERT INTO `charges` VALUES (36,36,2729.64,'2017-04-23 01:33:24','diego');
INSERT INTO `charges` VALUES (37,37,1819.75,'2017-04-23 01:33:24','diego');
INSERT INTO `charges` VALUES (38,38,909.89,'2017-04-23 01:33:24','diego');
INSERT INTO `charges` VALUES (39,39,909.89,'2017-04-23 01:33:24','diego');
INSERT INTO `charges` VALUES (40,40,1819.75,'2017-04-23 01:33:24','diego');
INSERT INTO `charges` VALUES (41,41,2729.64,'2017-04-23 01:33:24','diego');
INSERT INTO `charges` VALUES (42,42,1819.75,'2017-04-23 01:33:24','diego');
INSERT INTO `charges` VALUES (43,43,1819.75,'2017-04-23 01:33:24','diego');
INSERT INTO `charges` VALUES (44,44,2729.64,'2017-04-23 01:33:24','diego');
INSERT INTO `charges` VALUES (45,45,1819.75,'2017-04-23 01:33:24','diego');
INSERT INTO `charges` VALUES (46,46,909.89,'2017-04-23 01:33:24','diego');
INSERT INTO `charges` VALUES (47,47,909.89,'2017-04-23 01:33:24','diego');
INSERT INTO `charges` VALUES (48,48,1819.75,'2017-04-23 01:33:25','diego');
INSERT INTO `charges` VALUES (49,49,2729.64,'2017-04-23 01:33:25','diego');
INSERT INTO `charges` VALUES (50,50,1819.75,'2017-04-23 01:33:25','diego');
INSERT INTO `charges` VALUES (51,51,1819.75,'2017-04-23 01:33:25','diego');
INSERT INTO `charges` VALUES (52,52,2729.64,'2017-04-23 01:33:25','diego');
INSERT INTO `charges` VALUES (53,53,1819.75,'2017-04-23 01:33:25','diego');
INSERT INTO `charges` VALUES (54,54,909.89,'2017-04-23 01:33:25','diego');
INSERT INTO `charges` VALUES (55,55,909.89,'2017-04-23 01:33:25','diego');
INSERT INTO `charges` VALUES (56,56,1819.75,'2017-04-23 01:33:25','diego');
INSERT INTO `charges` VALUES (57,57,2729.64,'2017-04-23 01:33:25','diego');
INSERT INTO `charges` VALUES (58,58,1819.75,'2017-04-23 01:33:25','diego');
INSERT INTO `charges` VALUES (59,59,1819.75,'2017-04-23 01:33:25','diego');
INSERT INTO `charges` VALUES (60,60,2729.64,'2017-04-23 01:33:25','diego');
INSERT INTO `charges` VALUES (61,61,1819.75,'2017-04-23 01:33:25','diego');
INSERT INTO `charges` VALUES (62,62,909.89,'2017-04-23 01:33:25','diego');
INSERT INTO `charges` VALUES (63,63,909.89,'2017-04-23 01:33:25','diego');
INSERT INTO `charges` VALUES (64,64,1819.75,'2017-04-23 01:33:25','diego');
INSERT INTO `charges` VALUES (65,65,2729.64,'2017-04-23 01:33:25','diego');
INSERT INTO `charges` VALUES (66,66,1819.75,'2017-04-23 01:33:25','diego');
INSERT INTO `charges` VALUES (67,67,1819.75,'2017-04-23 01:33:25','diego');
INSERT INTO `charges` VALUES (68,68,2729.64,'2017-04-23 01:33:25','diego');
INSERT INTO `charges` VALUES (69,69,1819.75,'2017-04-23 01:33:25','diego');
INSERT INTO `charges` VALUES (70,70,909.89,'2017-04-23 01:33:25','diego');
INSERT INTO `charges` VALUES (71,71,909.89,'2017-04-23 01:33:25','diego');
INSERT INTO `charges` VALUES (72,72,1819.75,'2017-04-23 01:33:25','diego');
INSERT INTO `charges` VALUES (73,73,2729.64,'2017-04-23 01:33:25','diego');
INSERT INTO `charges` VALUES (74,74,1819.75,'2017-04-23 01:33:25','diego');
INSERT INTO `charges` VALUES (75,75,1819.75,'2017-04-23 01:33:25','diego');
INSERT INTO `charges` VALUES (76,76,2729.64,'2017-04-23 01:33:25','diego');
INSERT INTO `charges` VALUES (77,77,1819.75,'2017-04-23 01:33:25','diego');
INSERT INTO `charges` VALUES (78,78,909.89,'2017-04-23 01:33:26','diego');
INSERT INTO `charges` VALUES (79,79,909.89,'2017-04-23 01:33:26','diego');
INSERT INTO `charges` VALUES (80,80,1819.75,'2017-04-23 01:33:26','diego');
INSERT INTO `charges` VALUES (81,81,2729.64,'2017-04-23 01:33:26','diego');
INSERT INTO `charges` VALUES (82,82,1819.75,'2017-04-23 01:33:26','diego');
INSERT INTO `charges` VALUES (83,83,1819.75,'2017-04-23 01:33:26','diego');
INSERT INTO `charges` VALUES (84,84,2729.64,'2017-04-23 01:33:26','diego');
INSERT INTO `charges` VALUES (85,85,1819.75,'2017-04-23 01:33:26','diego');
INSERT INTO `charges` VALUES (86,86,909.89,'2017-04-23 01:33:26','diego');
INSERT INTO `charges` VALUES (87,87,909.89,'2017-04-23 01:33:26','diego');
INSERT INTO `charges` VALUES (88,88,1819.75,'2017-04-23 01:33:26','diego');
INSERT INTO `charges` VALUES (89,89,2729.64,'2017-04-23 01:33:26','diego');
INSERT INTO `charges` VALUES (90,90,1819.75,'2017-04-23 01:33:26','diego');
INSERT INTO `charges` VALUES (91,91,1819.75,'2017-04-23 01:33:26','diego');
INSERT INTO `charges` VALUES (92,92,2729.64,'2017-04-23 01:33:26','diego');
INSERT INTO `charges` VALUES (93,93,1819.75,'2017-04-23 01:33:26','diego');
INSERT INTO `charges` VALUES (94,94,909.89,'2017-04-23 01:33:26','diego');
INSERT INTO `charges` VALUES (95,95,909.89,'2017-04-23 01:33:26','diego');
INSERT INTO `charges` VALUES (96,96,1819.75,'2017-04-23 01:33:26','diego');
INSERT INTO `charges` VALUES (97,97,2729.64,'2017-04-23 01:33:26','diego');
INSERT INTO `charges` VALUES (98,98,1819.75,'2017-04-23 01:33:26','diego');
INSERT INTO `charges` VALUES (99,99,1819.75,'2017-04-23 01:33:26','diego');
INSERT INTO `charges` VALUES (100,100,2729.64,'2017-04-23 01:33:26','diego');
INSERT INTO `charges` VALUES (101,101,1819.75,'2017-04-23 01:33:26','diego');
INSERT INTO `charges` VALUES (102,102,909.89,'2017-04-23 01:33:26','diego');
INSERT INTO `charges` VALUES (103,103,909.89,'2017-04-23 01:33:26','diego');
INSERT INTO `charges` VALUES (104,104,1819.75,'2017-04-23 01:33:26','diego');
INSERT INTO `charges` VALUES (105,105,2729.64,'2017-04-23 01:33:26','diego');
INSERT INTO `charges` VALUES (106,106,1819.75,'2017-04-23 01:33:26','diego');
INSERT INTO `charges` VALUES (107,107,1819.75,'2017-04-23 01:33:26','diego');
INSERT INTO `charges` VALUES (108,108,2729.64,'2017-04-23 01:33:26','diego');
INSERT INTO `charges` VALUES (109,109,1819.75,'2017-04-23 01:33:26','diego');
INSERT INTO `charges` VALUES (110,110,909.89,'2017-04-23 01:33:26','diego');
INSERT INTO `charges` VALUES (111,111,909.89,'2017-04-23 01:33:26','diego');
INSERT INTO `charges` VALUES (112,112,1819.75,'2017-04-23 01:33:27','diego');
INSERT INTO `charges` VALUES (113,113,2729.64,'2017-04-23 01:33:27','diego');
INSERT INTO `charges` VALUES (114,114,1819.75,'2017-04-23 01:33:27','diego');
INSERT INTO `charges` VALUES (115,115,1819.75,'2017-04-23 01:33:27','diego');
INSERT INTO `charges` VALUES (116,116,2729.64,'2017-04-23 01:33:27','diego');
INSERT INTO `charges` VALUES (117,117,1819.75,'2017-04-23 01:33:27','diego');
INSERT INTO `charges` VALUES (118,118,909.89,'2017-04-23 01:33:27','diego');
INSERT INTO `charges` VALUES (119,119,909.89,'2017-04-23 01:33:27','diego');
INSERT INTO `charges` VALUES (120,120,1819.75,'2017-04-23 01:33:27','diego');
INSERT INTO `charges` VALUES (121,78,-2000.00,'2017-04-23 01:35:52','diego');
INSERT INTO `charges` VALUES (122,2,-1245.00,'2017-05-18 18:42:51','diego');
INSERT INTO `charges` VALUES (123,1,-1556.31,'2017-05-22 18:25:29','diego');
INSERT INTO `charges` VALUES (124,2,-1037.55,'2017-05-22 18:25:30','diego');
INSERT INTO `charges` VALUES (125,3,-1037.55,'2017-05-22 18:25:30','diego');
INSERT INTO `charges` VALUES (126,4,-1556.31,'2017-05-22 18:25:30','diego');
INSERT INTO `charges` VALUES (127,5,-1037.55,'2017-05-22 18:25:30','diego');
INSERT INTO `charges` VALUES (128,6,-518.77,'2017-05-22 18:25:30','diego');
INSERT INTO `charges` VALUES (129,7,-518.77,'2017-05-22 18:25:30','diego');
INSERT INTO `charges` VALUES (130,8,-1037.55,'2017-05-22 18:25:30','diego');
INSERT INTO `charges` VALUES (131,9,-1556.31,'2017-05-22 18:25:30','diego');
INSERT INTO `charges` VALUES (132,10,-1037.55,'2017-05-22 18:25:30','diego');
INSERT INTO `charges` VALUES (133,11,-1037.55,'2017-05-22 18:25:30','diego');
INSERT INTO `charges` VALUES (134,12,-1556.31,'2017-05-22 18:25:30','diego');
INSERT INTO `charges` VALUES (135,13,-1037.55,'2017-05-22 18:25:30','diego');
INSERT INTO `charges` VALUES (136,14,-518.77,'2017-05-22 18:25:30','diego');
INSERT INTO `charges` VALUES (137,15,-518.77,'2017-05-22 18:25:30','diego');
INSERT INTO `charges` VALUES (138,16,-1037.55,'2017-05-22 18:25:31','diego');
INSERT INTO `charges` VALUES (139,17,-1556.31,'2017-05-22 18:25:31','diego');
INSERT INTO `charges` VALUES (140,18,-1037.55,'2017-05-22 18:25:31','diego');
INSERT INTO `charges` VALUES (141,19,-1037.55,'2017-05-22 18:25:31','diego');
INSERT INTO `charges` VALUES (142,20,-1556.31,'2017-05-22 18:25:31','diego');
INSERT INTO `charges` VALUES (143,21,-1037.55,'2017-05-22 18:25:31','diego');
INSERT INTO `charges` VALUES (144,22,-518.77,'2017-05-22 18:25:31','diego');
INSERT INTO `charges` VALUES (145,23,-518.77,'2017-05-22 18:25:31','diego');
INSERT INTO `charges` VALUES (146,24,-1037.55,'2017-05-22 18:25:31','diego');
INSERT INTO `charges` VALUES (147,25,-1556.31,'2017-05-22 18:25:31','diego');
INSERT INTO `charges` VALUES (148,27,-1037.55,'2017-05-22 18:25:31','diego');
INSERT INTO `charges` VALUES (149,28,-1556.31,'2017-05-22 18:25:31','diego');
INSERT INTO `charges` VALUES (150,29,-1037.55,'2017-05-22 18:25:31','diego');
INSERT INTO `charges` VALUES (151,30,-518.77,'2017-05-22 18:25:31','diego');
INSERT INTO `charges` VALUES (152,31,-518.77,'2017-05-22 18:25:32','diego');
INSERT INTO `charges` VALUES (153,32,-1037.55,'2017-05-22 18:25:32','diego');
INSERT INTO `charges` VALUES (154,33,-1556.31,'2017-05-22 18:25:32','diego');
INSERT INTO `charges` VALUES (155,34,-1037.55,'2017-05-22 18:25:32','diego');
INSERT INTO `charges` VALUES (156,35,-1037.55,'2017-05-22 18:25:32','diego');
INSERT INTO `charges` VALUES (157,36,-1556.31,'2017-05-22 18:25:32','diego');
INSERT INTO `charges` VALUES (158,37,-1037.55,'2017-05-22 18:25:32','diego');
INSERT INTO `charges` VALUES (159,38,-518.77,'2017-05-22 18:25:32','diego');
INSERT INTO `charges` VALUES (160,39,-518.77,'2017-05-22 18:25:32','diego');
INSERT INTO `charges` VALUES (161,40,-1037.55,'2017-05-22 18:25:32','diego');
INSERT INTO `charges` VALUES (162,41,-1556.31,'2017-05-22 18:25:32','diego');
INSERT INTO `charges` VALUES (163,42,-1037.55,'2017-05-22 18:25:32','diego');
INSERT INTO `charges` VALUES (164,43,-1037.55,'2017-05-22 18:25:32','diego');
INSERT INTO `charges` VALUES (165,44,-1556.31,'2017-05-22 18:25:32','diego');
INSERT INTO `charges` VALUES (166,45,-1037.55,'2017-05-22 18:25:32','diego');
INSERT INTO `charges` VALUES (167,46,-518.77,'2017-05-22 18:25:32','diego');
INSERT INTO `charges` VALUES (168,47,-518.77,'2017-05-22 18:25:32','diego');
INSERT INTO `charges` VALUES (169,48,-1037.55,'2017-05-22 18:25:32','diego');
INSERT INTO `charges` VALUES (170,49,-1556.31,'2017-05-22 18:25:32','diego');
INSERT INTO `charges` VALUES (171,50,-1037.55,'2017-05-22 18:25:32','diego');
INSERT INTO `charges` VALUES (172,51,-1037.55,'2017-05-22 18:25:32','diego');
INSERT INTO `charges` VALUES (173,52,-1556.31,'2017-05-22 18:25:32','diego');
INSERT INTO `charges` VALUES (174,53,-1037.55,'2017-05-22 18:25:32','diego');
INSERT INTO `charges` VALUES (175,54,-518.77,'2017-05-22 18:25:32','diego');
INSERT INTO `charges` VALUES (176,55,-518.77,'2017-05-22 18:25:32','diego');
INSERT INTO `charges` VALUES (177,56,-1037.55,'2017-05-22 18:25:32','diego');
INSERT INTO `charges` VALUES (178,57,-1556.31,'2017-05-22 18:25:32','diego');
INSERT INTO `charges` VALUES (179,58,-1037.55,'2017-05-22 18:25:33','diego');
INSERT INTO `charges` VALUES (180,59,-1037.55,'2017-05-22 18:25:33','diego');
INSERT INTO `charges` VALUES (181,60,-1556.31,'2017-05-22 18:25:33','diego');
INSERT INTO `charges` VALUES (182,61,-1037.55,'2017-05-22 18:25:33','diego');
INSERT INTO `charges` VALUES (183,62,-518.77,'2017-05-22 18:25:33','diego');
INSERT INTO `charges` VALUES (184,63,-518.77,'2017-05-22 18:25:33','diego');
INSERT INTO `charges` VALUES (185,64,-1037.55,'2017-05-22 18:25:33','diego');
INSERT INTO `charges` VALUES (186,65,-1556.31,'2017-05-22 18:25:33','diego');
INSERT INTO `charges` VALUES (187,66,-1037.55,'2017-05-22 18:25:33','diego');
INSERT INTO `charges` VALUES (188,67,-1037.55,'2017-05-22 18:25:33','diego');
INSERT INTO `charges` VALUES (189,68,-1556.31,'2017-05-22 18:25:33','diego');
INSERT INTO `charges` VALUES (190,69,-1037.55,'2017-05-22 18:25:33','diego');
INSERT INTO `charges` VALUES (191,70,-518.77,'2017-05-22 18:25:33','diego');
INSERT INTO `charges` VALUES (192,71,-518.77,'2017-05-22 18:25:33','diego');
INSERT INTO `charges` VALUES (193,72,-1037.55,'2017-05-22 18:25:33','diego');
INSERT INTO `charges` VALUES (194,73,-1556.31,'2017-05-22 18:25:33','diego');
INSERT INTO `charges` VALUES (195,74,-1037.55,'2017-05-22 18:25:33','diego');
INSERT INTO `charges` VALUES (196,75,-1037.55,'2017-05-22 18:25:33','diego');
INSERT INTO `charges` VALUES (197,76,-1556.31,'2017-05-22 18:25:33','diego');
INSERT INTO `charges` VALUES (198,77,-1037.55,'2017-05-22 18:25:33','diego');
INSERT INTO `charges` VALUES (199,78,-518.77,'2017-05-22 18:25:33','diego');
INSERT INTO `charges` VALUES (200,80,-1037.55,'2017-05-22 18:25:33','diego');
INSERT INTO `charges` VALUES (201,81,-1556.31,'2017-05-22 18:25:34','diego');
INSERT INTO `charges` VALUES (202,82,-1037.55,'2017-05-22 18:25:34','diego');
INSERT INTO `charges` VALUES (203,83,-1037.55,'2017-05-22 18:25:34','diego');
INSERT INTO `charges` VALUES (204,84,-1556.31,'2017-05-22 18:25:34','diego');
INSERT INTO `charges` VALUES (205,85,-1037.55,'2017-05-22 18:25:34','diego');
INSERT INTO `charges` VALUES (206,86,-518.77,'2017-05-22 18:25:34','diego');
INSERT INTO `charges` VALUES (207,87,-518.77,'2017-05-22 18:25:34','diego');
INSERT INTO `charges` VALUES (208,88,-1037.55,'2017-05-22 18:25:34','diego');
INSERT INTO `charges` VALUES (209,89,-1556.31,'2017-05-22 18:25:34','diego');
INSERT INTO `charges` VALUES (210,90,-1037.55,'2017-05-22 18:25:34','diego');
INSERT INTO `charges` VALUES (211,91,-1037.55,'2017-05-22 18:25:34','diego');
INSERT INTO `charges` VALUES (212,92,-1556.31,'2017-05-22 18:25:34','diego');
INSERT INTO `charges` VALUES (213,93,-1037.55,'2017-05-22 18:25:34','diego');
INSERT INTO `charges` VALUES (214,94,-518.77,'2017-05-22 18:25:34','diego');
INSERT INTO `charges` VALUES (215,95,-518.77,'2017-05-22 18:25:34','diego');
INSERT INTO `charges` VALUES (216,96,-1037.55,'2017-05-22 18:25:34','diego');
INSERT INTO `charges` VALUES (217,97,-1556.31,'2017-05-22 18:25:34','diego');
INSERT INTO `charges` VALUES (218,98,-1037.55,'2017-05-22 18:25:34','diego');
INSERT INTO `charges` VALUES (219,99,-1037.55,'2017-05-22 18:25:34','diego');
INSERT INTO `charges` VALUES (220,100,-1556.31,'2017-05-22 18:25:34','diego');
INSERT INTO `charges` VALUES (221,101,-1037.55,'2017-05-22 18:25:34','diego');
INSERT INTO `charges` VALUES (222,102,-518.77,'2017-05-22 18:25:34','diego');
INSERT INTO `charges` VALUES (223,103,-518.77,'2017-05-22 18:25:35','diego');
INSERT INTO `charges` VALUES (224,104,-1037.55,'2017-05-22 18:25:35','diego');
INSERT INTO `charges` VALUES (225,105,-1556.31,'2017-05-22 18:25:35','diego');
INSERT INTO `charges` VALUES (226,106,-1037.55,'2017-05-22 18:25:35','diego');
INSERT INTO `charges` VALUES (227,107,-1037.55,'2017-05-22 18:25:35','diego');
INSERT INTO `charges` VALUES (228,108,-1556.31,'2017-05-22 18:25:35','diego');
INSERT INTO `charges` VALUES (229,109,-1037.55,'2017-05-22 18:25:35','diego');
INSERT INTO `charges` VALUES (230,110,-518.77,'2017-05-22 18:25:35','diego');
INSERT INTO `charges` VALUES (231,111,-518.77,'2017-05-22 18:25:35','diego');
INSERT INTO `charges` VALUES (232,112,-1037.55,'2017-05-22 18:25:35','diego');
INSERT INTO `charges` VALUES (233,113,-1556.31,'2017-05-22 18:25:35','diego');
INSERT INTO `charges` VALUES (234,114,-1037.55,'2017-05-22 18:25:35','diego');
INSERT INTO `charges` VALUES (235,115,-1037.55,'2017-05-22 18:25:35','diego');
INSERT INTO `charges` VALUES (236,116,-1556.31,'2017-05-22 18:25:35','diego');
INSERT INTO `charges` VALUES (237,117,-1037.55,'2017-05-22 18:25:35','diego');
INSERT INTO `charges` VALUES (238,118,-518.77,'2017-05-22 18:25:35','diego');
INSERT INTO `charges` VALUES (239,119,-518.77,'2017-05-22 18:25:35','diego');
INSERT INTO `charges` VALUES (240,120,-1037.55,'2017-05-22 18:25:35','diego');
/*!40000 ALTER TABLE `charges` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `db_logs`
--

DROP TABLE IF EXISTS `db_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `db_logs` (
  `logs_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `logs_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `logs_user` varchar(50) NOT NULL,
  `log_query` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`logs_id`)
) ENGINE=InnoDB AUTO_INCREMENT=140 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `db_logs`
--

LOCK TABLES `db_logs` WRITE;
/*!40000 ALTER TABLE `db_logs` DISABLE KEYS */;
INSERT INTO `db_logs` VALUES (1,'2017-04-09 04:08:56','login:admin@caracol','SELECT user_user, user_pwd, user_type FROM users WHERE user_user = \'admin@caracol\' AND user_pwd = \'1234\'');
INSERT INTO `db_logs` VALUES (2,'2017-04-09 04:11:25','admin@caracol','SELECT user_id FROM users WHERE user_user = \'gab@bat\'');
INSERT INTO `db_logs` VALUES (3,'2017-04-09 04:11:26','admin@caracol','INSERT INTO users VALUES (NULL, \'gab@bat\', \'1234\', \'2\', \'admin@caracol\', NULL)');
INSERT INTO `db_logs` VALUES (4,'2017-04-09 04:11:26','admin@caracol','SELECT user_id FROM users WHERE user_user = \'gab@bat\'');
INSERT INTO `db_logs` VALUES (5,'2017-04-09 04:11:26','admin@caracol','INSERT INTO userdata VALUES (NULL, \'Gabriel\', \'Batistuta\', \'e80111234\', \'1A\', 1)');
INSERT INTO `db_logs` VALUES (6,'2017-04-09 04:12:40','admin@caracol','SELECT user_id FROM users WHERE user_user = \'admin@caracol\'');
INSERT INTO `db_logs` VALUES (7,'2017-04-09 04:12:40','admin@caracol','INSERT INTO users VALUES (NULL, \'admin@caracol\', \'1234\', \'1\', \'admin@caracol\', NULL)');
INSERT INTO `db_logs` VALUES (8,'2017-04-09 04:12:40','admin@caracol','SELECT user_id FROM users WHERE user_user = \'admin@caracol\'');
INSERT INTO `db_logs` VALUES (9,'2017-04-09 04:12:40','admin@caracol','INSERT INTO userdata VALUES (NULL, \'Stalin\', \'Rivas\', \'v9456345\', \'9H\', 2)');
INSERT INTO `db_logs` VALUES (10,'2017-04-09 04:18:51','admin@caracol','INSERT INTO users VALUES (NULL, \'guest@caracol\', \'1234\', \'2\', \'admin@caracol\', NULL)');
INSERT INTO `db_logs` VALUES (11,'2017-04-09 05:24:53','admin@caracol','INSERT INTO users VALUES (NULL, \'un@correo\', \'1234\', \'2\', 1, \'admin@caracol\', NULL)');
INSERT INTO `db_logs` VALUES (13,'2017-04-09 14:21:54','register:$email','INSERT INTO users VALUES (NULL, \'salo@correo\', \'1234\', 2, 0, \'register:salo@correo\', NULL)');
INSERT INTO `db_logs` VALUES (14,'2017-04-09 14:23:10','register:$email','INSERT INTO users VALUES (NULL, \'paolo@correo\', \'1234\', 2, 0, \'register:paolo@correo\', NULL)');
INSERT INTO `db_logs` VALUES (15,'2017-04-09 15:46:33','admin@caracol','UPDATE users SET user_active = 1 WHERE user_user = \'gab@bat\' OR user_user = \'salo@correo\' ');
INSERT INTO `db_logs` VALUES (16,'2017-04-09 16:17:34','register:$email','INSERT INTO users VALUES (NULL, \'pa@cor\', \'1234\', 2, 0, \'register:pa@cor\', NULL)');
INSERT INTO `db_logs` VALUES (17,'2017-04-09 16:18:05','register:$email','INSERT INTO users VALUES (NULL, \'mari@marara\', \'1234\', 2, 0, \'register:mari@marara\', NULL)');
INSERT INTO `db_logs` VALUES (18,'2017-04-09 16:18:40','admin@caracol','UPDATE users SET user_active = 1 WHERE user_user = \'gab@bat\' ');
INSERT INTO `db_logs` VALUES (19,'2017-04-09 16:20:58','admin@caracol','UPDATE users SET user_active = 1 WHERE user_user = \'gab@bat\' ');
INSERT INTO `db_logs` VALUES (20,'2017-04-09 16:50:14','admin@caracol','DELETE FROM users WHERE user_user = \'pa@cor\' OR user_user = \'mari@marara\' ');
INSERT INTO `db_logs` VALUES (21,'2017-04-09 16:55:26','admin@caracol','UPDATE users SET user_active = 1 WHERE user_user = \'salo@correo\' ');
INSERT INTO `db_logs` VALUES (22,'2017-04-09 16:55:47','register:$email','INSERT INTO users VALUES (NULL, \'che@ge\', \'1234\', 2, 0, \'register:che@ge\', NULL)');
INSERT INTO `db_logs` VALUES (23,'2017-04-09 16:56:04','admin@caracol','DELETE FROM users WHERE user_user = \'che@ge\' ');
INSERT INTO `db_logs` VALUES (24,'2017-04-12 15:51:55','admin@caracol','INSERT INTO bills VALUES (NULL, \'2017-04-12\', \'Corporacición Eléctrica Nacional, S.A. (CORPOELEC)\', \'G200100141\', \'2\', \'4\', \'1111\', \'133.32\', \'1244.32\', \'1\', \'\', \'admin@caracol\', NULL)');
INSERT INTO `db_logs` VALUES (25,'2017-04-12 15:55:08','admin@caracol','INSERT INTO bills VALUES (NULL, \'2017-04-11\', \'Pedro Perez\', \'V12331313\', \'1\', \'3\', \'12121.21\', \'1454.55\', \'13575.76\', \'2\', \'El señor se róbo la desmalezadora\', \'admin@caracol\', NULL)');
INSERT INTO `db_logs` VALUES (26,'2017-04-13 01:37:06','register:$email','INSERT INTO users VALUES (NULL, \'dennis@berk\', \'1234\', 2, 0, \'register:dennis@berk\', NULL)');
INSERT INTO `db_logs` VALUES (27,'2017-04-13 14:51:09','admin@caracol','INSERT INTO users VALUES (NULL, \'oleg@caracol\', \'1234\', \'1\', 1, \'admin@caracol\', NULL)');
INSERT INTO `db_logs` VALUES (28,'2017-04-13 14:54:20','admin@caracol','INSERT INTO users VALUES (NULL, \'oleg@correo\', \'1234\', \'1\', 1, \'admin@caracol\', NULL)');
INSERT INTO `db_logs` VALUES (29,'2017-04-13 14:55:30','admin@caracol','INSERT INTO users VALUES (NULL, \'ole@correo\', \'1234\', \'1\', 1, \'admin@caracol\', NULL)');
INSERT INTO `db_logs` VALUES (30,'2017-04-13 23:56:30','admin@caracol','INSERT INTO users VALUES (NULL, \'u1n@correo\', \'1234\', \'2\', 1, \'admin@caracol\', NULL)');
INSERT INTO `db_logs` VALUES (31,'2017-04-14 00:20:10','admin@caracol','INSERT INTO users VALUES (NULL, \'cheto@correo\', \'1234\', \'2\', 1, \'admin@caracol\', NULL)');
INSERT INTO `db_logs` VALUES (32,'2017-04-14 00:24:58','admin@caracol','INSERT INTO users VALUES (NULL, \'pun@correo\', \'1234\', \'1\', 1, \'admin@caracol\', NULL)');
INSERT INTO `db_logs` VALUES (33,'2017-04-14 00:26:04','admin@caracol','INSERT INTO users VALUES (NULL, \'pun@correo\', \'1234\', \'1\', 1, \'admin@caracol\', NULL)');
INSERT INTO `db_logs` VALUES (34,'2017-04-14 00:28:04','admin@caracol','INSERT INTO users VALUES (NULL, \'pun@correo\', \'1234\', \'1\', 1, \'admin@caracol\', NULL)');
INSERT INTO `db_logs` VALUES (35,'2017-04-14 00:29:05','admin@caracol','INSERT INTO users VALUES (NULL, \'pun@correo\', \'1234\', \'1\', 1, \'admin@caracol\', NULL)');
INSERT INTO `db_logs` VALUES (36,'2017-04-14 00:29:37','admin@caracol','INSERT INTO users VALUES (NULL, \'pun@correo\', \'1234\', \'1\', 1, \'admin@caracol\', NULL)');
INSERT INTO `db_logs` VALUES (37,'2017-04-14 00:32:02','admin@caracol','INSERT INTO users VALUES (NULL, \'pun@correo\', \'1234\', \'1\', 1, \'admin@caracol\', NULL)');
INSERT INTO `db_logs` VALUES (38,'2017-04-14 00:34:00','admin@caracol','INSERT INTO users VALUES (NULL, \'pun@correo\', \'1234\', \'1\', 1, \'admin@caracol\', NULL)');
INSERT INTO `db_logs` VALUES (39,'2017-04-14 00:37:04','admin@caracol','INSERT INTO users VALUES (NULL, \'pun@correo\', \'1234\', \'1\', 1, \'admin@caracol\', NULL)');
INSERT INTO `db_logs` VALUES (40,'2017-04-14 00:39:44','admin@caracol','INSERT INTO users VALUES (NULL, \'pun@correo\', \'1234\', \'1\', 1, \'admin@caracol\', NULL)');
INSERT INTO `db_logs` VALUES (41,'2017-04-14 00:42:23','admin@caracol','INSERT INTO users VALUES (NULL, \'pun@correo\', \'1234\', \'1\', 1, \'admin@caracol\', NULL)');
INSERT INTO `db_logs` VALUES (42,'2017-04-14 00:44:40','admin@caracol','INSERT INTO users VALUES (NULL, \'pun@correo\', \'1234\', \'1\', 1, \'admin@caracol\', NULL)');
INSERT INTO `db_logs` VALUES (43,'2017-04-14 00:45:55','admin@caracol','INSERT INTO users VALUES (NULL, \'pun@correo\', \'1234\', \'1\', 1, \'admin@caracol\', NULL)');
INSERT INTO `db_logs` VALUES (44,'2017-04-14 00:49:53','admin@caracol','INSERT INTO users VALUES (NULL, \'pun@correo\', \'1234\', \'1\', 1, \'admin@caracol\', NULL)');
INSERT INTO `db_logs` VALUES (45,'2017-04-14 00:51:35','admin@caracol','INSERT INTO users VALUES (NULL, \'puen@correo\', \'1234\', \'2\', 1, \'admin@caracol\', NULL)');
INSERT INTO `db_logs` VALUES (46,'2017-04-14 00:55:35','admin@caracol','INSERT INTO users VALUES (NULL, \'diego@caracol\', \'1234\', \'2\', 1, \'admin@caracol\', NULL)');
INSERT INTO `db_logs` VALUES (47,'2017-04-14 01:02:17','register:$email','INSERT INTO users VALUES (NULL, \'meri@mat\', \'1234\', 2, 0, \'register:meri@mat\', NULL)');
INSERT INTO `db_logs` VALUES (48,'2017-04-14 16:43:15','register:$email','INSERT INTO users VALUES (NULL, \'luz@gmail.com\', \'1234\', 2, 0, \'register:luz@gmail.com\', NULL)');
INSERT INTO `db_logs` VALUES (49,'2017-04-14 16:43:53','admin@caracol','UPDATE users SET user_active = 1 WHERE user_user = \'luz@gmail_com\' ');
INSERT INTO `db_logs` VALUES (50,'2017-04-14 16:45:27','admin@caracol','INSERT INTO bills VALUES (NULL, \'2017-01-01\', \'Hidrológica de la Regio Capital, C.A. (HIDROCAPITAL)\', \'G200121076\', \'3\', \'4\', \'5512.12\', \'661.45\', \'6173.57\', \'1\', \'ninguna\', \'admin@caracol\', NULL)');
INSERT INTO `db_logs` VALUES (51,'2017-04-14 17:13:08','admin@caracol','INSERT INTO users VALUES (NULL, \'punn@correo\', \'1234\', \'2\', 1, \'admin@caracol\', NULL)');
INSERT INTO `db_logs` VALUES (52,'2017-04-16 17:47:36','admin@caracol','INSERT INTO bills VALUES (NULL, \'2017-04-16\', \'María Laura Mora Torta\', \'V13900343\', \'6\', \'4\', \'85\', \'0\', \'85\', \'2\', \'            \', \'admin@caracol\', NULL)');
INSERT INTO `db_logs` VALUES (53,'2017-04-16 17:48:12','admin@caracol','INSERT INTO bills VALUES (NULL, \'2017-04-15\', \'Proyectos Técnicos, S.A.\', \'J311429506\', \'5\', \'4\', \'15490.7\', \'1858.88\', \'17349.58\', \'1\', \'            \', \'admin@caracol\', NULL)');
INSERT INTO `db_logs` VALUES (54,'2017-04-16 17:49:29','admin@caracol','INSERT INTO bills VALUES (NULL, \'2017-04-13\', \'varios Proveedores\', \'J000000000\', \'7\', \'4\', \'23000\', \'2760\', \'25760\', \'1\', \'20 bolsas de basura\r\n2 lts de detergente\', \'admin@caracol\', NULL)');
INSERT INTO `db_logs` VALUES (55,'2017-04-16 17:54:38','admin@caracol','INSERT INTO bills VALUES (NULL, \'2017-04-13\', \'Hidrológica de la Regio Capital, C.A. (HIDROCAPITAL)\', \'G200121076\', \'3\', \'4\', \'8500\', \'1020\', \'9520\', \'1\', \'            \', \'admin@caracol\', NULL)');
INSERT INTO `db_logs` VALUES (56,'2017-04-16 17:56:01','admin@caracol','INSERT INTO bills VALUES (NULL, \'2017-04-16\', \'Corporacición Eléctrica Nacional, S.A. (CORPOELEC)\', \'G200100141\', \'2\', \'4\', \'60000.44\', \'7200.05\', \'67200.49\', \'1\', \'            \', \'admin@caracol\', NULL)');
INSERT INTO `db_logs` VALUES (57,'2017-04-20 19:20:59','admin@caracol','INSERT INTO payments VALUES (NULL, \'2017-04-06\', \'2\', \'2\', \'3444000\', \'4\', \'60090\', 0, \'notas\', NULL, \'2\')');
INSERT INTO `db_logs` VALUES (58,'2017-04-25 21:12:01','gab@bat','INSERT INTO payments VALUES (NULL, \'2017-04-06\', \'1\', \'2\', \'33533\', \'4\', \'1000\', 0, \'\', NULL, \'1\')');
INSERT INTO `db_logs` VALUES (59,'2017-04-25 21:22:07','gab@bat','INSERT INTO payments VALUES (NULL, \'2017-04-20\', \'1\', \'2\', \'646464\', \'1\', \'1201\', 0, \'\', NULL, \'1\')');
INSERT INTO `db_logs` VALUES (60,'2017-04-25 21:25:25','gab@bat','INSERT INTO payments VALUES (NULL, \'2017-04-01\', \'1\', \'2\', \'334434\', \'3\', \'2020\', 0, \'\', NULL, \'1\')');
INSERT INTO `db_logs` VALUES (61,'2017-05-18 18:39:39','admin@caracol','INSERT INTO payments VALUES (NULL, \'2017-05-11\', \'2\', \'2\', \'1010011\', \'4\', \'1245\', 0, \'\', NULL, \'2\')');
INSERT INTO `db_logs` VALUES (62,'2017-05-21 18:38:24','register:$email','INSERT INTO users VALUES (NULL, \'david@villa.paris\', \'123456\', 2, 0, \'register:david@villa.paris\', NULL)');
INSERT INTO `db_logs` VALUES (63,'2017-05-21 18:48:36','register:$email','INSERT INTO users VALUES (NULL, \'david@villa.paris\', \'123456\', 2, 0, \'register:david@villa.paris\', NULL)');
INSERT INTO `db_logs` VALUES (64,'2017-05-21 18:52:38','register:$email','INSERT INTO users VALUES (NULL, \'david@villa.paris\', \'123456\', 2, 0, \'register:david@villa.paris\', NULL)');
INSERT INTO `db_logs` VALUES (65,'2017-05-21 21:04:50','register:$email','INSERT INTO users VALUES (NULL, \'david@villa.paris\', \'123456\', 2, 0, \'register:david@villa.paris\', NULL)');
INSERT INTO `db_logs` VALUES (66,'2017-05-21 21:07:30','register:$email','INSERT INTO users VALUES (NULL, \'david@villa.paris\', \'123456\', 2, 0, \'register:david@villa.paris\', NULL)');
INSERT INTO `db_logs` VALUES (67,'2017-05-22 15:09:01','admin@caracol','INSERT INTO bills VALUES (NULL, \'2017-05-03\', \'SERVICIOS\', \'Servicios electrónicos\', \'Servicios y Proyectos Cosmonauta C.A.\', \'J000456789\', 1, \'TDD\', \'FACTURA\', 7, 11990.9, 1438.91, 13429.81, \'admin@caracol\', NULL)');
INSERT INTO `db_logs` VALUES (68,'2017-05-22 23:18:12','admin@caracol','INSERT INTO payments VALUES (NULL, \'2017-05-10\', \'2\', \'2\', \'10000\', \'1\', \'1000\', 0, \'\', NULL, \'2\')');
INSERT INTO `db_logs` VALUES (69,'2017-05-23 02:00:23','admin@caracol','INSERT INTO payments VALUES (NULL, \'2017-05-10\', \'2\', \'1\', \'2000\', \'2\', \'1232\', 0, \'\', NULL, \'2\')');
INSERT INTO `db_logs` VALUES (70,'2017-05-23 02:01:54','admin@caracol','INSERT INTO payments VALUES (NULL, \'2017-05-18\', \'2\', \'2\', \'23456\', \'5\', \'903.45\', 0, \'\', NULL, \'2\')');
INSERT INTO `db_logs` VALUES (71,'2017-05-23 02:09:47','admin@caracol','INSERT INTO payments VALUES (NULL, \'2017-05-01\', \'2\', \'2\', \'1010011\', \'4\', 1223.36, 0, \'\', NULL, \'2\')');
INSERT INTO `db_logs` VALUES (72,'2017-05-23 02:55:34','admin@caracol','INSERT INTO payments VALUES (NULL, \'2017-05-01\', \'2\', \'2\', \'10010\', \'6\', 1200.3, 0, \'\', NULL, \'2\')');
INSERT INTO `db_logs` VALUES (73,'2017-06-18 13:54:42','admin@caracol','INSERT INTO payments VALUES (NULL, \'2017-06-13\', \'2\', \'2\', \'345078\', \'2\', 1400, 0, \'ninguna\', NULL, \'2\')');
INSERT INTO `db_logs` VALUES (74,'2017-06-19 02:27:23','admin@caracol','INSERT INTO users VALUES (NULL, \'tumama@caracol\', \'123456\', \'\', \'\', 2, 1, \'admin@caracol\', NULL)');
INSERT INTO `db_logs` VALUES (75,'2017-06-19 02:29:32','admin@caracol','INSERT INTO users VALUES (NULL, \'tumama@caracol\', \'123456\', \'\', \'\', 2, 1, \'admin@caracol\', NULL)');
INSERT INTO `db_logs` VALUES (76,'2017-06-19 02:32:50','admin@caracol','INSERT INTO users VALUES (NULL, \'tumama@caracol\', \'123456\', \'\', \'\', 2, 1, \'admin@caracol\', NULL)');
INSERT INTO `db_logs` VALUES (77,'2017-06-19 02:39:32','admin@caracol','INSERT INTO users VALUES (NULL, \'tumama@caracol\', \'123456\', \'\', \'\', 2, 1, \'admin@caracol\', NULL)');
INSERT INTO `db_logs` VALUES (78,'2017-06-19 02:46:29','admin@caracol','INSERT INTO users VALUES (NULL, \'\', \'123456\', \'\', \'\', 2, 1, \'admin@caracol\', NULL)');
INSERT INTO `db_logs` VALUES (79,'2017-06-19 02:49:41','admin@caracol','INSERT INTO users VALUES (NULL, \'chuchu@cucu\', \'123456\', \'\', \'\', 2, 1, \'admin@caracol\', NULL)');
INSERT INTO `db_logs` VALUES (80,'2017-06-19 02:58:27','admin@caracol','INSERT INTO users VALUES (NULL, \'mono@jojoy\', \'123456\', \'\', \'\', 2, 1, \'admin@caracol\', NULL)');
INSERT INTO `db_logs` VALUES (81,'2017-06-19 03:38:31','admin@caracol','INSERT INTO users VALUES (NULL, \'ana@kurni\', \'123456\', \'\', \'\', 2, 1, \'admin@caracol\', NULL)');
INSERT INTO `db_logs` VALUES (82,'2017-06-19 03:40:23','admin@caracol','INSERT INTO users VALUES (NULL, \'shimo@perez\', \'123456\', \'\', \'\', 2, 1, \'admin@caracol\', NULL)');
INSERT INTO `db_logs` VALUES (83,'2017-06-19 03:42:09','admin@caracol','INSERT INTO users VALUES (NULL, \'chu@put\', \'123456\', \'\', \'\', 1, 1, \'admin@caracol\', NULL)');
INSERT INTO `db_logs` VALUES (84,'2017-06-19 03:50:33','admin@caracol','INSERT INTO users VALUES (NULL, \'bich@perra\', \'123456\', \'\', \'\', 1, 1, \'admin@caracol\', NULL)');
INSERT INTO `db_logs` VALUES (85,'2017-06-19 03:52:11','admin@caracol','INSERT INTO users VALUES (NULL, \'elborra@dor\', \'123456\', \'\', \'\', 1, 1, \'admin@caracol\', NULL)');
INSERT INTO `db_logs` VALUES (86,'2017-06-19 11:59:55','admin@caracol','INSERT INTO payments VALUES (NULL, \'2017-06-14\', \'2\', \'2\', \'66578\', \'8\', 700, 0, \'\', NULL, \'2\')');
INSERT INTO `db_logs` VALUES (87,'2017-06-19 12:00:01','admin@caracol','INSERT INTO payments VALUES (NULL, \'2017-06-14\', \'2\', \'2\', \'66578\', \'8\', 700, 0, \'\', NULL, \'2\')');
INSERT INTO `db_logs` VALUES (88,'2017-06-19 12:00:10','admin@caracol','INSERT INTO payments VALUES (NULL, \'2017-06-14\', \'2\', \'2\', \'66578\', \'8\', 700, 0, \'\', NULL, \'2\')');
INSERT INTO `db_logs` VALUES (89,'2017-06-19 12:01:48','admin@caracol','INSERT INTO payments VALUES (NULL, \'2017-06-14\', \'2\', \'2\', \'66578\', \'8\', 700, 0, \'\', NULL, \'2\')');
INSERT INTO `db_logs` VALUES (90,'2017-06-19 12:02:19','admin@caracol','INSERT INTO payments VALUES (NULL, \'2017-06-14\', \'2\', \'2\', \'66578\', \'8\', 700, 0, \'\', NULL, \'2\')');
INSERT INTO `db_logs` VALUES (91,'2017-06-19 12:02:20','admin@caracol','INSERT INTO payments VALUES (NULL, \'2017-06-14\', \'2\', \'2\', \'66578\', \'8\', 700, 0, \'\', NULL, \'2\')');
INSERT INTO `db_logs` VALUES (92,'2017-06-19 12:03:32','admin@caracol','INSERT INTO payments VALUES (NULL, \'2017-06-21\', \'2\', \'1\', \'1111111\', \'4\', 770, 0, \'\', NULL, \'2\')');
INSERT INTO `db_logs` VALUES (93,'2017-06-19 12:04:04','admin@caracol','INSERT INTO payments VALUES (NULL, \'2017-06-21\', \'2\', \'1\', \'1111111\', \'4\', 770, 0, \'\', NULL, \'2\')');
INSERT INTO `db_logs` VALUES (94,'2017-06-19 12:05:32','admin@caracol','INSERT INTO payments VALUES (NULL, \'2017-06-05\', \'2\', \'1\', \'11111\', \'4\', 700, 0, \'\', NULL, \'2\')');
INSERT INTO `db_logs` VALUES (95,'2017-06-19 12:05:39','admin@caracol','INSERT INTO payments VALUES (NULL, \'2017-06-05\', \'2\', \'1\', \'11111\', \'4\', 700, 0, \'\', NULL, \'2\')');
INSERT INTO `db_logs` VALUES (96,'2017-06-19 12:09:04','admin@caracol','INSERT INTO payments VALUES (NULL, \'2017-06-05\', \'2\', \'1\', \'11111\', \'4\', 700, 0, \'\', NULL, \'2\')');
INSERT INTO `db_logs` VALUES (97,'2017-06-19 12:09:32','admin@caracol','INSERT INTO payments VALUES (NULL, \'2017-06-01\', \'2\', \'1\', \'1111\', \'6\', 700, 0, \'\', NULL, \'2\')');
INSERT INTO `db_logs` VALUES (98,'2017-06-19 12:09:38','admin@caracol','INSERT INTO payments VALUES (NULL, \'2017-06-01\', \'2\', \'1\', \'1111\', \'6\', 700, 0, \'\', NULL, \'2\')');
INSERT INTO `db_logs` VALUES (99,'2017-06-19 14:21:41','admin@caracol','INSERT INTO payments VALUES (NULL, \'2017-06-14\', \'2\', \'2\', \'4545\', \'4\', 705, 0, \'\', NULL, \'2\')');
INSERT INTO `db_logs` VALUES (100,'2017-06-19 14:26:33','admin@caracol','INSERT INTO payments VALUES (NULL, \'2017-06-08\', \'2\', \'2\', \'3232\', \'4\', 555, 0, \'\', NULL, \'2\')');
INSERT INTO `db_logs` VALUES (101,'2017-06-19 14:35:21','admin@caracol','INSERT INTO payments VALUES (NULL, \'2017-06-07\', \'2\', \'1\', \'111\', \'2\', 1212, 0, \'\', NULL, \'2\')');
INSERT INTO `db_logs` VALUES (102,'2017-06-19 20:11:58','register:$email','INSERT INTO users VALUES (NULL, \'pepe@mujica\', \'\', \'\', \'123456\', 2, 0, \'register:pepe@mujica\', NULL)');
INSERT INTO `db_logs` VALUES (103,'2017-06-19 21:31:01','register:$email','INSERT INTO users VALUES (NULL, \'pepe@mujican\', \'\', \'\', \'e10adc3949ba59abbe56e057f20f883e\', 2, 0, \'register:pepe@mujican\', NULL)');
INSERT INTO `db_logs` VALUES (104,'2017-06-19 21:33:23','register:$email','INSERT INTO users VALUES (NULL, \'pepe@mujican\', \'\', \'\', \'e10adc3949ba59abbe56e057f20f883e\', 2, 0, \'register:pepe@mujican\', NULL)');
INSERT INTO `db_logs` VALUES (105,'2017-06-19 21:35:20','register:$email','INSERT INTO users VALUES (NULL, \'pepe@mujican\', \'\', \'\', \'e10adc3949ba59abbe56e057f20f883e\', 2, 0, \'register:pepe@mujican\', NULL)');
INSERT INTO `db_logs` VALUES (106,'2017-06-19 21:37:11','register:$email','INSERT INTO users VALUES (NULL, \'pepe@mujican\', \'\', \'\', \'e10adc3949ba59abbe56e057f20f883e\', 2, 0, \'register:pepe@mujican\', NULL)');
INSERT INTO `db_logs` VALUES (107,'2017-06-19 21:39:07','register:$email','INSERT INTO users VALUES (NULL, \'pepe@mujica\', \'\', \'\', \'e10adc3949ba59abbe56e057f20f883e\', 2, 0, \'register:pepe@mujica\', NULL)');
INSERT INTO `db_logs` VALUES (108,'2017-06-19 21:52:20','register:$email','INSERT INTO users VALUES (NULL, \'pepe@mujican\', \'\', \'\', \'fcea920f7412b5da7be0cf42b8c93759\', 2, 0, \'register:pepe@mujican\', NULL)');
INSERT INTO `db_logs` VALUES (109,'2017-06-19 21:54:21','register:$email','INSERT INTO users VALUES (NULL, \'pepe@mujicano\', \'\', \'\', \'e10adc3949ba59abbe56e057f20f883e\', 2, 0, \'register:pepe@mujicano\', NULL)');
INSERT INTO `db_logs` VALUES (110,'2017-06-19 22:01:02','register:$email','INSERT INTO users VALUES (NULL, \'pepe@mujica\', \'\', \'\', \'e10adc3949ba59abbe56e057f20f883e\', 2, 0, \'register:pepe@mujica\', NULL)');
INSERT INTO `db_logs` VALUES (111,'2017-06-19 22:02:23','register:$email','INSERT INTO users VALUES (NULL, \'pepe@mujican\', \'\', \'\', \'e10adc3949ba59abbe56e057f20f883e\', 2, 0, \'register:pepe@mujican\', NULL)');
INSERT INTO `db_logs` VALUES (112,'2017-06-19 22:07:17','register:$email','INSERT INTO users VALUES (NULL, \'pepe@mujicano\', \'\', \'\', \'96e79218965eb72c92a549dd5a330112\', 2, 0, \'register:pepe@mujicano\', NULL)');
INSERT INTO `db_logs` VALUES (113,'2017-06-19 22:09:13','register:$email','INSERT INTO users VALUES (NULL, \'pepe@mujicana\', \'\', \'\', \'96e79218965eb72c92a549dd5a330112\', 2, 0, \'register:pepe@mujicana\', NULL)');
INSERT INTO `db_logs` VALUES (114,'2017-06-19 22:18:29','register:$email','INSERT INTO users VALUES (NULL, \'pepe@mujica\', \'\', \'\', \'96e79218965eb72c92a549dd5a330112\', 2, 0, \'register:pepe@mujica\', NULL)');
INSERT INTO `db_logs` VALUES (115,'2017-06-19 22:19:56','register:$email','INSERT INTO users VALUES (NULL, \'pepe@mujican\', \'\', \'\', \'e3ceb5881a0a1fdaad01296d7554868d\', 2, 0, \'register:pepe@mujican\', NULL)');
INSERT INTO `db_logs` VALUES (116,'2017-06-19 22:24:03','register:$email','INSERT INTO users VALUES (NULL, \'pepe@mujicano\', \'\', \'\', \'e3ceb5881a0a1fdaad01296d7554868d\', 2, 0, \'register:pepe@mujicano\', NULL)');
INSERT INTO `db_logs` VALUES (117,'2017-06-19 22:26:55','register:$email','INSERT INTO users VALUES (NULL, \'pepe@mujicana\', \'\', \'\', \'e3ceb5881a0a1fdaad01296d7554868d\', 2, 0, \'register:pepe@mujicana\', NULL)');
INSERT INTO `db_logs` VALUES (118,'2017-06-19 22:28:29','register:$email','INSERT INTO users VALUES (NULL, \'pepe@mujicanan\', \'\', \'\', \'96e79218965eb72c92a549dd5a330112\', 2, 0, \'register:pepe@mujicanan\', NULL)');
INSERT INTO `db_logs` VALUES (119,'2017-06-23 20:08:36','admin@caracol','INSERT INTO bills VALUES (NULL, \'2017-06-23\', \'A17\', \'SERVICIOS\', \'Una descripción\', \'Hidrológica de la Regio Capital, C.A. (HIDROCAPITAL)\', \'G200121076\', 1, \'TDD\', \'FACTURA\', 0, 34900, 4188, 39088, \'admin@caracol\', NULL)');
INSERT INTO `db_logs` VALUES (120,'2017-06-29 19:08:14','register:$email','INSERT INTO users VALUES (NULL, \'oscar@cordova.try\', \'e10adc3949ba59abbe56e057f20f883e\', \'\', \'\', 2, 0, \'register:oscar@cordova.try\', NULL)');
INSERT INTO `db_logs` VALUES (121,'2017-06-29 19:10:06','register:$email','INSERT INTO users VALUES (NULL, \'oscar@cordova.try\', \'e10adc3949ba59abbe56e057f20f883e\', \'\', \'\', 2, 0, \'register:oscar@cordova.try\', NULL)');
INSERT INTO `db_logs` VALUES (122,'2017-06-29 19:16:29','register:$email','INSERT INTO users VALUES (NULL, \'oscar@cordova.trys\', \'e10adc3949ba59abbe56e057f20f883e\', \'\', \'\', 2, 0, \'register:oscar@cordova.trys\', NULL)');
INSERT INTO `db_logs` VALUES (123,'2017-06-29 19:20:08','register:$email','INSERT INTO users VALUES (NULL, \'oscar@cordova.try\', \'e10adc3949ba59abbe56e057f20f883e\', \'\', \'\', 2, 1, \'register:oscar@cordova.try\', NULL)');
INSERT INTO `db_logs` VALUES (124,'2017-06-29 19:23:42','register:$email','INSERT INTO users VALUES (NULL, \'oscar@cordova.try\', \'e10adc3949ba59abbe56e057f20f883e\', \'\', \'\', 2, 1, \'register:oscar@cordova.try\', NULL)');
INSERT INTO `db_logs` VALUES (125,'2017-06-29 19:25:13','register:$email','INSERT INTO users VALUES (NULL, \'oscar@cordova.try\', \'e10adc3949ba59abbe56e057f20f883e\', \'\', \'\', 2, 1, \'register:oscar@cordova.try\', NULL)');
INSERT INTO `db_logs` VALUES (126,'2017-06-29 19:27:53','register:$email','INSERT INTO users VALUES (NULL, \'oscar@cordova.try\', \'e10adc3949ba59abbe56e057f20f883e\', \'\', \'\', 1, 1, \'register:oscar@cordova.try\', NULL)');
INSERT INTO `db_logs` VALUES (127,'2017-06-29 19:33:13','register:$email','INSERT INTO users VALUES (NULL, \'carlos@valderrama.try\', \'e10adc3949ba59abbe56e057f20f883e\', \'\', \'\', 1, 1, \'register:carlos@valderrama.try\', NULL)');
INSERT INTO `db_logs` VALUES (128,'2017-06-29 19:53:52','oscar@cordova.try','INSERT INTO bills VALUES (NULL, \'2017-06-22\', \'Country_Park\', \'MATERIALES\', \'Esto es una prueba\', \'Pepito\', \'G020003332\', 2, \'CAJA CHICA\', \'FACTURA\', 0, 10000, 1200, 11200, \'oscar@cordova.try\', NULL)');
INSERT INTO `db_logs` VALUES (129,'2017-06-30 19:27:37','oscar@cordova.try','INSERT INTO users VALUES (NULL, \'susi@lacallada\', \'1234\', \'\', \'\', 2, 1, \'oscar@cordova.try\', NULL)');
INSERT INTO `db_logs` VALUES (130,'2017-06-30 19:40:07','susi@lacallada','INSERT INTO payments VALUES (NULL, \'2017-06-20\', \'Country_Park\', \'121\', \'1\', \'340098\', 4, 3400, 0, \'Para que no digan que soy mala paga\', NULL, \'238\')');
INSERT INTO `db_logs` VALUES (131,'2017-06-30 20:40:54','register:$email','INSERT INTO users VALUES (NULL, \'wuaraira@martin\', \'f4642f5d3ce1a103174f820ba6a52b61\', \'\', \'\', 1, 1, \'register:wuaraira@martin\', NULL)');
INSERT INTO `db_logs` VALUES (132,'2017-06-30 20:49:43','wuaraira@martin','INSERT INTO payments VALUES (NULL, \'2017-06-15\', \'Country_Park\', \'122\', \'2\', \'0023200\', 7, 3700, 0, \'\', NULL, \'239\')');
INSERT INTO `db_logs` VALUES (133,'2017-07-03 18:24:20','admin@caracol','INSERT INTO payments VALUES (NULL, \'2017-07-05\', \'A17\', \'2\', \'2\', \'110101\', 1, 0, 0, \'\', NULL, \'2\')');
INSERT INTO `db_logs` VALUES (134,'2017-07-08 21:57:35','admin@caracol','INSERT INTO payments VALUES (NULL, \'2017-06-29\', \'A17\', \'2\', \'2\', \'4343\', 8, 12232, 0, \'\', NULL, \'2\')');
INSERT INTO `db_logs` VALUES (135,'2017-07-10 14:59:39','register:$email','INSERT INTO users VALUES (NULL, \'junior@cordova.try\', \'96e79218965eb72c92a549dd5a330112\', \'\', \'\', 1, 1, \'register:junior@cordova.try\', NULL)');
INSERT INTO `db_logs` VALUES (136,'2017-07-13 22:30:56','admin@caracol','UPDATE payments SET pay_date = \'2017-07-05\', pay_type = 2, pay_op = \'110101\', pay_fk_bank = 2 , pay_amount = 200, pay_check = 0, pay_obs = \'Prueba otra vez 2\' WHERE pay_id = 16');
INSERT INTO `db_logs` VALUES (137,'2017-07-18 20:58:10','admin@caracol','INSERT INTO users VALUES (NULL, \'gil@lipollas\', \'1234\', \'\', \'\', 2, 1, \'admin@caracol\', NULL)');
INSERT INTO `db_logs` VALUES (138,'2017-07-18 21:01:28','admin@caracol','INSERT INTO users VALUES (NULL, \'segundo@tercero\', \'1234\', \'\', \'\', 2, 1, \'admin@caracol\', NULL)');
INSERT INTO `db_logs` VALUES (139,'2017-08-03 21:09:45','admin@caracol','INSERT INTO payments VALUES (NULL, \'2017-08-11\', \'A17\', \'2\', 2, \'223323\', 5, 2434.53, 0, \'\', NULL, \'2\')');
/*!40000 ALTER TABLE `db_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glo_cookies`
--

DROP TABLE IF EXISTS `glo_cookies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glo_cookies` (
  `coo_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `coo_key` varchar(20) NOT NULL,
  `coo_val` varchar(64) NOT NULL,
  `coo_info` varchar(500) NOT NULL DEFAULT '',
  `coo_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`coo_id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glo_cookies`
--

LOCK TABLES `glo_cookies` WRITE;
/*!40000 ALTER TABLE `glo_cookies` DISABLE KEYS */;
INSERT INTO `glo_cookies` VALUES (19,'remember','0b40ea42d5f3c29ae179818d7df9a713','{\"user_id\":\"2\",\"user\":\"admin@caracol\",\"status\":\"active\",\"name\":\"Stalin Rafael\",\"surname\":\"Rivas Perez\",\"val\":\"1\",\"number_id\":\"2\",\"apt\":\"1B\",\"bui\":\"A17\",\"type\":1}','2017-07-08 18:39:27');
INSERT INTO `glo_cookies` VALUES (20,'remember','2a6843c06c6fddd1ec996b0749634101','{\"user_id\":\"2\",\"user\":\"admin@caracol\",\"status\":\"active\",\"name\":\"Stalin Rafael\",\"surname\":\"Rivas Perez\",\"val\":\"1\",\"number_id\":\"2\",\"apt\":\"1B\",\"bui\":\"A17\",\"type\":1}','2017-07-31 15:50:11');
INSERT INTO `glo_cookies` VALUES (21,'remember','d029a9b09dbb48e54792593ed47214d5','{\"user_id\":\"2\",\"user\":\"admin@caracol\",\"status\":\"active\",\"name\":\"Stalin Rafael\",\"surname\":\"Rivas Perez\",\"val\":\"1\",\"number_id\":\"2\",\"apt\":\"1B\",\"bui\":\"A17\",\"type\":1}','2017-07-31 16:02:52');
INSERT INTO `glo_cookies` VALUES (24,'remember','7648fcdae899db1d22d1ddbe8f9f7781','{\"user_id\":\"2\",\"user\":\"admin@caracol\",\"status\":\"active\",\"name\":\"Stalin Rafael\",\"surname\":\"Rivas Perez\",\"val\":\"1\",\"number_id\":\"2\",\"apt\":\"1B\",\"bui\":\"A17\",\"type\":1}','2017-08-02 21:21:55');
INSERT INTO `glo_cookies` VALUES (26,'remember','41566c7709d3e58536708806ca5f4588','{\"user_id\":\"2\",\"user\":\"admin@caracol\",\"status\":\"active\",\"name\":\"Stalin Rafael\",\"surname\":\"Rivas Perez\",\"val\":\"1\",\"number_id\":\"2\",\"apt\":\"1B\",\"bui\":\"A17\",\"type\":1}','2017-08-15 18:53:17');
INSERT INTO `glo_cookies` VALUES (27,'remember','8ec2e97ee3560836ba185d1edd7c616c','{\"user_id\":\"2\",\"user\":\"admin@caracol\",\"status\":\"active\",\"name\":\"Stalin Rafael\",\"surname\":\"Rivas Perez\",\"val\":\"1\",\"number_id\":\"2\",\"apt\":\"1B\",\"bui\":\"A17\",\"type\":1}','2017-08-15 19:07:53');
/*!40000 ALTER TABLE `glo_cookies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glo_game`
--

DROP TABLE IF EXISTS `glo_game`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glo_game` (
  `gam_id` int(8) unsigned NOT NULL AUTO_INCREMENT,
  `gam_user` varchar(64) NOT NULL,
  `gam_ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `gam_exp` timestamp GENERATED ALWAYS AS ((`gam_ts` + interval 7 day)) VIRTUAL NOT NULL,
  `gam_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `gam_score` int(8) DEFAULT NULL,
  PRIMARY KEY (`gam_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glo_game`
--

LOCK TABLES `glo_game` WRITE;
/*!40000 ALTER TABLE `glo_game` DISABLE KEYS */;
/*!40000 ALTER TABLE `glo_game` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glo_lapses`
--

DROP TABLE IF EXISTS `glo_lapses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glo_lapses` (
  `lap_id` int(8) unsigned NOT NULL AUTO_INCREMENT,
  `lap_name` varchar(20) COLLATE utf8_spanish_ci NOT NULL,
  `lap_month` int(2) NOT NULL,
  `lap_year` int(4) NOT NULL,
  PRIMARY KEY (`lap_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glo_lapses`
--

LOCK TABLES `glo_lapses` WRITE;
/*!40000 ALTER TABLE `glo_lapses` DISABLE KEYS */;
/*!40000 ALTER TABLE `glo_lapses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `movements`
--

DROP TABLE IF EXISTS `movements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `movements` (
  `mov_id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `mov_date` date DEFAULT NULL,
  `mov_amount` decimal(10,2) unsigned NOT NULL,
  `mov_fk_origin` tinyint(3) unsigned NOT NULL,
  `mov_fk_receiver` tinyint(3) unsigned NOT NULL,
  `mov_method` varchar(30) COLLATE utf8_spanish_ci NOT NULL COMMENT 'Cheque, transferencia, deposito',
  `mov_user` varchar(30) CHARACTER SET utf8 NOT NULL DEFAULT 'N/D',
  `mov_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`mov_id`),
  KEY `mov_origin` (`mov_fk_origin`),
  KEY `mov_receiver` (`mov_fk_receiver`),
  CONSTRAINT `movements_ibfk_1` FOREIGN KEY (`mov_fk_origin`) REFERENCES `pri_accounts` (`acc_id`),
  CONSTRAINT `movements_ibfk_2` FOREIGN KEY (`mov_fk_receiver`) REFERENCES `pri_accounts` (`acc_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci COMMENT='Movimientos internos que no afectan el balance general';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `movements`
--

LOCK TABLES `movements` WRITE;
/*!40000 ALTER TABLE `movements` DISABLE KEYS */;
INSERT INTO `movements` VALUES (1,'2017-04-10',12000.00,1,2,'TRANSFERENCIA','N/D','2017-05-13 14:45:08');
/*!40000 ALTER TABLE `movements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pri_funds`
--

DROP TABLE IF EXISTS `pri_funds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pri_funds` (
  `fun_id` int(8) unsigned NOT NULL AUTO_INCREMENT,
  `fun_name` varchar(100) NOT NULL,
  `fun_balance` decimal(10,2) NOT NULL DEFAULT '0.00',
  `fun_default` varchar(20) NOT NULL DEFAULT '0' COMMENT 'Monto a cobrar mensualmente',
  `fun_type` int(1) NOT NULL DEFAULT '1' COMMENT 'Fondo de trabajo, cuota especial',
  `fun_bui` varchar(30) NOT NULL DEFAULT 'A17' COMMENT 'Edificio al que pertenece',
  `fun_creator` varchar(30) NOT NULL DEFAULT 'sysadmin',
  `fun_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`fun_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Fondos y Cuotas especiales';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pri_funds`
--

LOCK TABLES `pri_funds` WRITE;
/*!40000 ALTER TABLE `pri_funds` DISABLE KEYS */;
/*!40000 ALTER TABLE `pri_funds` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pri_userdata`
--

DROP TABLE IF EXISTS `pri_userdata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pri_userdata` (
  `udata_id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `udata_name` varchar(50) NOT NULL,
  `udata_surname` varchar(50) NOT NULL,
  `udata_ci` varchar(10) DEFAULT NULL COMMENT 'cedula o rif',
  `udata_cel` varchar(13) DEFAULT NULL,
  `udata_cond` int(1) NOT NULL DEFAULT '1',
  `udata_gender` varchar(1) NOT NULL DEFAULT 'M',
  `udata_number_fk` tinyint(3) unsigned NOT NULL COMMENT 'numero de apartamento',
  `udata_user_fk` smallint(5) unsigned NOT NULL,
  PRIMARY KEY (`udata_id`),
  KEY `fk_user` (`udata_user_fk`),
  KEY `udata_number_fk` (`udata_number_fk`),
  CONSTRAINT `link_users` FOREIGN KEY (`udata_user_fk`) REFERENCES `pri_users` (`user_id`),
  CONSTRAINT `pri_userdata_ibfk_2` FOREIGN KEY (`udata_number_fk`) REFERENCES `pri_buildings` (`bui_id`)
) ENGINE=InnoDB AUTO_INCREMENT=219 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pri_userdata`
--

LOCK TABLES `pri_userdata` WRITE;
/*!40000 ALTER TABLE `pri_userdata` DISABLE KEYS */;
INSERT INTO `pri_userdata` VALUES (1,'Gabriel','Batistuta','E80111234',NULL,1,'M',1,1);
INSERT INTO `pri_userdata` VALUES (2,'Stalin Rafael','Rivas Perez','V9456344','04164236576',2,'M',2,2);
INSERT INTO `pri_userdata` VALUES (3,'Oscar Ignacio','Cordova Patiño','','04266540012',1,'M',3,3);
INSERT INTO `pri_userdata` VALUES (4,'Faustino','Asprilla','E82009342',NULL,1,'M',4,4);
INSERT INTO `pri_userdata` VALUES (6,'Salomon','Rondon','V14000333',NULL,1,'M',5,6);
INSERT INTO `pri_userdata` VALUES (7,'Paolo','Maldini','E83000212',NULL,1,'M',5,7);
INSERT INTO `pri_userdata` VALUES (8,'Dennis Adolfo','Berkham','E80445765',NULL,1,'M',7,8);
INSERT INTO `pri_userdata` VALUES (12,'Diego Jose','Viniegra Villalobos','V14891345',NULL,1,'M',78,28);
INSERT INTO `pri_userdata` VALUES (13,'Meridian','Matova','E88282822',NULL,1,'M',78,29);
INSERT INTO `pri_userdata` VALUES (14,'Luz Marina','Villalobos Alvarez','E81447878',NULL,1,'M',78,30);
INSERT INTO `pri_userdata` VALUES (16,'Delcy','Bello','V6816747','',1,'F',1,32);
INSERT INTO `pri_userdata` VALUES (17,'Stalin Rafael','Rivas Perez','V9456344','04164236576',1,'M',2,33);
INSERT INTO `pri_userdata` VALUES (18,'Oscar Ignacio','Cordova Patiño','','04266540012',1,'M',3,34);
INSERT INTO `pri_userdata` VALUES (19,'Juan','Calderon','V937787','',1,'M',4,35);
INSERT INTO `pri_userdata` VALUES (20,'Bladimiro','Montilla','V9017289','0414-1406484',1,'M',5,36);
INSERT INTO `pri_userdata` VALUES (21,'Alejandro','Romero','V9941682','0414-1722014',1,'M',6,37);
INSERT INTO `pri_userdata` VALUES (22,'Oscar','Diaz','V9560116','0414-0110384',1,'M',7,38);
INSERT INTO `pri_userdata` VALUES (23,'Julian','Blanco','V6961144','0416-7141023',1,'M',8,39);
INSERT INTO `pri_userdata` VALUES (24,'Adon','Hernandez','V6975838','0416-3295092',1,'M',9,40);
INSERT INTO `pri_userdata` VALUES (25,'Rina','Vargas','V10629158','',1,'F',10,41);
INSERT INTO `pri_userdata` VALUES (26,'Sigris','Rivas','V10784373','0414-3349272',1,'F',11,42);
INSERT INTO `pri_userdata` VALUES (27,'Franklin','Gomez','V10065092','0416-7973715',1,'M',12,43);
INSERT INTO `pri_userdata` VALUES (28,'Edit','Nuñez','V10820207','',1,'F',13,44);
INSERT INTO `pri_userdata` VALUES (29,'Katiuska','Aguilar','V10822251','0416-7036249',1,'F',14,45);
INSERT INTO `pri_userdata` VALUES (30,'Eduardo','Guerra','V9958901','0214-2470405',1,'M',15,46);
INSERT INTO `pri_userdata` VALUES (31,'Aracelys','Diaz','V7474773','0416-7042602',1,'F',16,47);
INSERT INTO `pri_userdata` VALUES (32,'Maria','Abeijon','V942051','',1,'F',17,48);
INSERT INTO `pri_userdata` VALUES (33,'Leudys','Gonzalez','V10528201','0416-1726990',1,'F',18,49);
INSERT INTO `pri_userdata` VALUES (34,'Orlando','Graterol','V9961345','0414-2228407',1,'M',19,50);
INSERT INTO `pri_userdata` VALUES (35,'Marianella','Muñoz','V10788721','0416-2146611',1,'F',20,51);
INSERT INTO `pri_userdata` VALUES (36,'Octavio','Gutierrez','E8185146','',1,'M',21,52);
INSERT INTO `pri_userdata` VALUES (37,'Carlos','Aguilera','V9280761','0414-3363262',1,'M',22,53);
INSERT INTO `pri_userdata` VALUES (38,'Gustavo','Bermudez','V9099693','0414-3237117',1,'M',23,54);
INSERT INTO `pri_userdata` VALUES (39,'Irina','Passo','E84341298','',1,'F',24,55);
INSERT INTO `pri_userdata` VALUES (40,'Sonia','Perez','V9120751','',1,'F',25,56);
INSERT INTO `pri_userdata` VALUES (41,'Armando','Salazar','E8224868','',1,'M',26,57);
INSERT INTO `pri_userdata` VALUES (42,'Juan','Angulo','V8674922','0416-9367854',1,'M',27,58);
INSERT INTO `pri_userdata` VALUES (43,'Carol','Bermudez','V10484289','',1,'F',28,59);
INSERT INTO `pri_userdata` VALUES (44,'Atilana','Cocho','V10544035','0412-5574926',1,'F',29,60);
INSERT INTO `pri_userdata` VALUES (45,'William','Sanchez','E82296106','',1,'M',30,61);
INSERT INTO `pri_userdata` VALUES (46,'Deyanira','Perez','E82361170','',1,'F',31,62);
INSERT INTO `pri_userdata` VALUES (47,'Yatsen','Torres','V10486850','0414-0110168',1,'M',32,63);
INSERT INTO `pri_userdata` VALUES (48,'Plutarco','Guerrero','V10201557','0416-8304160',1,'M',33,64);
INSERT INTO `pri_userdata` VALUES (49,'Yorman','Rodriguez','V10489903','',1,'M',34,65);
INSERT INTO `pri_userdata` VALUES (50,'Alexis','Indriago','V10114529','0412-6932460',1,'M',35,66);
INSERT INTO `pri_userdata` VALUES (51,'Raquel','Ortiz','V9149630','0414-1806052',1,'F',36,67);
INSERT INTO `pri_userdata` VALUES (52,'Coromoto','Gil','V7983315','0416-4235945',1,'F',37,68);
INSERT INTO `pri_userdata` VALUES (53,'Jose','Barrientos','V7235353','0414-4597545',1,'M',38,69);
INSERT INTO `pri_userdata` VALUES (54,'Ernesto','Vivas','V8707516','0414-3078846',1,'M',39,70);
INSERT INTO `pri_userdata` VALUES (55,'Nelly','Silva','V10429175','0414-0669951',1,'F',40,71);
INSERT INTO `pri_userdata` VALUES (56,'Hector','Briceño','V11044404','0416-4210775',1,'M',41,72);
INSERT INTO `pri_userdata` VALUES (57,'Miryan','Zabala','V7661297','0412-9248887',1,'F',42,73);
INSERT INTO `pri_userdata` VALUES (58,'Oscar','Granados','V7681942','',1,'M',43,74);
INSERT INTO `pri_userdata` VALUES (59,'Carlos','Rey','V7681951','0416-8109192',1,'M',44,75);
INSERT INTO `pri_userdata` VALUES (60,'Luz','Duarte','V9187628','',1,'F',45,76);
INSERT INTO `pri_userdata` VALUES (61,'Alirio','Rojas','V9190151','0414-9276280',1,'M',46,77);
INSERT INTO `pri_userdata` VALUES (62,'Edinson','Bello','E83076512','',1,'M',47,78);
INSERT INTO `pri_userdata` VALUES (63,'Jose','Marcano','V8762580','0416-2147249',1,'M',48,79);
INSERT INTO `pri_userdata` VALUES (64,'Jose','Silva','V10505214','0416-4185649',1,'M',49,80);
INSERT INTO `pri_userdata` VALUES (65,'Isney','Marchan','V8773933','0412-6000669',1,'F',50,81);
INSERT INTO `pri_userdata` VALUES (66,'Maria','Rojas','V9374164','0412-9502475',1,'F',51,82);
INSERT INTO `pri_userdata` VALUES (67,'Gianny','Gerardo','V11156265','0416-6204150',1,'F',52,83);
INSERT INTO `pri_userdata` VALUES (68,'Richard','Garcia','V11158991','',1,'M',53,84);
INSERT INTO `pri_userdata` VALUES (69,'Marlon','Felibert','V11180007','0412-5591822',1,'M',54,85);
INSERT INTO `pri_userdata` VALUES (70,'Jaime','Sintjago','V11228710','0412-2971355',1,'M',55,86);
INSERT INTO `pri_userdata` VALUES (71,'Nury','Hoyos','V11300972','0416-8213172',1,'F',56,87);
INSERT INTO `pri_userdata` VALUES (72,'Gloria','Gonzalez','V11287089','0414-2224742',1,'F',57,88);
INSERT INTO `pri_userdata` VALUES (73,'Jose','Briceño','V11405147','0414-2654575',1,'M',58,89);
INSERT INTO `pri_userdata` VALUES (74,'Lino','Parra','V11412926','',1,'M',59,90);
INSERT INTO `pri_userdata` VALUES (75,'Gilmy','Aguilar','V11482881','0414-1180388',1,'F',60,91);
INSERT INTO `pri_userdata` VALUES (76,'Jairo','Barros','V11663179','',1,'M',61,92);
INSERT INTO `pri_userdata` VALUES (77,'Yamileth','Urbina','V11666136','',1,'F',62,93);
INSERT INTO `pri_userdata` VALUES (78,'Victor','Mecia','V11690787','0416-8042528',1,'M',63,94);
INSERT INTO `pri_userdata` VALUES (79,'Jose','Camacho','V11801399','',1,'M',64,95);
INSERT INTO `pri_userdata` VALUES (80,'Any','Villarroel','V11829863','',1,'F',65,96);
INSERT INTO `pri_userdata` VALUES (81,'Edgardo','Coraspe','V11826588','0412-9377144',1,'M',66,97);
INSERT INTO `pri_userdata` VALUES (82,'Alejandro','Gonzalez','V11865447','0416-2638477',1,'M',67,98);
INSERT INTO `pri_userdata` VALUES (83,'Pedro','Jimenez','V12059338','0412-9521288',1,'M',68,99);
INSERT INTO `pri_userdata` VALUES (84,'Osvaldo','Hernandez','V12063483','',1,'M',69,100);
INSERT INTO `pri_userdata` VALUES (85,'Joher','Montilla','V12161817','0416-6118458',1,'M',70,101);
INSERT INTO `pri_userdata` VALUES (86,'Francia','Salazar','V12293572','',1,'F',71,102);
INSERT INTO `pri_userdata` VALUES (87,'Jeckson','Blanco','V12339520','0412-4356736',1,'M',72,103);
INSERT INTO `pri_userdata` VALUES (88,'Jose','Materano','V12299386','0414-1122527',1,'M',73,104);
INSERT INTO `pri_userdata` VALUES (89,'Henrry','Lares','V12411338','',1,'M',74,105);
INSERT INTO `pri_userdata` VALUES (90,'Beatriz','Jimenez','V12484299','0412-5950387',1,'F',75,106);
INSERT INTO `pri_userdata` VALUES (91,'Nairobi','Burgos','V12626931','0416-7259847',1,'F',76,107);
INSERT INTO `pri_userdata` VALUES (92,'Andres','Parra','V12627651','',1,'M',77,108);
INSERT INTO `pri_userdata` VALUES (93,'Katiuska','Osorio','V12666161','0412-5425564',1,'F',78,109);
INSERT INTO `pri_userdata` VALUES (94,'Jimmy','Benitez','V12973783','0414-2449257',1,'M',10,110);
INSERT INTO `pri_userdata` VALUES (95,'Leonardo','Velez','V12960326','',1,'M',80,111);
INSERT INTO `pri_userdata` VALUES (96,'Yony','Calderon','V13021647','',1,'M',81,112);
INSERT INTO `pri_userdata` VALUES (97,'Fabian','Ricardo','V13109019','',1,'M',82,113);
INSERT INTO `pri_userdata` VALUES (98,'Luis','Cornieles','V13144227','0414-1569728',1,'M',83,114);
INSERT INTO `pri_userdata` VALUES (99,'Luisa','Vergara','V13139649','0424-1214162',1,'F',84,115);
INSERT INTO `pri_userdata` VALUES (100,'Richar','Arellano','V13141656','0416-6106396',1,'M',85,116);
INSERT INTO `pri_userdata` VALUES (101,'Alexander','Amundaray','V13250270','',1,'M',86,117);
INSERT INTO `pri_userdata` VALUES (102,'Efrain','Duque','V13311205','0416-8075052',1,'M',87,118);
INSERT INTO `pri_userdata` VALUES (103,'Juan','Rodriguez','V13284794','0412-5887016',1,'M',88,119);
INSERT INTO `pri_userdata` VALUES (104,'Yesenia','Zambrano','V13581493','0412-9638301',1,'F',89,120);
INSERT INTO `pri_userdata` VALUES (105,'Michael','Cubano','V13614731','',1,'M',90,121);
INSERT INTO `pri_userdata` VALUES (106,'Jose','Ortega','V13658570','0414-3165974',1,'M',91,122);
INSERT INTO `pri_userdata` VALUES (107,'Maribel','Melendez','V13846650','',1,'F',92,123);
INSERT INTO `pri_userdata` VALUES (108,'Eglis','Izquierdo','V14153281','',1,'F',93,124);
INSERT INTO `pri_userdata` VALUES (110,'Douglas','Montilla','V14201272','0414-9108865',1,'M',95,126);
INSERT INTO `pri_userdata` VALUES (111,'Xiomara','Lopez','V14201800','0416-2187889',1,'F',96,127);
INSERT INTO `pri_userdata` VALUES (112,'Marlyn','Guerra','V14420591','',1,'F',97,128);
INSERT INTO `pri_userdata` VALUES (113,'Yanibel','De Jesus','V14400968','0414-0107788',1,'F',98,129);
INSERT INTO `pri_userdata` VALUES (114,'Brenda','Ledeica','V14484000','0414-9393740',1,'F',99,130);
INSERT INTO `pri_userdata` VALUES (115,'Loni','Atencio','V14963827','0416-3062889',1,'M',100,131);
INSERT INTO `pri_userdata` VALUES (116,'Josefina','Alvarez','V14965758','0416-7083571',1,'F',101,132);
INSERT INTO `pri_userdata` VALUES (117,'Yosmar','Marchan','V14992500','0412-9803176',1,'M',102,133);
INSERT INTO `pri_userdata` VALUES (118,'Carlos','Teran','V15040564','',1,'M',103,134);
INSERT INTO `pri_userdata` VALUES (119,'Andres','Colsini','V15040851','',1,'M',104,135);
INSERT INTO `pri_userdata` VALUES (120,'Jairo','Mora','V15143099','0414-2561843',1,'M',105,136);
INSERT INTO `pri_userdata` VALUES (121,'Cleotilde','Hernandez','V15342914','0414-2864843',1,'F',106,137);
INSERT INTO `pri_userdata` VALUES (122,'Arturo','Olmos','V15366357','',1,'M',107,138);
INSERT INTO `pri_userdata` VALUES (123,'Beisy','Leal','V15395907','',1,'F',108,139);
INSERT INTO `pri_userdata` VALUES (124,'Luis','Chacon','V15503728','',1,'M',109,140);
INSERT INTO `pri_userdata` VALUES (125,'Oswaldo','Nuñez','V15613946','0412-6138932',1,'M',110,141);
INSERT INTO `pri_userdata` VALUES (126,'Antonio','Perez','V15582734','',1,'M',111,142);
INSERT INTO `pri_userdata` VALUES (127,'Jhonny','Lerma','V15665528','',1,'M',112,143);
INSERT INTO `pri_userdata` VALUES (128,'Yovany','Rincon','V15669530','',1,'M',113,144);
INSERT INTO `pri_userdata` VALUES (129,'Arianne','Cabaniel','V15605286','0416-4002256',1,'F',114,145);
INSERT INTO `pri_userdata` VALUES (130,'Arelis','Herrera','V15677817','0414-4684738',1,'F',115,146);
INSERT INTO `pri_userdata` VALUES (131,'Luis','Sifontes','V15797338','',1,'M',116,147);
INSERT INTO `pri_userdata` VALUES (132,'Yosneidy','Bandres','V15797490','0414-2145951',1,'M',117,148);
INSERT INTO `pri_userdata` VALUES (133,'Del Valle','Moreno','V15793427','0412-6165791',1,'F',118,149);
INSERT INTO `pri_userdata` VALUES (134,'Claudio','Letelier','V16032859','0414-2930477',1,'M',119,150);
INSERT INTO `pri_userdata` VALUES (135,'Mariela','Longa','V16032866','0412-9271923',1,'F',120,151);
INSERT INTO `pri_userdata` VALUES (136,'Johanna','Rivas','V16300288','',1,'F',65,152);
INSERT INTO `pri_userdata` VALUES (137,'Eduardo','Velasquez','V16486479','',1,'M',66,153);
INSERT INTO `pri_userdata` VALUES (138,'Norelys','Marquez','V16557182','0414-7372185',1,'F',67,154);
INSERT INTO `pri_userdata` VALUES (139,'Richard','Cocho','V16563834','0412-3991290',1,'M',68,155);
INSERT INTO `pri_userdata` VALUES (140,'Johana','Herra','V16525390','0414-3322147',1,'F',69,156);
INSERT INTO `pri_userdata` VALUES (141,'Neydimar','Diaz','V16475266','0414-9171684',1,'F',70,157);
INSERT INTO `pri_userdata` VALUES (142,'Osvaldo','Piña','V16673797','',1,'M',71,158);
INSERT INTO `pri_userdata` VALUES (143,'Orion','Hernandez','V16674881','',1,'M',72,159);
INSERT INTO `pri_userdata` VALUES (144,'Joan','Ferrer','V16727054','0416-2621219',1,'M',73,160);
INSERT INTO `pri_userdata` VALUES (145,'Yeghlin','Larez','V16893852','0414-0130566',1,'F',74,161);
INSERT INTO `pri_userdata` VALUES (146,'Maria','Diazx','V16971992','0416-4199622',1,'F',75,162);
INSERT INTO `pri_userdata` VALUES (147,'Lorena','Santana','V17075855','',1,'M',76,163);
INSERT INTO `pri_userdata` VALUES (148,'Maria','Trompetera','V17036100','',1,'M',77,164);
INSERT INTO `pri_userdata` VALUES (149,'Raiza','Vargas','V17285384','0416-8993204',1,'M',119,165);
INSERT INTO `pri_userdata` VALUES (150,'Yoxoely','Molina','V17294504','0224-6068036',1,'F',120,166);
INSERT INTO `pri_userdata` VALUES (151,'Rosa','Mora','V17358844','0416-1708987',1,'F',65,167);
INSERT INTO `pri_userdata` VALUES (152,'Maximo','Arias','V17588315','0412-9584686',1,'M',66,168);
INSERT INTO `pri_userdata` VALUES (153,'Flor','La Rosa','V17757424','',1,'F',67,169);
INSERT INTO `pri_userdata` VALUES (154,'Maria','Mora','V17895858','0416-5265870',1,'F',68,170);
INSERT INTO `pri_userdata` VALUES (155,'Fanny','Mendoza','V17886717','',1,'F',6,171);
INSERT INTO `pri_userdata` VALUES (156,'Jacssely','Montilla','V18026651','0414-2460120',1,'F',7,172);
INSERT INTO `pri_userdata` VALUES (157,'Elizabeth','Barrios','V18024708','0412-5722291',1,'F',8,173);
INSERT INTO `pri_userdata` VALUES (158,'Helleybert','Chitty','V17926479','',1,'M',9,174);
INSERT INTO `pri_userdata` VALUES (159,'Ysneda','Diaz','V18045347','0416-2399403',1,'F',10,175);
INSERT INTO `pri_userdata` VALUES (160,'Edixon','Romero','V18217218','0412-5987169',1,'M',11,176);
INSERT INTO `pri_userdata` VALUES (161,'Angela','Lirio','V18367900','',1,'F',6,177);
INSERT INTO `pri_userdata` VALUES (162,'Crizaida','Ramirez','V18584714','0416-9109792',1,'F',7,178);
INSERT INTO `pri_userdata` VALUES (163,'Jose','Pariata','V18756011','0412-9020830',1,'M',8,179);
INSERT INTO `pri_userdata` VALUES (164,'Maria','Lazo','V18713585','0416-8012250',1,'F',9,180);
INSERT INTO `pri_userdata` VALUES (165,'Ernesto','Mata','V19370411','',1,'M',10,181);
INSERT INTO `pri_userdata` VALUES (166,'Rafael','Rodriguez','V19499094','',1,'M',11,182);
INSERT INTO `pri_userdata` VALUES (167,'Andres','Gonzalez','V19500188','',1,'M',12,183);
INSERT INTO `pri_userdata` VALUES (168,'Luis','Mendivil','V20320408','',1,'M',13,184);
INSERT INTO `pri_userdata` VALUES (169,'Dariana','Cedeño','V20677373','',1,'F',6,185);
INSERT INTO `pri_userdata` VALUES (170,'Luis','Diaz','V2061188','',1,'M',7,186);
INSERT INTO `pri_userdata` VALUES (171,'Benjamin','Hernandez','V20678561','',1,'M',8,187);
INSERT INTO `pri_userdata` VALUES (172,'Elmira','Casique','V2071765','0414-9946558',1,'F',9,188);
INSERT INTO `pri_userdata` VALUES (173,'Carlos','Ortiz','V2074008','0416-8133299',1,'M',10,189);
INSERT INTO `pri_userdata` VALUES (174,'Jhonald','Caballero','V20910508','',1,'M',11,190);
INSERT INTO `pri_userdata` VALUES (175,'Hermes','Gutierrez','V2109247','',1,'M',12,191);
INSERT INTO `pri_userdata` VALUES (176,'Jose','Yepez','V21055104','',1,'M',13,192);
INSERT INTO `pri_userdata` VALUES (177,'Delvis','Cabrita','V21063246','',1,'M',14,193);
INSERT INTO `pri_userdata` VALUES (178,'Ender','Perez','V21418516','',1,'M',6,194);
INSERT INTO `pri_userdata` VALUES (179,'Elias','Ledeica','V2139011','',1,'M',7,195);
INSERT INTO `pri_userdata` VALUES (180,'Paula','Monasterio','V2154464','0414-9016373',1,'F',8,196);
INSERT INTO `pri_userdata` VALUES (181,'Cesar','Moreno','V2148924','0416-4702003',1,'M',9,197);
INSERT INTO `pri_userdata` VALUES (182,'Freddy','Velasco','V2149428','',1,'M',10,198);
INSERT INTO `pri_userdata` VALUES (183,'Jose','Guerra','V2151586','',1,'M',11,199);
INSERT INTO `pri_userdata` VALUES (184,'Mercedes','Marquez','V2158522','',1,'F',28,200);
INSERT INTO `pri_userdata` VALUES (185,'Jose','Arias','V22014703','0416-8160289',1,'M',29,201);
INSERT INTO `pri_userdata` VALUES (186,'Bernarda','De La Hoz','V22017201','',1,'F',30,202);
INSERT INTO `pri_userdata` VALUES (187,'Rafael','Manuitt','V2213427','0416-7155954',1,'M',31,203);
INSERT INTO `pri_userdata` VALUES (188,'Edward','Rios','V22759049','',1,'M',32,204);
INSERT INTO `pri_userdata` VALUES (189,'Manuel','Aguirre','V22762236','0412-9247063',1,'M',33,205);
INSERT INTO `pri_userdata` VALUES (190,'Pablo','Bermejo','V22762326','0412-7251509',1,'M',34,206);
INSERT INTO `pri_userdata` VALUES (191,'Aurora','Pereira','V22902137','',1,'F',35,207);
INSERT INTO `pri_userdata` VALUES (192,'Victor','Torres','V23148664','0416-2058817',1,'M',36,208);
INSERT INTO `pri_userdata` VALUES (193,'Omar','Gomez','V23446526','',1,'M',37,209);
INSERT INTO `pri_userdata` VALUES (194,'Ana','Alcantara','V23641888','',1,'F',38,210);
INSERT INTO `pri_userdata` VALUES (196,'David Ernesto','Villa Paris','V12324323',NULL,1,'M',48,220);
INSERT INTO `pri_userdata` VALUES (202,'Ana','Kurnikova','',NULL,2,'M',5,229);
INSERT INTO `pri_userdata` VALUES (209,'Oscar Ignacio','Cordova Patiño','V13000123','04266540012',1,'M',125,236);
INSERT INTO `pri_userdata` VALUES (210,'Carlos Felipe','Valderrama Orta',NULL,NULL,1,'M',135,237);
INSERT INTO `pri_userdata` VALUES (211,'Susi','La Callada','V10234567',NULL,2,'M',121,238);
INSERT INTO `pri_userdata` VALUES (212,'Waraira','Martín Sánchez',NULL,NULL,1,'M',122,239);
INSERT INTO `pri_userdata` VALUES (213,'Junior Jose','Cordova',NULL,NULL,2,'M',125,240);
INSERT INTO `pri_userdata` VALUES (214,'Gil','Lipollas','',NULL,2,'M',22,241);
INSERT INTO `pri_userdata` VALUES (215,'Segundo','Tercero','',NULL,2,'M',28,242);
INSERT INTO `pri_userdata` VALUES (218,'Karina','La Meltroso','',NULL,1,'M',122,248);
/*!40000 ALTER TABLE `pri_userdata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `spendings_types`
--

DROP TABLE IF EXISTS `spendings_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `spendings_types` (
  `spe_id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `spe_name` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `spe_op` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`spe_id`),
  KEY `spe_name` (`spe_name`),
  KEY `spe_name_2` (`spe_name`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `spendings_types`
--

LOCK TABLES `spendings_types` WRITE;
/*!40000 ALTER TABLE `spendings_types` DISABLE KEYS */;
INSERT INTO `spendings_types` VALUES (1,'PERSONAL',0);
INSERT INTO `spendings_types` VALUES (2,'MATERIALES',0);
INSERT INTO `spendings_types` VALUES (3,'SERVICIOS',0);
INSERT INTO `spendings_types` VALUES (4,'BIENES',0);
INSERT INTO `spendings_types` VALUES (5,'LEGAL',0);
/*!40000 ALTER TABLE `spendings_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `u4_buildings`
--

DROP TABLE IF EXISTS `u4_buildings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `u4_buildings` (
  `bui_id` int(8) unsigned NOT NULL AUTO_INCREMENT,
  `bui_name` varchar(30) NOT NULL DEFAULT 'A17',
  `bui_apt` varchar(3) NOT NULL,
  `bui_balance` decimal(10,2) NOT NULL DEFAULT '0.00',
  `bui_weight` varchar(10) NOT NULL DEFAULT '0.00' COMMENT 'Porcentaje ponderado',
  `bui_assigned` tinyint(1) NOT NULL DEFAULT '1',
  `bui_occupied` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'Si esta habitado',
  `bui_notes` varchar(1000) DEFAULT NULL,
  PRIMARY KEY (`bui_id`),
  UNIQUE KEY `bui_number_2` (`bui_apt`),
  KEY `bui_number` (`bui_apt`)
) ENGINE=InnoDB AUTO_INCREMENT=151 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `u4_buildings`
--

LOCK TABLES `u4_buildings` WRITE;
/*!40000 ALTER TABLE `u4_buildings` DISABLE KEYS */;
INSERT INTO `u4_buildings` VALUES (136,'Country_Park','M1',0.00,'6.409828',1,1,'{\"todo\": true}');
INSERT INTO `u4_buildings` VALUES (137,'Country_Park','M2',0.00,'6.603667',1,1,'{\"todo\": true}');
INSERT INTO `u4_buildings` VALUES (138,'Country_Park','1',0.00,'6.568069',1,1,'{\"todo\": true}');
INSERT INTO `u4_buildings` VALUES (139,'Country_Park','2',0.00,'6.64427',1,1,'{\"todo\": true}');
INSERT INTO `u4_buildings` VALUES (140,'Country_Park','3',0.00,'6.425328',1,1,'{\"todo\": true}');
INSERT INTO `u4_buildings` VALUES (141,'Country_Park','4',0.00,'6.641821',1,0,'');
INSERT INTO `u4_buildings` VALUES (142,'Country_Park','5',0.00,'6.319065',1,1,'{\"todo\": true}');
INSERT INTO `u4_buildings` VALUES (143,'Country_Park','6',0.00,'6.480478',1,1,'{\"todo\": true}');
INSERT INTO `u4_buildings` VALUES (144,'Country_Park','7',0.00,'6.644581',1,1,'{\"todo\": true}');
INSERT INTO `u4_buildings` VALUES (145,'Country_Park','8',0.00,'6.492283',1,1,'{\"todo\": true}');
INSERT INTO `u4_buildings` VALUES (146,'Country_Park','9',0.00,'6.485532',1,1,'{\"todo\": true}');
INSERT INTO `u4_buildings` VALUES (147,'Country_Park','10',0.00,'6.497734',1,1,'{\"todo\": true}');
INSERT INTO `u4_buildings` VALUES (148,'Country_Park','11',0.00,'6.673306',1,1,'{\"todo\": true}');
INSERT INTO `u4_buildings` VALUES (149,'Country_Park','12',0.00,'6.562629',1,1,'{\"todo\": true}');
INSERT INTO `u4_buildings` VALUES (150,'Country_Park','PH',0.00,'8.551409',1,1,'{\"todo\": true}');
/*!40000 ALTER TABLE `u4_buildings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `u4_userdata`
--

DROP TABLE IF EXISTS `u4_userdata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `u4_userdata` (
  `udata_id` int(8) unsigned NOT NULL AUTO_INCREMENT,
  `udata_name` varchar(50) NOT NULL,
  `udata_surname` varchar(50) NOT NULL,
  `udata_ci` varchar(10) DEFAULT NULL COMMENT 'cedula o rif',
  `udata_cel` varchar(13) DEFAULT NULL,
  `udata_cond` int(1) NOT NULL DEFAULT '1',
  `udata_gender` varchar(1) DEFAULT NULL COMMENT 'M o F',
  `udata_number_fk` int(8) unsigned NOT NULL COMMENT 'numero de apartamento',
  `udata_user_fk` int(8) unsigned NOT NULL,
  PRIMARY KEY (`udata_id`),
  KEY `u4_udata_user` (`udata_user_fk`),
  KEY `u4_udata_bui` (`udata_number_fk`),
  CONSTRAINT `u4_link_buildings` FOREIGN KEY (`udata_number_fk`) REFERENCES `u4_buildings` (`bui_id`),
  CONSTRAINT `u4_link_users` FOREIGN KEY (`udata_user_fk`) REFERENCES `u4_users` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=239 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `u4_userdata`
--

LOCK TABLES `u4_userdata` WRITE;
/*!40000 ALTER TABLE `u4_userdata` DISABLE KEYS */;
INSERT INTO `u4_userdata` VALUES (219,'Francisca','Querales','V13528627','0416-1792560',1,'F',136,249);
INSERT INTO `u4_userdata` VALUES (220,'MarÃ­a Pilar','Ãlvarez Castro','V15238080',NULL,1,'F',137,250);
INSERT INTO `u4_userdata` VALUES (221,'Carmen','Garrido Molina','V15990579',NULL,1,'F',138,251);
INSERT INTO `u4_userdata` VALUES (222,'Francisco Javier','Rubio','V14275575',NULL,0,'M',139,252);
INSERT INTO `u4_userdata` VALUES (223,'Elena','Morales MartÃ­n','V8871943','0412-5152152',1,'F',139,253);
INSERT INTO `u4_userdata` VALUES (224,'Francisco Javier','CÃ³rdova Iglesias','V16225722',NULL,1,'M',140,254);
INSERT INTO `u4_userdata` VALUES (225,'Gabriel','MartÃ­n','V12264079',NULL,1,'M',142,255);
INSERT INTO `u4_userdata` VALUES (226,'JosÃ© Manuel','MartÃ­n BerroterÃ¡n','V18410464','0414-3730584',1,'M',143,256);
INSERT INTO `u4_userdata` VALUES (227,'JosÃ© Manuel','Mathaus NuÃ±ez',NULL,'0416-6977230',1,'M',144,257);
INSERT INTO `u4_userdata` VALUES (229,'Arturo','RamÃ­rez MarÃ­n',NULL,'0416-4627149',1,'M',145,259);
INSERT INTO `u4_userdata` VALUES (230,'Manuel','Ochoa',NULL,'0416-1140473',1,'M',146,260);
INSERT INTO `u4_userdata` VALUES (231,'Sergio','Morales HernÃ¡ndez','E82647685',NULL,0,'M',147,261);
INSERT INTO `u4_userdata` VALUES (232,'Rafael','DÃ­az Ortega',NULL,NULL,0,'M',147,262);
INSERT INTO `u4_userdata` VALUES (233,'Rosa MarÃ­a','Mathaus Vivas','V17198381','0412-5997332',1,'F',147,263);
INSERT INTO `u4_userdata` VALUES (234,'Juan','Delgado Ruiz','V17356573','0424-3567484',1,'M',148,264);
INSERT INTO `u4_userdata` VALUES (235,'David','Morales','V12589752','0426-4555047',0,'M',149,265);
INSERT INTO `u4_userdata` VALUES (236,'MarÃ­a Antonieta','Sanz Iglesias','V18895570','0424-8461446',1,'F',149,266);
INSERT INTO `u4_userdata` VALUES (237,'Pablo','Iglesias GÃ³mez','V18408976',NULL,1,'M',150,267);
INSERT INTO `u4_userdata` VALUES (238,'Diego Jose','Viniegra Villalobos',NULL,NULL,1,NULL,141,268);
/*!40000 ALTER TABLE `u4_userdata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `u4_users`
--

DROP TABLE IF EXISTS `u4_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `u4_users` (
  `user_id` int(8) unsigned NOT NULL AUTO_INCREMENT,
  `user_user` varchar(64) NOT NULL COMMENT 'e-mail como usuario',
  `user_pwd` varchar(64) NOT NULL,
  `user_question` varchar(64) DEFAULT NULL,
  `user_response` varchar(64) DEFAULT NULL,
  `user_type` int(1) NOT NULL COMMENT 'tipo de usuario',
  `user_active` int(1) DEFAULT NULL,
  `user_creator` varchar(64) DEFAULT NULL,
  `user_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_id`),
  KEY `user_user` (`user_user`),
  KEY `user_type` (`user_type`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=269 DEFAULT CHARSET=utf8 COMMENT='Tabla de usuarios para el acceso';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `u4_users`
--

LOCK TABLES `u4_users` WRITE;
/*!40000 ALTER TABLE `u4_users` DISABLE KEYS */;
INSERT INTO `u4_users` VALUES (249,'francisca1@cntv.gob.ve','1234','','d41d8cd98f00b204e9800998ecf8427e',1,1,'demo','2017-08-26 22:27:59');
INSERT INTO `u4_users` VALUES (250,'marÃ­a2@mns.edu.mx','1234','','d41d8cd98f00b204e9800998ecf8427e',1,1,'demo','2017-08-26 22:27:59');
INSERT INTO `u4_users` VALUES (251,'carmen3@yahou.es','1234','','d41d8cd98f00b204e9800998ecf8427e',1,1,'demo','2017-08-26 22:27:59');
INSERT INTO `u4_users` VALUES (252,'francisco4@mns.edu.mx','1234','','d41d8cd98f00b204e9800998ecf8427e',2,1,'demo','2017-08-26 22:27:59');
INSERT INTO `u4_users` VALUES (253,'elena5@yahou.es','1234','','d41d8cd98f00b204e9800998ecf8427e',1,1,'demo','2017-08-26 22:27:59');
INSERT INTO `u4_users` VALUES (254,'francisco6@cntv.gob.ve','1234','','d41d8cd98f00b204e9800998ecf8427e',1,1,'demo','2017-08-26 22:27:59');
INSERT INTO `u4_users` VALUES (255,'gabriel7@identi.ca','1234','El Capital','6b950af3d84109cb52c1186a2ffbef9a',1,1,'demo','2017-08-26 22:27:59');
INSERT INTO `u4_users` VALUES (256,'josÃ©8@fmail.com','1234','','d41d8cd98f00b204e9800998ecf8427e',1,1,'demo','2017-08-26 22:27:59');
INSERT INTO `u4_users` VALUES (257,'josÃ©9@mns.edu.mx','1234','Cien aÃ±os de Soledad','0b4a5593a5bbe5fa7cc78f3585c8e303',1,1,'demo','2017-08-26 22:27:59');
INSERT INTO `u4_users` VALUES (259,'arturo11@cntv.gob.ve','1234','','d41d8cd98f00b204e9800998ecf8427e',1,1,'demo','2017-08-26 22:27:59');
INSERT INTO `u4_users` VALUES (260,'manuel12@fmail.com','1234','','d41d8cd98f00b204e9800998ecf8427e',1,1,'demo','2017-08-26 22:27:59');
INSERT INTO `u4_users` VALUES (261,'sergio13@yahou.es','1234','','d41d8cd98f00b204e9800998ecf8427e',2,0,'demo','2017-08-26 22:27:59');
INSERT INTO `u4_users` VALUES (262,'rafael14@fmail.com','1234','','d41d8cd98f00b204e9800998ecf8427e',2,1,'demo','2017-08-26 22:27:59');
INSERT INTO `u4_users` VALUES (263,'rosa15@fmail.com','1234','El Estado y la RevoluciÃ³n','2b2c3930af637973eb5c37ec5541d2eb',1,1,'demo','2017-08-26 22:28:00');
INSERT INTO `u4_users` VALUES (264,'juan16@hogmail.com','1234','','d41d8cd98f00b204e9800998ecf8427e',1,1,'demo','2017-08-26 22:28:00');
INSERT INTO `u4_users` VALUES (265,'david17@mns.edu.mx','1234','','d41d8cd98f00b204e9800998ecf8427e',2,0,'demo','2017-08-26 22:28:00');
INSERT INTO `u4_users` VALUES (266,'marÃ­a18@fmail.com','1234','','d41d8cd98f00b204e9800998ecf8427e',1,1,'demo','2017-08-26 22:28:00');
INSERT INTO `u4_users` VALUES (267,'pablo19@mns.edu.mx','1234','','d41d8cd98f00b204e9800998ecf8427e',1,1,'demo','2017-08-26 22:28:00');
INSERT INTO `u4_users` VALUES (268,'diego.viniegra@gmail.com','96e79218965eb72c92a549dd5a330112',NULL,NULL,0,1,NULL,'2017-08-26 22:28:00');
/*!40000 ALTER TABLE `u4_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usual_providers`
--

DROP TABLE IF EXISTS `usual_providers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usual_providers` (
  `up_id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `up_name` varchar(100) COLLATE utf8_spanish_ci NOT NULL COMMENT 'Nombre o Razon Social',
  `up_rif` varchar(10) COLLATE utf8_spanish_ci NOT NULL COMMENT 'Rif o CI',
  `up_alias` varchar(20) COLLATE utf8_spanish_ci NOT NULL,
  `up_desc` varchar(40) CHARACTER SET utf8 NOT NULL DEFAULT 'definir',
  `up_fk_type` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT 'Tipo de gasto',
  `up_op` int(1) unsigned NOT NULL DEFAULT '0' COMMENT 'Caracteristicas especiales de cobro',
  `up_bui` varchar(30) CHARACTER SET utf8 NOT NULL DEFAULT 'A17' COMMENT 'El edificio',
  `up_notes` varchar(1000) COLLATE utf8_spanish_ci DEFAULT '' COMMENT 'Documentacion relacionada',
  PRIMARY KEY (`up_id`),
  KEY `up_group_fk` (`up_fk_type`),
  KEY `up_name` (`up_name`),
  KEY `up_rif` (`up_rif`),
  KEY `up_alias` (`up_alias`),
  CONSTRAINT `usual_providers_ibfk_1` FOREIGN KEY (`up_fk_type`) REFERENCES `spendings_types` (`spe_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci COMMENT='Proveedores Frecuentes';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usual_providers`
--

LOCK TABLES `usual_providers` WRITE;
/*!40000 ALTER TABLE `usual_providers` DISABLE KEYS */;
INSERT INTO `usual_providers` VALUES (2,'Corporacición Eléctrica Nacional, S.A. (CORPOELEC)','G200100141','ELECTRICIDAD','Consumo mensual de electricidad',3,0,'A17','');
INSERT INTO `usual_providers` VALUES (3,'Hidrológica de la Regio Capital, C.A. (HIDROCAPITAL)','G200121076','HIDROCAPITAL','Consumo mensual de agua',3,1,'A17','');
INSERT INTO `usual_providers` VALUES (4,'José Alfredo Tamayo','V20112432','Jardinero','Pago por trabajos (jardinería)',1,0,'A17','Trabaja martes y jueves');
INSERT INTO `usual_providers` VALUES (5,'Proyectos Técnicos, S.A.','J311429506','MANT. ASCENSORES','Mantenimiento de ascensores',3,0,'A17','');
INSERT INTO `usual_providers` VALUES (6,'María Laura Mora Torta','V13900343','LIMPIEZA EDIFICIO','Sueldo mensual (limpieza)',1,0,'A17','');
INSERT INTO `usual_providers` VALUES (7,'Consorcio de Ferreterías Comerciales EPA C.A.','J000000456','EPA','Compra de materiales varios',2,2,'A17','');
INSERT INTO `usual_providers` VALUES (8,'Servicios y Proyectos Cosmonauta C.A.','J000456789','ADMINISTRACION','Sitio Web de administración',3,0,'Country_Park','');
/*!40000 ALTER TABLE `usual_providers` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-09-01 17:04:21
